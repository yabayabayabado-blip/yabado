const captureButton = document.querySelector('#captureButton');
const saveButton = document.querySelector('#saveButton');
const libraryButton = document.querySelector('#libraryButton');
const statusNode = document.querySelector('#status');
const countBadge = document.querySelector('#countBadge');

refreshCount();
captureButton.addEventListener('click', () => capture(true));
saveButton.addEventListener('click', () => capture(false));
libraryButton.addEventListener('click', () => chrome.runtime.sendMessage({ type: 'OPEN_LIBRARY' }));

async function capture(shouldDownload) {
  setBusy(true);
  showStatus('正在辨識貼文中的動圖…');
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id || !/^https:\/\/(?:[^/]+\.)?threads\.com\//i.test(tab.url || '')) {
      throw new Error('目前頁面不是 Threads，請先開啟要擷取的貼文。');
    }

    const scan = await chrome.tabs.sendMessage(tab.id, { type: 'SCAN_THREADS_MEDIA' });
    if (!scan?.ok) throw new Error(scan?.error || '無法讀取此貼文。');
    if (!scan.items?.length) {
      throw new Error('目前貼文未找到動圖。請先播放動圖或滑過貼文內容，再按一次。');
    }

    showStatus(`找到 ${scan.items.length} 個動圖來源，正在保存…`);
    const stored = await chrome.runtime.sendMessage({
      type: 'STORE_MEDIA_BATCH',
      items: scan.items,
      page: scan.page
    });
    if (!stored?.ok && !stored?.saved?.length) throw new Error(stored?.error || '保存失敗。');

    const ids = [...new Set((stored.saved || []).map((entry) => entry.id))];
    if (shouldDownload) await downloadIds(ids);

    const newCount = (stored.saved || []).filter((entry) => !entry.existing).length;
    const failedText = stored.failed?.length ? `，另有 ${stored.failed.length} 個來源無法取得` : '';
    showStatus(
      shouldDownload
        ? `完成：${ids.length} 個檔案已下載，新增收藏 ${newCount} 個${failedText}。`
        : `完成：新增收藏 ${newCount} 個，略過重複 ${stored.skipped || 0} 個${failedText}。`,
      'success'
    );
    await refreshCount();
  } catch (error) {
    const message = error?.message?.includes('Receiving end does not exist')
      ? '擴充功能剛安裝或更新，請重新整理 Threads 頁面後再試。'
      : error?.message || '執行失敗。';
    showStatus(message, 'error');
  } finally {
    setBusy(false);
  }
}

async function downloadIds(ids) {
  for (const id of ids) {
    const item = await getMedia(id);
    if (!item?.blob) continue;
    const objectUrl = URL.createObjectURL(item.blob);
    try {
      await chrome.downloads.download({
        url: objectUrl,
        filename: `Threads動圖/${item.filename}`,
        conflictAction: 'uniquify',
        saveAs: false
      });
    } finally {
      setTimeout(() => URL.revokeObjectURL(objectUrl), 60_000);
    }
  }
}

async function refreshCount() {
  try {
    const response = await chrome.runtime.sendMessage({ type: 'GET_LIBRARY_COUNT' });
    countBadge.textContent = response?.ok ? String(response.count) : '—';
  } catch (_) {
    countBadge.textContent = '—';
  }
}

function setBusy(isBusy) {
  captureButton.disabled = isBusy;
  saveButton.disabled = isBusy;
}

function showStatus(message, kind = '') {
  statusNode.textContent = message;
  statusNode.className = `status ${kind}`.trim();
}
