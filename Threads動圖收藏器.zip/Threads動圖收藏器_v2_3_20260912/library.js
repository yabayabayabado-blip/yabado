const grid = document.querySelector('#grid');
const empty = document.querySelector('#empty');
const summary = document.querySelector('#summary');
const statusNode = document.querySelector('#status');
const template = document.querySelector('#cardTemplate');
const copyButton = document.querySelector('#copyButton');
const openFolderButton = document.querySelector('#openFolderButton');
const batchDeleteButton = document.querySelector('#batchDeleteButton');
const lineModeButton = document.querySelector('#lineModeButton');
const lineConnection = document.querySelector('#lineConnection');
const lineCount = document.querySelector('#lineCount');
const lineSelectAllButton = document.querySelector('#lineSelectAllButton');
const lineStopButton = document.querySelector('#lineStopButton');
const lineCancelButton = document.querySelector('#lineCancelButton');
const lineWindowDialog = document.querySelector('#lineWindowDialog');
const lineWindowSelect = document.querySelector('#lineWindowSelect');
const contentScale = document.querySelector('#contentScale');
const previewLevel = document.querySelector('#previewLevel');
const previewLevelLabel = document.querySelector('#previewLevelLabel');

let media = [];
let selectedId = null;
let lineRunning = false;
let stopLineRequested = false;
let nativeReady = false;
const lineSelectedIds = new Set();
const objectUrls = new Map();
const NATIVE_HOST = 'com.cjcu.threads_line_clipboard';

copyButton.addEventListener('click', copySelected);
openFolderButton.addEventListener('click', openImageFolder);
batchDeleteButton.addEventListener('click', removeBatchSelected);
lineModeButton.addEventListener('click', startLineSequence);
lineSelectAllButton.addEventListener('click', toggleLineSelectAll);
lineStopButton.addEventListener('click', () => {
  stopLineRequested = true;
  lineStopButton.disabled = true;
  showStatus('已要求停止；目前這張完成送出後不再處理下一張。');
});
lineCancelButton.addEventListener('click', () => clearLineSelection(true));
contentScale.addEventListener('change', saveSettings);
previewLevel.addEventListener('input', () => {
  applyPreviewLevel();
  saveSettings();
});
window.addEventListener('beforeunload', releaseObjectUrls);

initialize();

async function initialize() {
  const settings = await chrome.storage.local.get({
    contentScale: '0.5',
    previewLevel: '5'
  });
  contentScale.value = settings.contentScale === '1' ? '1' : '0.5';
  previewLevel.value = settings.previewLevel;
  applyPreviewLevel();
  await loadLibrary();
  await checkNativeHost();
}

async function saveSettings() {
  await chrome.storage.local.set({
    contentScale: contentScale.value,
    previewLevel: previewLevel.value
  });
}

function applyPreviewLevel() {
  const level = Math.max(1, Math.min(10, Number(previewLevel.value) || 5));
  const sizes = [44, 55, 66, 77, 110, 132, 154, 176, 198, 220];
  const percentages = [20, 25, 30, 35, 50, 60, 70, 80, 90, 100];
  grid.style.setProperty('--card-size', `${sizes[level - 1]}px`);
  grid.classList.toggle('small-cards', level >= 5 && level <= 6);
  grid.classList.toggle('thumbnail-only', level <= 4);
  previewLevelLabel.textContent = `第${level}級（${percentages[level - 1]}%）`;
}

async function loadLibrary() {
  try {
    media = (await getAllMedia()).sort((a, b) => b.capturedAt.localeCompare(a.capturedAt));
    render();
  } catch (error) {
    showStatus(`無法開啟收藏：${error.message}`, true);
  }
}

function render() {
  releaseObjectUrls();
  grid.replaceChildren();
  selectedId = null;
  lineSelectedIds.clear();
  empty.hidden = media.length > 0;
  grid.hidden = media.length === 0;
  summary.textContent = `共 ${media.length} 個收藏；每張圖只需勾選一次，再執行複製、LINE 傳送或刪除`;

  for (const item of media) {
    const node = template.content.firstElementChild.cloneNode(true);
    const lineCheckbox = node.querySelector('.line-selector');
    const preview = node.querySelector('.preview');
    const objectUrl = URL.createObjectURL(item.blob);
    objectUrls.set(item.id, objectUrl);

    const visual = item.kind === 'video'
      ? Object.assign(document.createElement('video'), { src: objectUrl, muted: true, loop: true, autoplay: true, playsInline: true })
      : Object.assign(document.createElement('img'), { src: objectUrl, alt: item.pageTitle || 'Threads 動圖' });
    preview.append(visual);
    preview.addEventListener('click', () => {
      lineCheckbox.checked = !lineCheckbox.checked;
      updateLineSelection(item.id, lineCheckbox.checked, node);
    });
    lineCheckbox.addEventListener('change', () => updateLineSelection(item.id, lineCheckbox.checked, node));

    node.querySelector('.type-pill').textContent = item.extension.toUpperCase();
    node.querySelector('.size').textContent = formatBytes(item.bytes);
    node.querySelector('.title').textContent = item.pageTitle || item.filename;
    node.querySelector('.date').textContent = new Date(item.capturedAt).toLocaleString('zh-TW', { hour12: false });
    const source = node.querySelector('.source');
    source.href = item.sourcePage || item.sourceUrl;
    grid.append(node);
  }
  updateToolbar();
  updateBatchToolbar();
  updateLineToolbar();
}

function updateToolbar() {
  const hasSelection = lineSelectedIds.size === 1 && Boolean(selectedId);
  copyButton.disabled = !hasSelection;
}

function updateBatchToolbar() {
  const count = lineSelectedIds.size;
  batchDeleteButton.textContent = `刪除已勾選 ${count} 張`;
  batchDeleteButton.disabled = lineRunning || count === 0;
}

function clearLineSelection(showMessage) {
  if (lineRunning) return;
  resetLineSelectionState();
  if (showMessage) showStatus('已清除所有 LINE 圖片選取。');
}

function resetLineSelectionState() {
  stopLineRequested = false;
  lineSelectedIds.clear();
  selectedId = null;
  grid.querySelectorAll('.line-selector').forEach((checkbox) => { checkbox.checked = false; });
  grid.querySelectorAll('.card').forEach((card) => card.classList.remove('line-selected', 'selected'));
  updateToolbar();
  updateBatchToolbar();
  updateLineToolbar();
}

async function checkNativeHost() {
  lineConnection.textContent = '正在檢查 Windows 橋接程式…';
  try {
    const response = await nativeCall({ action: 'ping' });
    if (!response?.ok) throw new Error(response?.error || 'bridge_error');
    nativeReady = true;
    const windowCount = Number(response.windowCount || 0);
    lineConnection.textContent = windowCount > 0
      ? `橋接程式正常，已偵測到 ${windowCount} 個 LINE 視窗。`
      : '橋接程式正常；送出時會等待 LINE 對話視窗 5 秒。';
    lineConnection.className = windowCount > 0 ? 'connected' : 'warning';
  } catch (error) {
    nativeReady = false;
    lineConnection.textContent = '尚未安裝橋接程式，請執行「安裝LINE自動貼上功能.cmd」。';
    lineConnection.className = 'error';
  }
  updateLineToolbar();
}

function updateLineSelection(id, checked, card) {
  if (checked) lineSelectedIds.add(id); else lineSelectedIds.delete(id);
  card.classList.toggle('line-selected', checked);
  selectedId = lineSelectedIds.size === 1 ? [...lineSelectedIds][0] : null;
  updateToolbar();
  updateBatchToolbar();
  updateLineToolbar();
}

function updateLineToolbar() {
  const count = lineSelectedIds.size;
  lineCount.textContent = `已勾選 ${count} 張`;
  lineModeButton.textContent = lineRunning
    ? '正在貼上…'
    : count > 0
      ? `LINE 自動貼上（${count}）`
      : 'LINE 自動貼上（請先勾選）';
  lineModeButton.disabled = lineRunning || count === 0 || !nativeReady;
  lineSelectAllButton.disabled = lineRunning || media.length === 0;
  lineSelectAllButton.textContent = media.length > 0 && count === media.length ? '取消全選' : '全選';
  contentScale.disabled = lineRunning;
  lineCancelButton.disabled = lineRunning || count === 0;
  lineStopButton.disabled = !lineRunning || stopLineRequested;
}

function toggleLineSelectAll() {
  const shouldSelect = lineSelectedIds.size !== media.length;
  lineSelectedIds.clear();
  if (shouldSelect) media.forEach((item) => lineSelectedIds.add(item.id));
  [...grid.querySelectorAll('.card')].forEach((card) => {
    const checkbox = card.querySelector('.line-selector');
    checkbox.checked = shouldSelect;
    card.classList.toggle('line-selected', shouldSelect);
  });
  selectedId = lineSelectedIds.size === 1 ? [...lineSelectedIds][0] : null;
  updateToolbar();
  updateBatchToolbar();
  updateLineToolbar();
}

async function startLineSequence() {
  const ids = [...lineSelectedIds];
  const items = ids.map((id) => media.find((item) => item.id === id)).filter(Boolean);
  if (!items.length || lineRunning) return;
  if (!nativeReady) {
    showStatus('LINE 橋接程式尚未就緒，請重新安裝橋接程式後重開 Chrome。', true);
    await checkNativeHost();
    return;
  }

  lineRunning = true;
  stopLineRequested = false;
  updateBatchToolbar();
  updateLineToolbar();
  let completed = 0;
  try {
    const targetWindow = await waitForLineTarget();
    if (!targetWindow) {
      const wasStopped = stopLineRequested;
      await safelyClearClipboard();
      resetLineSelectionState();
      showStatus(wasStopped
        ? '已停止等待 LINE 視窗；剪貼簿已清空並回復預設狀態。'
        : '5 秒內仍未偵測到可用的 LINE 對話視窗；已清空剪貼簿並回復預設狀態。', true);
      return;
    }
    showStatus(`已選擇 LINE 視窗「${targetWindow.title}」，開始準備圖片…`);

    for (let index = 0; index < items.length; index += 1) {
      if (stopLineRequested) break;
      const item = items[index];
      showStatus(`正在準備第 ${index + 1}／${items.length} 張…`);
      const output = await createOutputBlob(item, contentScale.value, (message) => {
        showStatus(`第 ${index + 1}／${items.length} 張：${message}`);
      });
      if (output.blob.size > 45 * 1024 * 1024) {
        throw new Error('輸出檔案超過45 MB，請降低輸出尺寸。');
      }
      if (stopLineRequested) break;
      showStatus(`正在貼上第 ${index + 1}／${items.length} 張到 LINE…`);
      const response = await nativeCall({
        action: 'paste_and_send_file',
        windowId: targetWindow.id,
        filename: lineFilename(item, output.extension),
        base64: await blobToBase64(output.blob)
      });
      if (!response?.ok) throw new Error(nativeErrorMessage(response?.error));
      completed += 1;
      if (index < items.length - 1 && !stopLineRequested) showStatus(`已送出 ${completed} 張，正在準備下一張…`);
    }
    if (stopLineRequested) {
      await safelyClearClipboard();
      showStatus(`已停止，共送出 ${completed}／${items.length} 張；剪貼簿已清空。`);
    } else {
      await safelyClearClipboard();
      resetLineSelectionState();
      showStatus(`完成：${completed} 張已依序送出，系統剪貼簿已清空。`);
    }
  } catch (error) {
    await safelyClearClipboard();
    resetLineSelectionState();
    showStatus(`LINE 自動貼上中止：${nativeErrorMessage(error.message)}`, true);
  } finally {
    lineRunning = false;
    stopLineRequested = false;
    updateBatchToolbar();
    updateLineToolbar();
    await checkNativeHost();
  }
}

async function waitForLineTarget() {
  let windows = await listLineWindows();
  if (!windows.length) {
    lineConnection.textContent = '尚未偵測到 LINE 對話視窗；請在 5 秒內開啟聊天室…';
    lineConnection.className = 'warning';
    showStatus('沒有偵測到已開啟的 LINE 對話視窗，正在待命 5 秒；請立即開啟要傳送的聊天室。');
    const deadline = Date.now() + 5000;
    while (Date.now() < deadline && !stopLineRequested) {
      const remaining = Math.max(1, Math.ceil((deadline - Date.now()) / 1000));
      lineConnection.textContent = `請開啟 LINE 對話視窗；剩餘 ${remaining} 秒…`;
      await wait(500);
      windows = await listLineWindows();
      if (windows.length) break;
    }
  }
  if (!windows.length || stopLineRequested) return null;
  if (windows.length === 1) return windows[0];
  const selectedWindow = await chooseLineWindow(windows);
  if (!selectedWindow) throw new Error('line_window_selection_cancelled');
  return selectedWindow;
}

async function listLineWindows() {
  const response = await nativeCall({ action: 'list_line_windows' });
  if (!response?.ok) throw new Error(nativeErrorMessage(response?.error));
  return Array.isArray(response.windows)
    ? response.windows.filter((entry) => String(entry.title || '').trim().toLowerCase() !== 'line')
    : [];
}

function chooseLineWindow(windows) {
  lineWindowSelect.replaceChildren();
  windows.forEach((entry, index) => {
    const option = document.createElement('option');
    option.value = entry.id;
    option.textContent = `${index + 1}. ${entry.title || 'LINE 對話視窗'}`;
    lineWindowSelect.append(option);
  });
  lineWindowDialog.showModal();
  return new Promise((resolve) => {
    lineWindowDialog.addEventListener('close', () => {
      if (lineWindowDialog.returnValue !== 'confirm') {
        resolve(null);
        return;
      }
      resolve(windows.find((entry) => entry.id === lineWindowSelect.value) || null);
    }, { once: true });
  });
}

async function safelyClearClipboard() {
  try { await nativeCall({ action: 'clear_clipboard' }); } catch (_) { }
}

function wait(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

function nativeCall(message) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendNativeMessage(NATIVE_HOST, message, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve(response);
    });
  });
}

function nativeErrorMessage(value) {
  const message = String(value || '未知錯誤');
  if (/host not found|not registered|Specified native messaging/i.test(message)) {
    return '找不到 Windows 橋接程式，請執行「安裝LINE自動貼上功能.cmd」後重新開啟 Chrome。';
  }
  const messages = {
    line_not_running: '找不到 LINE 電腦版，請先開啟 LINE 並進入正確聊天室。',
    line_focus_failed: '無法切換到 LINE 視窗，請解除最小化並重新執行。',
    line_window_closed: '選取的 LINE 對話視窗已關閉，請重新選取後再傳送。',
    line_window_selection_cancelled: '已取消選擇 LINE 對話視窗。',
    clipboard_busy: '系統剪貼簿正被其他程式占用，請稍後重試。',
    clipboard_clear_failed: '圖片已送出，但系統剪貼簿無法清空，請手動清除。',
    file_too_large: '動圖超過橋接程式限制，請降低輸出尺寸。',
    empty_file: '輸出的動圖內容為空。'
  };
  return messages[message] || message;
}

function lineFilename(item, extension) {
  const baseName = item.filename.replace(/\.[^.]+$/, '').replace(/[^\w\u4e00-\u9fff@.-]+/g, '_');
  return `${baseName}_${sizeSuffix()}.${extension}`;
}

function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(',')[1] || '');
    reader.onerror = () => reject(reader.error || new Error('讀取輸出檔案失敗。'));
    reader.readAsDataURL(blob);
  });
}

async function copySelected() {
  const item = chosenItem();
  if (!item) return;
  setActionsBusy(true);
  try {
    showStatus('正在把原始動圖檔寫入系統剪貼簿…');
    const response = await nativeCall({
      action: 'copy_file',
      filename: originalFilename(item),
      base64: await blobToBase64(item.blob)
    });
    if (!response?.ok) throw new Error(nativeErrorMessage(response?.error));
    showStatus(`已複製原始 ${item.extension.toUpperCase()} 檔（${formatBytes(item.blob.size)}），沒有複製網址、沒有重新縮放。`);
  } catch (error) {
    showStatus(`複製失敗：${nativeErrorMessage(error.message)}`, true);
  } finally {
    setActionsBusy(false);
  }
}

function originalFilename(item) {
  const extension = String(item.extension || '').replace(/^\./, '') || extensionFromMime(item.mime);
  const baseName = String(item.filename || `threads_${Date.now()}`).replace(/[\\/:*?"<>|]+/g, '_').replace(/\.[^.]+$/, '');
  return `${baseName}.${extension}`;
}

function extensionFromMime(mime) {
  if (mime === 'image/gif') return 'gif';
  if (mime === 'image/png') return 'png';
  if (mime === 'image/webp') return 'webp';
  if (mime === 'video/webm') return 'webm';
  return 'mp4';
}

async function openImageFolder() {
  try {
    // Chrome downloads API 的 DownloadItem.filename 會提供實際下載檔案的完整路徑。
    // 從最近的下載紀錄找出 Threads動圖 子資料夾，避免只開啟下載根目錄。
    const downloads = await chrome.downloads.search({
      orderBy: ['-startTime'],
      limit: 1000
    });
    const marker = `${String.fromCharCode(92)}Threads動圖${String.fromCharCode(92)}`;
    const matched = downloads.find((item) => {
      const filename = String(item?.filename || '');
      return filename.includes(marker) || filename.replaceAll('\\', '/').includes('/Threads動圖/');
    });

    if (matched?.filename) {
      const normalized = String(matched.filename).replaceAll('/', '\\');
      const lastSeparator = normalized.lastIndexOf('\\');
      if (lastSeparator > 0) {
        const folderPath = normalized.slice(0, lastSeparator);
        const response = await nativeCall({ action: 'open_folder', folderPath });
        if (response?.ok) {
          showStatus('已開啟 Threads動圖 圖片存放目錄。');
          return;
        }
        throw new Error(nativeErrorMessage(response?.error));
      }
    }

    // 尚未有 Threads動圖 的下載紀錄時，無法由 Chrome API 推得自訂下載子目錄的絕對路徑。
    // 此時退回 Chrome 下載根目錄，讓使用者仍能正常操作。
    chrome.downloads.showDefaultFolder();
    showStatus('目前尚未找到 Threads動圖 的下載紀錄，已開啟 Chrome 下載目錄。');
  } catch (error) {
    try {
      chrome.downloads.showDefaultFolder();
      showStatus('無法直接定位 Threads動圖 子目錄，已改為開啟 Chrome 下載目錄。', true);
    } catch (_) {
      showStatus(`無法開啟圖片目錄：${nativeErrorMessage(error.message)}`, true);
    }
  }
}

async function removeBatchSelected() {
  const ids = [...lineSelectedIds];
  if (!ids.length) return;
  if (!confirm(`確定要刪除已勾選的 ${ids.length} 個本機收藏嗎？此動作無法復原。`)) return;
  setBatchBusy(true);
  try {
    const idSet = new Set(ids);
    for (const id of ids) await deleteMedia(id);
    media = media.filter((item) => !idSet.has(item.id));
      chrome.action.setBadgeText({ text: media.length ? String(Math.min(media.length, 999)) : '' });
    render();
    showStatus(`已刪除 ${ids.length} 個收藏。`);
    window.setTimeout(() => {
      if (statusNode.textContent === `已刪除 ${ids.length} 個收藏。`) showStatus('');
    }, 1200);
  } catch (error) {
    showStatus(`刪除失敗：${error.message}`, true);
    updateBatchToolbar();
  } finally {
    setBatchBusy(false);
  }
}

function chosenItem() {
  return media.find((item) => item.id === selectedId) || null;
}

function sizeSuffix() {
  const value = Number(contentScale.value);
  const labels = new Map([
    [1, '原始大小'],
    [0.5, '百分之五十']
  ]);
  return labels.get(value) || `縮小${Math.round(value * 10000) / 100}%`;
}

function setActionsBusy(busy) {
  [copyButton, openFolderButton, lineModeButton, contentScale].forEach((control) => { control.disabled = busy; });
  if (!busy) {
    updateToolbar();
    updateLineToolbar();
  }
}

function setBatchBusy(busy) {
  batchDeleteButton.disabled = busy;
  if (!busy) updateBatchToolbar();
}

function showStatus(message, isError = false) {
  statusNode.textContent = message;
  statusNode.className = `status${isError ? ' error' : ''}`;
}

function formatBytes(bytes) {
  if (!Number.isFinite(bytes) || bytes <= 0) return '—';
  const units = ['B', 'KB', 'MB', 'GB'];
  const index = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  return `${(bytes / 1024 ** index).toFixed(index ? 1 : 0)} ${units[index]}`;
}

function releaseObjectUrls() {
  objectUrls.forEach((url) => URL.revokeObjectURL(url));
  objectUrls.clear();
}
