const captureButton = document.querySelector('#captureButton');
const saveButton = document.querySelector('#saveButton');
const libraryButton = document.querySelector('#libraryButton');
const otherMediaButton = document.querySelector('#otherMediaButton');
const statusNode = document.querySelector('#status');
const countBadge = document.querySelector('#countBadge');

refreshCount();
captureButton.addEventListener('click', () => capture(true));
saveButton.addEventListener('click', () => capture(false));
libraryButton.addEventListener('click', () => chrome.runtime.sendMessage({ type: 'OPEN_LIBRARY' }));
otherMediaButton.addEventListener('click', openOtherMedia);

async function capture(shouldDownload) {
  setBusy(true);
  showStatus('正在辨識貼文中的動圖…');
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id || !/^https:\/\/(?:[^/]+\.)?threads\.com\//i.test(tab.url || '')) {
      throw new Error('目前頁面不是 Threads，請先開啟要擷取的貼文。');
    }

    const scan = await chrome.tabs.sendMessage(tab.id, { type: 'SCAN_THREADS_MEDIA' });
    if (!scan?.ok) throw new Error(scan?.error || '無法讀取此貼文。');
    if (!scan.items?.length) {
      throw new Error('目前貼文未找到動圖。請先播放動圖或滑過貼文內容，再按一次。');
    }

    showStatus(`找到 ${scan.items.length} 個動圖來源，正在保存…`);
    const stored = await chrome.runtime.sendMessage({
      type: 'STORE_MEDIA_BATCH',
      items: scan.items,
      page: scan.page
    });
    if (!stored?.ok && !stored?.saved?.length) throw new Error(stored?.error || '保存失敗。');

    const savedEntries = stored.saved || [];
    const newIds = [...new Set(savedEntries.filter((entry) => !entry.existing).map((entry) => entry.id))];
    const downloadedCount = shouldDownload && newIds.length ? await downloadIds(newIds) : 0;
    if (downloadedCount > 0) {
      try { await chrome.runtime.sendMessage({ type: 'REFRESH_FOLDER_INDEX_SIGNATURE' }); } catch (_) { }
    }

    const newCount = newIds.length;
    const skippedCount = stored.skipped || 0;
    const failedText = stored.failed?.length ? `，另有 ${stored.failed.length} 個來源無法取得` : '';
    showStatus(
      shouldDownload
        ? `完成：下載 ${downloadedCount} 個 GIF，新增收藏 ${newCount} 個，略過重複 ${skippedCount} 個${failedText}。`
        : `完成：新增收藏 ${newCount} 個，略過重複 ${skippedCount} 個${failedText}。`,
      'success'
    );
    await refreshCount();
  } catch (error) {
    const message = error?.message?.includes('Receiving end does not exist')
      ? '擴充功能剛安裝或更新，請重新整理 Threads 頁面後再試。'
      : error?.message || '執行失敗。';
    showStatus(message, 'error');
  } finally {
    setBusy(false);
  }
}

async function downloadIds(ids) {
  let downloaded = 0;
  for (const id of ids) {
    const item = await getMedia(id);
    if (!item?.blob) continue;
    const isGif = item.mime === 'image/gif' || String(item.extension || '').toLowerCase() === 'gif';
    if (!isGif) continue;

    const objectUrl = URL.createObjectURL(item.blob);
    try {
      const downloadId = await chrome.downloads.download({
        url: objectUrl,
        filename: `Threads動圖/${item.filename.replace(/\.[^.]+$/, '.gif')}`,
        conflictAction: 'uniquify',
        saveAs: false
      });
      downloaded += 1;
      const localPath = await waitForDownloadPath(downloadId);
      if (localPath) {
        item.localFilePath = localPath;
        item.recoveredFromDownload = true;
        await putMedia(item);
      }
    } finally {
      setTimeout(() => URL.revokeObjectURL(objectUrl), 60_000);
    }
  }
  return downloaded;
}

async function waitForDownloadPath(downloadId) {
  for (let attempt = 0; attempt < 20; attempt += 1) {
    const items = await chrome.downloads.search({ id: downloadId });
    const path = String(items?.[0]?.filename || '');
    if (path) return path;
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  return '';
}

async function refreshCount() {
  try {
    const response = await chrome.runtime.sendMessage({ type: 'GET_LIBRARY_COUNT' });
    countBadge.textContent = response?.ok ? String(response.count) : '—';
  } catch (_) {
    countBadge.textContent = '—';
  }
}

function setBusy(isBusy) {
  captureButton.disabled = isBusy;
  saveButton.disabled = isBusy;
  otherMediaButton.disabled = isBusy;
}

async function openOtherMedia() {
  setBusy(true);
  showStatus('正在掃描貼文中的其他媒體…');
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id || !/^https:\/\/(?:[^/]+\.)?threads\.com\//i.test(tab.url || '')) {
      throw new Error('目前頁面不是 Threads，請先開啟要擷取的貼文。');
    }
    let scan = await chrome.tabs.sendMessage(tab.id, { type: 'SCAN_THREADS_ALL_MEDIA' });
    // 相容更新前已開啟的 Threads 分頁；若舊 content script 不認識新指令，改用舊掃描指令。
    if (!scan?.ok) scan = await chrome.tabs.sendMessage(tab.id, { type: 'SCAN_THREADS_OTHER_MEDIA' });
    if (!scan?.ok) throw new Error(scan?.error || '無法讀取此貼文。');
    const candidates = Array.isArray(scan.items) ? scan.items.filter((item) => !/\.gif(?:$|[?#])/i.test(item?.url || '') && !/(?:format|fm|ext)=gif(?:&|$)/i.test(item?.url || '')) : [];
    if (!candidates.length) throw new Error('目前貼文未找到 GIF 以外可下載的媒體。');
    await chrome.storage.local.set({ threadsOtherMediaScan: { items: candidates, page: scan.page, scannedAt: Date.now() } });
    await chrome.tabs.create({ url: chrome.runtime.getURL('other-media.html') });
    showStatus(`找到 ${candidates.length} 個其他媒體。`, 'success');
  } catch (error) {
    const message = error?.message?.includes('Receiving end does not exist')
      ? '擴充功能剛安裝或更新，請重新整理 Threads 頁面後再試。'
      : error?.message || '執行失敗。';
    showStatus(message, 'error');
  } finally {
    setBusy(false);
  }
}

function showStatus(message, kind = '') {
  statusNode.textContent = message;
  statusNode.className = `status ${kind}`.trim();
}
