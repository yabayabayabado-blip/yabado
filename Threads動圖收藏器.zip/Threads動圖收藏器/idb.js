const DB_NAME = 'threads-motion-library';
const DB_VERSION = 1;
const STORE_NAME = 'media';

function openMediaDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, { keyPath: 'id' });
        store.createIndex('capturedAt', 'capturedAt');
        store.createIndex('sourcePage', 'sourcePage');
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function dbRequest(mode, operation) {
  const db = await openMediaDB();
  try {
    return await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, mode);
      const store = tx.objectStore(STORE_NAME);
      let request;
      try {
        request = operation(store);
      } catch (error) {
        reject(error);
        return;
      }
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
      tx.onabort = () => reject(tx.error || new Error('資料庫交易已中止'));
    });
  } finally {
    db.close();
  }
}

function getAllMedia() {
  return dbRequest('readonly', (store) => store.getAll());
}

function getMedia(id) {
  return dbRequest('readonly', (store) => store.get(id));
}

function putMedia(item) {
  return dbRequest('readwrite', (store) => store.put(item));
}

function deleteMedia(id) {
  return dbRequest('readwrite', (store) => store.delete(id));
}

function clearMedia() {
  return dbRequest('readwrite', (store) => store.clear());
}
