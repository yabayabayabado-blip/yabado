importScripts('idb.js');

chrome.runtime.onInstalled.addListener(() => {
  chrome.action.setBadgeBackgroundColor({ color: '#0a7a5a' });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'STORE_MEDIA_BATCH') {
    storeMediaBatch(message.items || [], message.page || {})
      .then(sendResponse)
      .catch((error) => sendResponse({ ok: false, error: friendlyError(error) }));
    return true;
  }

  if (message?.type === 'GET_LIBRARY_COUNT') {
    getAllMedia()
      .then((items) => sendResponse({ ok: true, count: items.length }))
      .catch((error) => sendResponse({ ok: false, error: friendlyError(error) }));
    return true;
  }

  if (message?.type === 'OPEN_LIBRARY') {
    chrome.tabs.create({ url: chrome.runtime.getURL('library.html') });
    sendResponse({ ok: true });
  }
});

async function storeMediaBatch(items, page) {
  if (!Array.isArray(items) || items.length === 0) {
    return { ok: true, saved: [], skipped: 0, failed: [] };
  }

  const unique = [...new Map(items.map((item) => [item.url, item])).values()];
  const saved = [];
  const failed = [];
  let skipped = 0;

  for (let index = 0; index < unique.length; index += 1) {
    const candidate = unique[index];
    try {
      const id = await sha256(candidate.url);
      const existing = await getMedia(id);
      if (existing) {
        skipped += 1;
        saved.push({ id, existing: true });
        continue;
      }

      const response = await fetch(candidate.url, {
        credentials: 'include',
        cache: 'no-cache',
        referrer: page.url || 'https://www.threads.com/'
      });
      if (!response.ok) throw new Error(`下載來源回應 ${response.status}`);

      const blob = await response.blob();
      if (!blob.size) throw new Error('來源檔案大小為 0');

      const contentHash = await sha256Blob(blob);
      const existingItems = await getAllMedia();
      const sameContent = existingItems.find((item) => item.contentHash && item.contentHash === contentHash);
      if (sameContent) {
        skipped += 1;
        saved.push({ id: sameContent.id, existing: true });
        continue;
      }

      const mime = normalizeMime(blob.type, candidate.kind, candidate.url);
      const extension = extensionFromMime(mime, candidate.url);
      const capturedAt = new Date().toISOString();
      const item = {
        id,
        blob: blob.type === mime ? blob : blob.slice(0, blob.size, mime),
        mime,
        extension,
        bytes: blob.size,
        kind: mime.startsWith('video/') ? 'video' : 'image',
        sourceUrl: candidate.url,
        sourcePage: page.url || '',
        pageTitle: page.title || 'Threads 貼文',
        author: page.author || '',
        capturedAt,
        filename: buildFilename(page, index + 1, extension),
        contentHash
      };
      await putMedia(item);
      saved.push({ id, existing: false });
    } catch (error) {
      failed.push({ url: candidate.url, error: friendlyError(error) });
    }
  }

  const all = await getAllMedia();
  chrome.action.setBadgeText({ text: all.length ? String(Math.min(all.length, 999)) : '' });
  return { ok: failed.length !== unique.length, saved, skipped, failed };
}


async function sha256Blob(blob) {
  const buffer = await blob.arrayBuffer();
  const digest = await crypto.subtle.digest('SHA-256', buffer);
  return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, '0')).join('');
}

async function sha256(value) {
  const data = new TextEncoder().encode(value);
  const digest = await crypto.subtle.digest('SHA-256', data);
  return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, '0')).join('');
}

function normalizeMime(mime, kind, url) {
  const clean = (mime || '').split(';')[0].toLowerCase();
  if (/^(image|video)\//.test(clean)) return clean;
  const lower = url.toLowerCase();
  if (/\.gif(?:$|[?#])/.test(lower)) return 'image/gif';
  if (/\.webp(?:$|[?#])/.test(lower)) return 'image/webp';
  if (/\.webm(?:$|[?#])/.test(lower)) return 'video/webm';
  if (/\.mov(?:$|[?#])/.test(lower)) return 'video/quicktime';
  return kind === 'video' ? 'video/mp4' : 'image/gif';
}

function extensionFromMime(mime, url) {
  const types = {
    'image/gif': 'gif',
    'image/webp': 'webp',
    'image/png': 'png',
    'image/jpeg': 'jpg',
    'video/mp4': 'mp4',
    'video/webm': 'webm',
    'video/quicktime': 'mov'
  };
  if (types[mime]) return types[mime];
  const match = url.match(/\.([a-z0-9]{2,5})(?:$|[?#])/i);
  return match ? match[1].toLowerCase() : 'bin';
}

function buildFilename(page, index, extension) {
  const date = new Date().toISOString().slice(0, 10).replaceAll('-', '');
  const author = sanitizeFilename(page.author || 'threads');
  return `${date}_${author}_${String(index).padStart(2, '0')}.${extension}`;
}

function sanitizeFilename(value) {
  return String(value).replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').replace(/\s+/g, '_').slice(0, 60) || 'threads';
}

function friendlyError(error) {
  if (error?.name === 'QuotaExceededError') return '本機收藏空間不足，請先刪除部分舊收藏。';
  return error?.message || String(error || '未知錯誤');
}
