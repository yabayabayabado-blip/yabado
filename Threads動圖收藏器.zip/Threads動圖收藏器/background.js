importScripts('idb.js');

const NATIVE_HOST = 'com.cjcu.threads_line_clipboard';
let recoveryPromise = null;

chrome.runtime.onInstalled.addListener(() => {
  chrome.action.setBadgeBackgroundColor({ color: '#0a7a5a' });
  ensureRecoveredLibrary().catch(() => {});
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'STORE_MEDIA_BATCH') {
    (async () => {
      await ensureRecoveredLibrary();
      return storeMediaBatch(message.items || [], message.page || {});
    })()
      .then(sendResponse)
      .catch((error) => sendResponse({ ok: false, error: friendlyError(error) }));
    return true;
  }

  if (message?.type === 'GET_LIBRARY_COUNT') {
    (async () => {
      await ensureRecoveredLibrary();
      const items = await getAllMedia();
      return { ok: true, count: items.length };
    })()
      .then(sendResponse)
      .catch((error) => sendResponse({ ok: false, error: friendlyError(error) }));
    return true;
  }

  if (message?.type === 'OPEN_LIBRARY') {
    chrome.tabs.create({ url: chrome.runtime.getURL('library.html') });
    sendResponse({ ok: true });
  }
});

async function ensureRecoveredLibrary() {
  if (recoveryPromise) return recoveryPromise;
  recoveryPromise = recoverLibraryFromExistingDownloads().finally(() => {
    recoveryPromise = null;
  });
  return recoveryPromise;
}


function hasChromeDuplicateSuffix(filename) {
  return / \(\d+\)(?=\.[^.]+$)/i.test(String(filename || ''));
}

function chooseDuplicateKeeper(files) {
  return [...files].sort((a, b) => {
    const aDup = hasChromeDuplicateSuffix(a.filename) ? 1 : 0;
    const bDup = hasChromeDuplicateSuffix(b.filename) ? 1 : 0;
    if (aDup !== bDup) return aDup - bDup;
    const aTime = Date.parse(a.modifiedAt || '') || 0;
    const bTime = Date.parse(b.modifiedAt || '') || 0;
    if (aTime !== bTime) return aTime - bTime;
    const aName = String(a.filename || '');
    const bName = String(b.filename || '');
    if (aName.length !== bName.length) return aName.length - bName.length;
    return aName.localeCompare(bName, 'zh-Hant');
  })[0];
}

async function dedupeFolderFiles(files) {
  const groups = new Map();
  for (let index = 0; index < files.length; index += 1) {
    const file = files[index];
    const fullPath = String(file.path || '');
    if (!fullPath) continue;
    try {
      const response = await nativeCall({ action: 'read_file', filePath: fullPath });
      if (!response?.ok || !response.base64) continue;
      const bytes = base64ToUint8Array(response.base64);
      if (!bytes.byteLength) continue;
      const contentHash = await sha256Bytes(bytes);
      const enriched = { ...file, contentHash, bytesData: bytes };
      if (!groups.has(contentHash)) groups.set(contentHash, []);
      groups.get(contentHash).push(enriched);
    } catch (_) { }
  }

  const kept = [];
  let deletedDuplicates = 0;
  for (const group of groups.values()) {
    const keeper = chooseDuplicateKeeper(group);
    if (!keeper) continue;
    kept.push(keeper);
    for (const file of group) {
      if (file.path === keeper.path) continue;
      try {
        const deleted = await nativeCall({ action: 'delete_file', filePath: file.path });
        if (deleted?.ok && (deleted.deleted || deleted.missing)) deletedDuplicates += 1;
        else kept.push(file);
      } catch (_) {
        kept.push(file);
      }
    }
  }
  return { files: kept, deletedDuplicates };
}

async function recoverLibraryFromExistingDownloads() {
  const folderPath = await locateThreadsFolderFromDownloads();
  if (!folderPath) return 0;

  let ping;
  try {
    ping = await nativeCall({ action: 'ping' });
  } catch (_) {
    throw new Error('已找到 Threads動圖 資料夾，但目前無法讀取實際檔案。請重新執行「安裝LINE自動貼上功能.cmd」並重開 Chrome，避免重複下載。');
  }
  if (!ping?.ok || compareVersions(String(ping.version || '0'), '2.6.1') < 0) {
    throw new Error('已找到 Threads動圖 資料夾，但 Windows 橋接程式版本過舊。請重新執行「安裝LINE自動貼上功能.cmd」並重開 Chrome，避免重複下載。');
  }

  const listing = await nativeCall({ action: 'list_folder', folderPath });
  if (!listing?.ok || !Array.isArray(listing.files)) return 0;

  // 以檔案內容雜湊去重；重複實體檔案直接從 Threads動圖 資料夾刪除，只保留一份。
  const gifFiles = listing.files.filter((file) => /\.gif$/i.test(String(file.filename || file.path || '')));
  const deduped = await dedupeFolderFiles(gifFiles);
  const folderFiles = deduped.files;

  // 只以資料夾「現在實際存在」的檔案為恢復來源，不再把 Chrome 歷史下載紀錄當收藏清單。
  const actualPaths = new Set(folderFiles.map((file) => String(file.path || '').replaceAll('\\', '/').toLowerCase()));
  const current = await getAllMedia();
  for (const item of current) {
    if (!item?.recoveredFromDownload || !item?.localFilePath) continue;
    const key = String(item.localFilePath).replaceAll('\\', '/').toLowerCase();
    if (!actualPaths.has(key)) await deleteMedia(item.id);
  }

  const existingItems = await getAllMedia();
  const hashes = new Set(existingItems.map((item) => item.contentHash).filter(Boolean));
  let restored = 0;

  for (let index = 0; index < folderFiles.length; index += 1) {
    const file = folderFiles[index];
    const fullPath = String(file.path || '');
    if (!fullPath) continue;
    try {
      const bytes = file.bytesData instanceof Uint8Array ? file.bytesData : new Uint8Array(file.bytesData || []);
      if (!bytes.byteLength) continue;
      const contentHash = file.contentHash || await sha256Bytes(bytes);
      if (hashes.has(contentHash)) continue;
      hashes.add(contentHash);

      const filename = String(file.filename || fullPath.replaceAll('\\', '/').split('/').pop() || `threads_${index + 1}.gif`);
      const extension = (filename.match(/\.([a-z0-9]{2,5})$/i)?.[1] || 'gif').toLowerCase();
      const mime = normalizeRecoveredMime('', extension);
      await putMedia({
        id: `restored_${contentHash}`,
        blob: new Blob([bytes], { type: mime }),
        mime,
        extension,
        bytes: bytes.byteLength,
        kind: mime.startsWith('video/') ? 'video' : 'image',
        sourceUrl: '',
        sourcePage: '',
        pageTitle: filename,
        author: '',
        capturedAt: file.modifiedAt || new Date().toISOString(),
        filename,
        contentHash,
        recoveredFromDownload: true,
        localFilePath: fullPath
      });
      restored += 1;
    } catch (_) { }
  }

  const all = await getAllMedia();
  chrome.action.setBadgeText({ text: all.length ? String(Math.min(all.length, 999)) : '' });
  return restored;
}

async function locateThreadsFolderFromDownloads() {
  let downloads = [];
  try {
    downloads = await chrome.downloads.search({ orderBy: ['-startTime'], limit: 5000 });
  } catch (_) {
    return '';
  }
  const marker = '/Threads動圖/';
  for (const item of downloads) {
    const fullPath = String(item?.filename || '');
    const normalized = fullPath.replaceAll('\\', '/');
    const at = normalized.toLowerCase().lastIndexOf(marker.toLowerCase());
    if (at < 0) continue;
    return fullPath.slice(0, at + marker.length - 1).replaceAll('/', '\\');
  }
  return '';
}

function compareVersions(a, b) {
  const aa = String(a).split('.').map((part) => Number(part) || 0);
  const bb = String(b).split('.').map((part) => Number(part) || 0);
  const length = Math.max(aa.length, bb.length);
  for (let i = 0; i < length; i += 1) {
    if ((aa[i] || 0) > (bb[i] || 0)) return 1;
    if ((aa[i] || 0) < (bb[i] || 0)) return -1;
  }
  return 0;
}

function nativeCall(message) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendNativeMessage(NATIVE_HOST, message, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message || 'native_host_unavailable'));
        return;
      }
      resolve(response || null);
    });
  });
}

function base64ToUint8Array(base64) {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
  return bytes;
}

async function sha256Bytes(bytes) {
  const view = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  const digest = await crypto.subtle.digest('SHA-256', view);
  return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, '0')).join('');
}

function normalizeRecoveredMime(mime, extension) {
  const clean = String(mime || '').split(';')[0].toLowerCase();
  if (/^(image|video)\//.test(clean)) return clean;
  const types = {
    gif: 'image/gif', webp: 'image/webp', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg',
    mp4: 'video/mp4', webm: 'video/webm', mov: 'video/quicktime'
  };
  return types[String(extension || '').toLowerCase()] || 'image/gif';
}

async function storeMediaBatch(items, page) {
  if (!Array.isArray(items) || items.length === 0) {
    return { ok: true, saved: [], skipped: 0, failed: [] };
  }

  const unique = [...new Map(items.map((item) => [item.url, item])).values()];
  const saved = [];
  const failed = [];
  let skipped = 0;

  for (let index = 0; index < unique.length; index += 1) {
    const candidate = unique[index];
    try {
      const id = await sha256(candidate.url);
      const existing = await getMedia(id);
      if (existing) {
        skipped += 1;
        saved.push({ id, existing: true });
        continue;
      }

      const response = await fetch(candidate.url, {
        credentials: 'include',
        cache: 'no-cache',
        referrer: page.url || 'https://www.threads.com/'
      });
      if (!response.ok) throw new Error(`下載來源回應 ${response.status}`);

      const blob = await response.blob();
      if (!blob.size) throw new Error('來源檔案大小為 0');

      const contentHash = await sha256Blob(blob);
      const existingItems = await getAllMedia();
      const sameContent = existingItems.find((item) => item.contentHash && item.contentHash === contentHash);
      if (sameContent) {
        skipped += 1;
        saved.push({ id: sameContent.id, existing: true });
        continue;
      }

      const mime = normalizeMime(blob.type, candidate.kind, candidate.url);
      const extension = extensionFromMime(mime, candidate.url);
      const capturedAt = new Date().toISOString();
      const item = {
        id,
        blob: blob.type === mime ? blob : blob.slice(0, blob.size, mime),
        mime,
        extension,
        bytes: blob.size,
        kind: mime.startsWith('video/') ? 'video' : 'image',
        sourceUrl: candidate.url,
        sourcePage: page.url || '',
        pageTitle: page.title || 'Threads 貼文',
        author: page.author || '',
        capturedAt,
        filename: buildFilename(page, index + 1, extension),
        contentHash
      };
      await putMedia(item);
      saved.push({ id, existing: false });
    } catch (error) {
      failed.push({ url: candidate.url, error: friendlyError(error) });
    }
  }

  const all = await getAllMedia();
  chrome.action.setBadgeText({ text: all.length ? String(Math.min(all.length, 999)) : '' });
  return { ok: failed.length !== unique.length, saved, skipped, failed };
}


async function sha256Blob(blob) {
  const buffer = await blob.arrayBuffer();
  const digest = await crypto.subtle.digest('SHA-256', buffer);
  return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, '0')).join('');
}

async function sha256(value) {
  const data = new TextEncoder().encode(value);
  const digest = await crypto.subtle.digest('SHA-256', data);
  return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, '0')).join('');
}

function normalizeMime(mime, kind, url) {
  const clean = (mime || '').split(';')[0].toLowerCase();
  if (/^(image|video)\//.test(clean)) return clean;
  const lower = url.toLowerCase();
  if (/\.gif(?:$|[?#])/.test(lower)) return 'image/gif';
  if (/\.webp(?:$|[?#])/.test(lower)) return 'image/webp';
  if (/\.webm(?:$|[?#])/.test(lower)) return 'video/webm';
  if (/\.mov(?:$|[?#])/.test(lower)) return 'video/quicktime';
  return kind === 'video' ? 'video/mp4' : 'image/gif';
}

function extensionFromMime(mime, url) {
  const types = {
    'image/gif': 'gif',
    'image/webp': 'webp',
    'image/png': 'png',
    'image/jpeg': 'jpg',
    'video/mp4': 'mp4',
    'video/webm': 'webm',
    'video/quicktime': 'mov'
  };
  if (types[mime]) return types[mime];
  const match = url.match(/\.([a-z0-9]{2,5})(?:$|[?#])/i);
  return match ? match[1].toLowerCase() : 'bin';
}

function buildFilename(page, index, extension) {
  const date = new Date().toISOString().slice(0, 10).replaceAll('-', '');
  const author = sanitizeFilename(page.author || 'threads');
  return `${date}_${author}_${String(index).padStart(2, '0')}.${extension}`;
}

function sanitizeFilename(value) {
  return String(value).replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').replace(/\s+/g, '_').slice(0, 60) || 'threads';
}

function friendlyError(error) {
  if (error?.name === 'QuotaExceededError') return '本機收藏空間不足，請先刪除部分舊收藏。';
  return error?.message || String(error || '未知錯誤');
}
