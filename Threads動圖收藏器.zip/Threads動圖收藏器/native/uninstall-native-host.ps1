$ErrorActionPreference = "Stop"
$hostName = "com.cjcu.threads_line_clipboard"
$registryPath = "HKCU:\Software\Google\Chrome\NativeMessagingHosts\$hostName"
$installDirectory = Join-Path $env:LOCALAPPDATA "ThreadsMotionClipboardHost"

if (Test-Path $registryPath) { Remove-Item $registryPath -Recurse -Force }
if (Test-Path $installDirectory) { Remove-Item $installDirectory -Recurse -Force }
Write-Host "LINE auto-paste bridge removed." -ForegroundColor Green
