﻿$ErrorActionPreference = "Stop"

$hostName = "com.cjcu.threads_line_clipboard"
$extensionId = "ggkdbfgodkiebjfoofbdhebgaikjalkl"
$installDirectory = Join-Path $env:LOCALAPPDATA "ThreadsMotionClipboardHost"
$sourceFile = Join-Path $PSScriptRoot "native-host.cs"
$executableFile = Join-Path $installDirectory "threads-line-host.exe"
$manifestFile = Join-Path $installDirectory "$hostName.json"
$registryPath = "HKCU:\Software\Google\Chrome\NativeMessagingHosts\$hostName"

function Stop-ThreadsNativeHost {
    # Temporarily unregister first so Chrome cannot immediately start another host while updating.
    if (Test-Path $registryPath) {
        Remove-Item $registryPath -Recurse -Force -ErrorAction SilentlyContinue
    }

    for ($attempt = 1; $attempt -le 10; $attempt++) {
        Get-Process -Name "threads-line-host" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
        Start-Sleep -Milliseconds 250
        $running = Get-Process -Name "threads-line-host" -ErrorAction SilentlyContinue
        if (-not $running) { return }
    }

    throw "Unable to stop threads-line-host.exe. Please close Chrome and run the installer again."
}

function Remove-OldExecutable {
    if (-not (Test-Path $executableFile)) { return }

    for ($attempt = 1; $attempt -le 12; $attempt++) {
        try {
            Remove-Item $executableFile -Force -ErrorAction Stop
            return
        }
        catch {
            Get-Process -Name "threads-line-host" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
            Start-Sleep -Milliseconds 300
        }
    }

    throw "Unable to replace threads-line-host.exe because the file is still in use. Please close Chrome and run the installer again."
}

Write-Host "Updating Threads LINE bridge..."
Stop-ThreadsNativeHost
New-Item -ItemType Directory -Path $installDirectory -Force | Out-Null
Remove-OldExecutable

function Try-ResolveUiAutomationAssembly([string]$assemblyName) {
    $runtimeDirectory = [System.Runtime.InteropServices.RuntimeEnvironment]::GetRuntimeDirectory()
    $candidates = @(
        (Join-Path $runtimeDirectory ("WPF\" + $assemblyName)),
        (Join-Path $env:WINDIR ("Microsoft.NET\Framework64\v4.0.30319\WPF\" + $assemblyName)),
        (Join-Path $env:WINDIR ("Microsoft.NET\Framework\v4.0.30319\WPF\" + $assemblyName))
    )

    foreach ($candidate in $candidates) {
        if ($candidate -and (Test-Path $candidate)) {
            return (Resolve-Path $candidate).Path
        }
    }

    try {
        $assembly = [System.Reflection.Assembly]::LoadWithPartialName([System.IO.Path]::GetFileNameWithoutExtension($assemblyName))
        if ($assembly -and $assembly.Location -and (Test-Path $assembly.Location)) {
            return $assembly.Location
        }
    }
    catch { }

    return $null
}

$uiAutomationClient = Try-ResolveUiAutomationAssembly "UIAutomationClient.dll"
$uiAutomationTypes = Try-ResolveUiAutomationAssembly "UIAutomationTypes.dll"
$uiAutomationAvailable = ($null -ne $uiAutomationClient -and $null -ne $uiAutomationTypes)

# UI Automation is optional. The host loads it dynamically when available.
# If unavailable, video sending still works and uses a conservative timed cleanup.
Add-Type `
    -Path $sourceFile `
    -OutputAssembly $executableFile `
    -OutputType ConsoleApplication `
    -ReferencedAssemblies @("System.dll", "System.Core.dll", "System.Windows.Forms.dll", "System.Web.Extensions.dll")

if ($uiAutomationAvailable) {
    Write-Host "UI Automation detected: upload completion monitoring enabled." -ForegroundColor Green
}
else {
    Write-Host "UI Automation not found: video sending will use timed temporary-file cleanup." -ForegroundColor Yellow
}

$manifest = [ordered]@{
    name = $hostName
    description = "Threads Motion Clipboard bridge for LINE Desktop"
    path = $executableFile
    type = "stdio"
    allowed_origins = @("chrome-extension://$extensionId/")
} | ConvertTo-Json -Depth 4

[System.IO.File]::WriteAllText($manifestFile, $manifest, (New-Object System.Text.UTF8Encoding($false)))
New-Item -Path $registryPath -Force | Out-Null
Set-Item -Path $registryPath -Value $manifestFile

Write-Host ""
Write-Host "Installation completed." -ForegroundColor Green
Write-Host "The old bridge process was stopped automatically before updating."
Write-Host "Please close and reopen Chrome once, then open the extension library."
Write-Host "Extension ID: $extensionId"
