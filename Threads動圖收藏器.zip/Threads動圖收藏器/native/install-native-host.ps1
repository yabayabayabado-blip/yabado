$ErrorActionPreference = "Stop"

$hostName = "com.cjcu.threads_line_clipboard"
$extensionId = "ggkdbfgodkiebjfoofbdhebgaikjalkl"
$installDirectory = Join-Path $env:LOCALAPPDATA "ThreadsMotionClipboardHost"
$sourceFile = Join-Path $PSScriptRoot "native-host.cs"
$executableFile = Join-Path $installDirectory "threads-line-host.exe"
$manifestFile = Join-Path $installDirectory "$hostName.json"
$registryPath = "HKCU:\Software\Google\Chrome\NativeMessagingHosts\$hostName"

New-Item -ItemType Directory -Path $installDirectory -Force | Out-Null
if (Test-Path $executableFile) { Remove-Item $executableFile -Force }

Add-Type `
    -Path $sourceFile `
    -OutputAssembly $executableFile `
    -OutputType ConsoleApplication `
    -ReferencedAssemblies @("System.dll", "System.Core.dll", "System.Windows.Forms.dll", "System.Web.Extensions.dll")

$manifest = [ordered]@{
    name = $hostName
    description = "Threads Motion Clipboard bridge for LINE Desktop"
    path = $executableFile
    type = "stdio"
    allowed_origins = @("chrome-extension://$extensionId/")
} | ConvertTo-Json -Depth 4

[System.IO.File]::WriteAllText($manifestFile, $manifest, (New-Object System.Text.UTF8Encoding($false)))
New-Item -Path $registryPath -Force | Out-Null
Set-Item -Path $registryPath -Value $manifestFile

Write-Host ""
Write-Host "Installation completed." -ForegroundColor Green
Write-Host "Please close and reopen Chrome, then open the extension library."
Write-Host "Extension ID: $extensionId"
