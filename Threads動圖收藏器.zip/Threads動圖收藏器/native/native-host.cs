using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Forms;

internal static class ThreadsLineHost
{
    private const int MaxMessageBytes = 64 * 1024 * 1024;
    private const int MaxFileBytes = 45 * 1024 * 1024;
    private const long MaxTransferBytes = 1024L * 1024L * 1024L;
    private static readonly JavaScriptSerializer Json = new JavaScriptSerializer { MaxJsonLength = MaxMessageBytes };
    private delegate bool EnumWindowsCallback(IntPtr hWnd, IntPtr lParam);

    private sealed class LineWindowInfo
    {
        public string id { get; set; }
        public string title { get; set; }
    }

    [DllImport("user32.dll")]
    private static extern bool EnumWindows(EnumWindowsCallback callback, IntPtr lParam);

    [DllImport("user32.dll")]
    private static extern bool IsWindow(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern bool IsWindowVisible(IntPtr hWnd);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int GetWindowTextLength(IntPtr hWnd);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int maxCount);

    [DllImport("user32.dll")]
    private static extern bool SetForegroundWindow(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);

    [DllImport("user32.dll")]
    private static extern IntPtr GetForegroundWindow();

    [DllImport("user32.dll", EntryPoint = "GetWindowThreadProcessId")]
    private static extern uint GetWindowThreadIdForFocus(IntPtr hWnd, IntPtr processId);

    [DllImport("user32.dll", EntryPoint = "GetWindowThreadProcessId")]
    private static extern uint GetWindowThreadIdAndProcess(IntPtr hWnd, out uint processId);

    [DllImport("kernel32.dll")]
    private static extern uint GetCurrentThreadId();

    [DllImport("user32.dll")]
    private static extern bool AttachThreadInput(uint idAttach, uint idAttachTo, bool attach);

    [DllImport("user32.dll")]
    private static extern bool BringWindowToTop(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern IntPtr SetFocus(IntPtr hWnd);

    [STAThread]
    private static void Main()
    {
        try
        {
            Dictionary<string, object> request = ReadMessage();
            string action = GetString(request, "action");
            if (action == "ping")
            {
                List<LineWindowInfo> windows = GetLineWindows();
                WriteMessage(new { ok = true, version = "2.6.13", lineRunning = windows.Count > 0, windowCount = windows.Count });
                return;
            }
            if (action == "list_line_windows") { ListLineWindows(); return; }
            if (action == "copy_file") { CopyFile(request); return; }
            if (action == "open_folder") { OpenFolder(request); return; }
            if (action == "read_file") { ReadFile(request); return; }
            if (action == "list_folder") { ListFolder(request); return; }
            if (action == "delete_file") { DeleteFile(request); return; }
            if (action == "paste_file") { PasteFile(request); return; }
            if (action == "paste_and_send_file") { PasteAndSendFile(request); return; }
            if (action == "begin_temp_transfer") { BeginTempTransfer(request); return; }
            if (action == "append_temp_chunk") { AppendTempChunk(request); return; }
            if (action == "send_temp_file") { SendTempFile(request); return; }
            if (action == "cancel_temp_transfer") { CancelTempTransfer(request); return; }
            if (action == "send_enter_and_clear") { SendEnterAndClear(request); return; }
            if (action == "clear_clipboard") { ClearClipboard(); WriteMessage(new { ok = true, cleared = true }); return; }
            throw new InvalidOperationException("unsupported_action");
        }
        catch (Exception error)
        {
            WriteMessage(new { ok = false, error = error.Message });
        }
    }

    private static void ReadFile(Dictionary<string, object> request)
    {
        string filePath = GetString(request, "filePath");
        if (string.IsNullOrWhiteSpace(filePath)) throw new InvalidOperationException("file_path_missing");
        filePath = Path.GetFullPath(filePath);
        string normalized = filePath.Replace('/', '\\');
        string marker = "\\Threads動圖\\";
        if (normalized.IndexOf(marker, StringComparison.OrdinalIgnoreCase) < 0)
            throw new InvalidOperationException("file_path_not_allowed");
        if (!File.Exists(filePath)) throw new InvalidOperationException("file_not_found");
        FileInfo info = new FileInfo(filePath);
        if (info.Length <= 0) throw new InvalidOperationException("empty_file");
        if (info.Length > MaxFileBytes) throw new InvalidOperationException("file_too_large");
        byte[] bytes = File.ReadAllBytes(filePath);
        WriteMessage(new { ok = true, base64 = Convert.ToBase64String(bytes), bytes = bytes.Length, filename = Path.GetFileName(filePath) });
    }


    private static void ListFolder(Dictionary<string, object> request)
    {
        string folderPath = GetString(request, "folderPath");
        if (string.IsNullOrWhiteSpace(folderPath)) throw new InvalidOperationException("folder_path_missing");
        folderPath = Path.GetFullPath(folderPath);
        string folderName = Path.GetFileName(folderPath.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar));
        if (!string.Equals(folderName, "Threads動圖", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("folder_path_not_allowed");
        if (!Directory.Exists(folderPath)) throw new InvalidOperationException("folder_not_found");

        string[] allowed = { ".gif", ".png", ".webp", ".jpg", ".jpeg", ".mp4", ".webm", ".mov" };
        var files = Directory.EnumerateFiles(folderPath, "*", SearchOption.TopDirectoryOnly)
            .Where(path => allowed.Contains(Path.GetExtension(path).ToLowerInvariant()))
            .Select(path => new FileInfo(path))
            .Where(info => info.Exists && info.Length > 0 && info.Length <= MaxFileBytes)
            .OrderBy(info => info.Name, StringComparer.OrdinalIgnoreCase)
            .Select(info => new {
                path = info.FullName,
                filename = info.Name,
                bytes = info.Length,
                modifiedAt = info.LastWriteTimeUtc.ToString("o")
            })
            .ToArray();

        WriteMessage(new { ok = true, folderPath = folderPath, files = files });
    }

    private static void DeleteFile(Dictionary<string, object> request)
    {
        string filePath = GetString(request, "filePath");
        if (string.IsNullOrWhiteSpace(filePath)) throw new InvalidOperationException("file_path_missing");
        filePath = Path.GetFullPath(filePath);
        string parent = Path.GetDirectoryName(filePath) ?? "";
        string folderName = Path.GetFileName(parent.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar));
        if (!string.Equals(folderName, "Threads動圖", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("file_path_not_allowed");
        if (!File.Exists(filePath))
        {
            WriteMessage(new { ok = true, deleted = false, missing = true, filePath = filePath });
            return;
        }
        File.Delete(filePath);
        WriteMessage(new { ok = true, deleted = true, filePath = filePath });
    }

    private static void OpenFolder(Dictionary<string, object> request)
    {
        string folderPath = GetString(request, "folderPath");
        if (string.IsNullOrWhiteSpace(folderPath)) throw new InvalidOperationException("folder_path_missing");
        folderPath = Path.GetFullPath(folderPath);
        if (!Directory.Exists(folderPath)) throw new InvalidOperationException("folder_not_found");
        Process.Start(new ProcessStartInfo
        {
            FileName = "explorer.exe",
            Arguments = "\"" + folderPath + "\"",
            UseShellExecute = true
        });
        WriteMessage(new { ok = true, opened = true, folderPath = folderPath });
    }

    private static void PasteFile(Dictionary<string, object> request)
    {
        IntPtr lineWindow = ResolveLineWindow(request);
        string filePath = SaveTemporaryFile(request);
        SetClipboardFile(filePath);
        if (!FocusLineWindow(lineWindow)) throw new InvalidOperationException("line_focus_failed");
        Thread.Sleep(180);
        SendKeys.SendWait("^v");
        Thread.Sleep(320);
        if (GetBoolean(request, "confirmImageMode"))
        {
            // LINE 第一次貼上會詢問要貼「圖片」或「文字」，預設焦點為圖片。
            SendKeys.SendWait("{ENTER}");
            Thread.Sleep(320);
        }
        WriteMessage(new { ok = true, pasted = true, bytes = new FileInfo(filePath).Length });
    }

    private static void PasteAndSendFile(Dictionary<string, object> request)
    {
        IntPtr lineWindow = ResolveLineWindow(request);
        string filePath = SaveTemporaryFile(request);
        SetClipboardFile(filePath);
        if (!FocusLineWindow(lineWindow)) throw new InvalidOperationException("line_focus_failed");

        // 每一張都完整走完 LINE 的貼圖流程：貼上 -> Enter 選擇「圖片」 -> Enter 送出。
        Thread.Sleep(220);
        SendKeys.SendWait("^v");
        Thread.Sleep(420);
        SendKeys.SendWait("{ENTER}");
        Thread.Sleep(520);
        SendKeys.SendWait("{ENTER}");
        Thread.Sleep(700);

        WriteMessage(new { ok = true, pasted = true, sent = true, bytes = new FileInfo(filePath).Length });
    }

    private static void CopyFile(Dictionary<string, object> request)
    {
        string filePath = SaveTemporaryFile(request);
        SetClipboardFile(filePath);
        WriteMessage(new { ok = true, copied = true, bytes = new FileInfo(filePath).Length });
    }

    private static void SendEnterAndClear(Dictionary<string, object> request)
    {
        IntPtr lineWindow = ResolveLineWindow(request);
        if (!FocusLineWindow(lineWindow)) throw new InvalidOperationException("line_focus_failed");
        Thread.Sleep(180);
        SendKeys.SendWait("{ENTER}");
        Thread.Sleep(260);
        ClearClipboard();
        WriteMessage(new { ok = true, sent = true, cleared = true });
    }

    private static string GetTempDirectory()
    {
        string tempDirectory = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "ThreadsMotionClipboardHost",
            "Temp"
        );
        Directory.CreateDirectory(tempDirectory);
        CleanOldFiles(tempDirectory);
        return tempDirectory;
    }

    private static string SanitizeTransferId(string value)
    {
        string raw = value ?? string.Empty;
        string clean = new string(raw.Where(c => char.IsLetterOrDigit(c) || c == '_' || c == '-').ToArray());
        if (clean.Length < 8 || clean.Length > 120) throw new InvalidOperationException("invalid_transfer_id");
        return clean;
    }

    private static string GetTransferPath(string transferId)
    {
        string id = SanitizeTransferId(transferId);
        string directory = GetTempDirectory();
        string[] files = Directory.GetFiles(directory, id + ".*");
        if (files.Length == 0) throw new InvalidOperationException("transfer_not_found");
        return files[0];
    }

    private static void BeginTempTransfer(Dictionary<string, object> request)
    {
        string transferId = SanitizeTransferId(GetString(request, "transferId"));
        string requestedName = Path.GetFileName(GetString(request, "filename"));
        string extension = Path.GetExtension(requestedName).ToLowerInvariant();
        string[] allowed = { ".gif", ".png", ".webp", ".jpg", ".jpeg", ".mp4", ".webm", ".mov" };
        if (!allowed.Contains(extension)) throw new InvalidOperationException("unsupported_media_format");
        long expectedBytes = 0;
        object rawExpected;
        if (request.TryGetValue("expectedBytes", out rawExpected) && rawExpected != null)
            long.TryParse(Convert.ToString(rawExpected), out expectedBytes);
        if (expectedBytes <= 0) throw new InvalidOperationException("empty_file");
        if (expectedBytes > MaxTransferBytes) throw new InvalidOperationException("transfer_too_large");

        string directory = GetTempDirectory();
        foreach (string old in Directory.GetFiles(directory, transferId + ".*"))
        {
            try { File.Delete(old); } catch { }
        }
        string filePath = Path.Combine(directory, transferId + extension);
        using (FileStream stream = new FileStream(filePath, FileMode.CreateNew, FileAccess.Write, FileShare.Read)) { }
        WriteMessage(new { ok = true, transferId = transferId, expectedBytes = expectedBytes });
    }

    private static void AppendTempChunk(Dictionary<string, object> request)
    {
        string transferId = SanitizeTransferId(GetString(request, "transferId"));
        string filePath = GetTransferPath(transferId);
        string base64 = GetString(request, "base64");
        byte[] bytes = Convert.FromBase64String(base64);
        if (bytes.Length == 0) throw new InvalidOperationException("empty_chunk");
        FileInfo before = new FileInfo(filePath);
        if (before.Length + bytes.LongLength > MaxTransferBytes) throw new InvalidOperationException("transfer_too_large");
        using (FileStream stream = new FileStream(filePath, FileMode.Append, FileAccess.Write, FileShare.Read))
        {
            stream.Write(bytes, 0, bytes.Length);
        }
        WriteMessage(new { ok = true, bytes = new FileInfo(filePath).Length });
    }

    private static void SendTempFile(Dictionary<string, object> request)
    {
        string transferId = SanitizeTransferId(GetString(request, "transferId"));
        string filePath = GetTransferPath(transferId);
        if (!File.Exists(filePath) || new FileInfo(filePath).Length <= 0) throw new InvalidOperationException("empty_file");
        IntPtr lineWindow = ResolveLineWindow(request);
        try
        {
            SetClipboardFile(filePath);
            if (!FocusLineWindow(lineWindow)) throw new InvalidOperationException("line_focus_failed");
            Thread.Sleep(220);
            SendKeys.SendWait("^v");
            Thread.Sleep(420);
            SendKeys.SendWait("{ENTER}");
            Thread.Sleep(520);
            SendKeys.SendWait("{ENTER}");
            Thread.Sleep(1200);
            try { ClearClipboard(); } catch { }
            long bytes = new FileInfo(filePath).Length;
            WriteMessage(new { ok = true, pasted = true, sent = true, bytes = bytes });
        }
        finally
        {
            try { if (File.Exists(filePath)) File.Delete(filePath); } catch { }
        }
    }

    private static void CancelTempTransfer(Dictionary<string, object> request)
    {
        string transferId = SanitizeTransferId(GetString(request, "transferId"));
        string directory = GetTempDirectory();
        bool deleted = false;
        foreach (string path in Directory.GetFiles(directory, transferId + ".*"))
        {
            try { File.Delete(path); deleted = true; } catch { }
        }
        WriteMessage(new { ok = true, deleted = deleted });
    }

    private static string SaveTemporaryFile(Dictionary<string, object> request)
    {
        string base64 = GetString(request, "base64");
        byte[] bytes = Convert.FromBase64String(base64);
        if (bytes.Length == 0) throw new InvalidOperationException("empty_file");
        if (bytes.Length > MaxFileBytes) throw new InvalidOperationException("file_too_large");

        string requestedName = Path.GetFileName(GetString(request, "filename"));
        string extension = Path.GetExtension(requestedName).ToLowerInvariant();
        string[] allowed = { ".gif", ".png", ".webp", ".jpg", ".jpeg", ".mp4", ".webm", ".mov" };
        if (!allowed.Contains(extension)) extension = ".gif";
        string tempDirectory = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "ThreadsMotionClipboardHost",
            "Temp"
        );
        Directory.CreateDirectory(tempDirectory);
        CleanOldFiles(tempDirectory);
        string filePath = Path.Combine(tempDirectory, "threads_" + DateTime.Now.ToString("yyyyMMdd_HHmmss_fff") + extension);
        File.WriteAllBytes(filePath, bytes);
        return filePath;
    }

    private static bool FocusLineWindow(IntPtr lineWindow)
    {
        ShowWindowAsync(lineWindow, 9);
        IntPtr foreground = GetForegroundWindow();
        uint foregroundThread = GetWindowThreadIdForFocus(foreground, IntPtr.Zero);
        uint currentThread = GetCurrentThreadId();
        bool attached = false;
        try
        {
            if (foregroundThread != 0 && foregroundThread != currentThread)
                attached = AttachThreadInput(currentThread, foregroundThread, true);
            BringWindowToTop(lineWindow);
            SetForegroundWindow(lineWindow);
            SetFocus(lineWindow);
        }
        finally
        {
            if (attached) AttachThreadInput(currentThread, foregroundThread, false);
        }
        Thread.Sleep(120);
        return GetForegroundWindow() == lineWindow;
    }

    private static void ListLineWindows()
    {
        List<LineWindowInfo> windows = GetLineWindows();
        WriteMessage(new { ok = true, windows = windows.ToArray(), windowCount = windows.Count });
    }

    private static List<LineWindowInfo> GetLineWindows()
    {
        HashSet<int> processIds = new HashSet<int>(Process.GetProcessesByName("LINE").Select(item => item.Id));
        List<LineWindowInfo> windows = new List<LineWindowInfo>();
        if (processIds.Count == 0) return windows;

        EnumWindows(delegate (IntPtr hWnd, IntPtr lParam)
        {
            if (!IsWindowVisible(hWnd)) return true;
            uint processId;
            GetWindowThreadIdAndProcess(hWnd, out processId);
            if (!processIds.Contains((int)processId)) return true;
            int length = GetWindowTextLength(hWnd);
            if (length <= 0) return true;
            StringBuilder title = new StringBuilder(length + 1);
            GetWindowText(hWnd, title, title.Capacity);
            string value = title.ToString().Trim();
            if (value.Length == 0) return true;
            // LINE 主視窗標題只有 "LINE"，不是實際聊天室，不列入送圖選單。
            if (string.Equals(value, "LINE", StringComparison.OrdinalIgnoreCase)) return true;
            windows.Add(new LineWindowInfo { id = hWnd.ToInt64().ToString(), title = value });
            return true;
        }, IntPtr.Zero);

        return windows.OrderBy(item => item.title, StringComparer.CurrentCultureIgnoreCase).ToList();
    }

    private static IntPtr ResolveLineWindow(Dictionary<string, object> request)
    {
        long rawHandle;
        if (!long.TryParse(GetString(request, "windowId"), out rawHandle)) throw new InvalidOperationException("line_window_closed");
        IntPtr hWnd = new IntPtr(rawHandle);
        if (!IsWindow(hWnd) || !IsWindowVisible(hWnd)) throw new InvalidOperationException("line_window_closed");
        uint processId;
        GetWindowThreadIdAndProcess(hWnd, out processId);
        try
        {
            Process process = Process.GetProcessById((int)processId);
            if (!string.Equals(process.ProcessName, "LINE", StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("line_window_closed");
        }
        catch (ArgumentException)
        {
            throw new InvalidOperationException("line_window_closed");
        }
        return hWnd;
    }

    private static void SetClipboardFile(string filePath)
    {
        Exception lastError = null;
        for (int attempt = 0; attempt < 8; attempt++)
        {
            try
            {
                StringCollection files = new StringCollection();
                files.Add(filePath);
                Clipboard.SetFileDropList(files);
                return;
            }
            catch (Exception error)
            {
                lastError = error;
                Thread.Sleep(120);
            }
        }
        throw new InvalidOperationException("clipboard_busy", lastError);
    }

    private static void ClearClipboard()
    {
        Exception lastError = null;
        for (int attempt = 0; attempt < 8; attempt++)
        {
            try
            {
                Clipboard.Clear();
                return;
            }
            catch (Exception error)
            {
                lastError = error;
                Thread.Sleep(120);
            }
        }
        throw new InvalidOperationException("clipboard_clear_failed", lastError);
    }

    private static void CleanOldFiles(string directory)
    {
        DateTime limit = DateTime.Now.AddDays(-1);
        foreach (string file in Directory.GetFiles(directory, "threads_*"))
        {
            try { if (File.GetLastWriteTime(file) < limit) File.Delete(file); }
            catch { }
        }
    }

    private static Dictionary<string, object> ReadMessage()
    {
        Stream input = Console.OpenStandardInput();
        byte[] lengthBytes = ReadExactly(input, 4);
        int length = BitConverter.ToInt32(lengthBytes, 0);
        if (length <= 0 || length > MaxMessageBytes) throw new InvalidOperationException("invalid_message_size");
        byte[] payload = ReadExactly(input, length);
        return Json.Deserialize<Dictionary<string, object>>(Encoding.UTF8.GetString(payload));
    }

    private static byte[] ReadExactly(Stream stream, int length)
    {
        byte[] buffer = new byte[length];
        int offset = 0;
        while (offset < length)
        {
            int read = stream.Read(buffer, offset, length - offset);
            if (read <= 0) throw new EndOfStreamException("message_incomplete");
            offset += read;
        }
        return buffer;
    }

    private static void WriteMessage(object value)
    {
        byte[] payload = Encoding.UTF8.GetBytes(Json.Serialize(value));
        Stream output = Console.OpenStandardOutput();
        byte[] length = BitConverter.GetBytes(payload.Length);
        output.Write(length, 0, length.Length);
        output.Write(payload, 0, payload.Length);
        output.Flush();
    }

    private static string GetString(Dictionary<string, object> values, string key)
    {
        object value;
        if (!values.TryGetValue(key, out value) || value == null) return string.Empty;
        return Convert.ToString(value);
    }

    private static bool GetBoolean(Dictionary<string, object> values, string key)
    {
        object value;
        if (!values.TryGetValue(key, out value) || value == null) return false;
        return Convert.ToBoolean(value);
    }
}
