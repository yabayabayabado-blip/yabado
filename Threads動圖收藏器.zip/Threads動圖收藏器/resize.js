async function createOutputBlob(item, contentScaleValue, onProgress = () => {}) {
  const contentScale = Number(contentScaleValue);
  if (!Number.isFinite(contentScale) || contentScale <= 0 || contentScale > 1) throw new Error('輸出比例設定不正確。');
  if (contentScale === 1 && item.mime === 'image/gif') {
    return { blob: item.blob, extension: 'gif', converted: false };
  }

  onProgress('正在解析動畫…');
  if (item.kind === 'video' || item.mime.startsWith('video/')) {
    return { blob: await resizeVideoToGif(item.blob, contentScale, onProgress), extension: 'gif', converted: true };
  }
  if (item.mime === 'image/gif' || item.mime === 'image/webp') {
    return { blob: await resizeAnimatedImageToGif(item.blob, item.mime, contentScale, onProgress), extension: 'gif', converted: true };
  }
  return { blob: await resizeStaticImageToPng(item.blob, contentScale), extension: 'png', converted: true };
}

async function resizeAnimatedImageToGif(blob, mime, contentScale, onProgress) {
  if (mime === 'image/gif' && window.gifuct) {
    return decodeGifWithGifuct(blob, contentScale, onProgress);
  }
  if ('ImageDecoder' in window) {
    return decodeWithImageDecoder(blob, mime, contentScale, onProgress);
  }
  throw new Error('目前的 Chrome 無法解碼這個動圖格式。');
}

async function decodeWithImageDecoder(blob, mime, contentScale, onProgress) {
  const decoder = new ImageDecoder({ data: blob.stream(), type: mime });
  await decoder.tracks.ready;
  const track = decoder.tracks.selectedTrack;
  if (!track) throw new Error('讀不到動圖影格。');

  const frameCount = Math.max(1, track.frameCount || 1);
  const first = await decoder.decode({ frameIndex: 0, completeFramesOnly: true });
  const sourceWidth = first.image.displayWidth || first.image.codedWidth;
  const sourceHeight = first.image.displayHeight || first.image.codedHeight;
  const layout = calculateLayout(sourceWidth, sourceHeight, contentScale);
  const encoder = createGifEncoder();
  const canvas = createTransparentCanvas(layout.canvasWidth, layout.canvasHeight);
  const ctx = canvas.getContext('2d', { alpha: true, willReadFrequently: true });

  for (let index = 0; index < frameCount; index += 1) {
    const result = index === 0 ? first : await decoder.decode({ frameIndex: index, completeFramesOnly: true });
    drawTransparentFrame(ctx, result.image, layout);
    writeGifFrame(encoder, ctx, layout.canvasWidth, layout.canvasHeight, normalizeDelay(result.image.duration / 1000));
    result.image.close();
    onProgress(`正在處理第 ${index + 1}／${frameCount} 格…`);
    if (index % 8 === 0) await yieldToUi();
  }
  decoder.close();
  return finishGif(encoder);
}

async function decodeGifWithGifuct(blob, contentScale, onProgress) {
  const parsed = window.gifuct.parseGIF(await blob.arrayBuffer());
  const frames = window.gifuct.decompressFrames(parsed, true);
  const sourceWidth = parsed.lsd.width;
  const sourceHeight = parsed.lsd.height;
  const layout = calculateLayout(sourceWidth, sourceHeight, contentScale);
  const encoder = createGifEncoder();
  const source = createTransparentCanvas(sourceWidth, sourceHeight);
  const sourceCtx = source.getContext('2d', { alpha: true, willReadFrequently: true });
  const patchCanvas = document.createElement('canvas');
  const out = createTransparentCanvas(layout.canvasWidth, layout.canvasHeight);
  const outCtx = out.getContext('2d', { alpha: true, willReadFrequently: true });
  let previous = null;
  let restoreImage = null;

  for (let index = 0; index < frames.length; index += 1) {
    if (previous?.disposalType === 2) sourceCtx.clearRect(previous.dims.left, previous.dims.top, previous.dims.width, previous.dims.height);
    else if (previous?.disposalType === 3 && restoreImage) sourceCtx.putImageData(restoreImage, 0, 0);

    const frame = frames[index];
    restoreImage = frame.disposalType === 3 ? sourceCtx.getImageData(0, 0, sourceWidth, sourceHeight) : null;
    patchCanvas.width = frame.dims.width;
    patchCanvas.height = frame.dims.height;
    const patchCtx = patchCanvas.getContext('2d', { alpha: true });
    patchCtx.clearRect(0, 0, patchCanvas.width, patchCanvas.height);
    patchCtx.putImageData(new ImageData(frame.patch, frame.dims.width, frame.dims.height), 0, 0);
    sourceCtx.drawImage(patchCanvas, frame.dims.left, frame.dims.top);
    drawTransparentFrame(outCtx, source, layout);
    writeGifFrame(encoder, outCtx, layout.canvasWidth, layout.canvasHeight, normalizeDelay(frame.delay));
    previous = frame;
    onProgress(`正在處理第 ${index + 1}／${frames.length} 格…`);
    if (index % 8 === 0) await yieldToUi();
  }
  return finishGif(encoder);
}

async function resizeVideoToGif(blob, contentScale, onProgress) {
  const video = document.createElement('video');
  video.muted = true;
  video.playsInline = true;
  video.preload = 'auto';
  const url = URL.createObjectURL(blob);
  video.src = url;
  try {
    await once(video, 'loadedmetadata');
    if (video.readyState < 2) await once(video, 'loadeddata');
    if (!Number.isFinite(video.duration) || video.duration <= 0) throw new Error('讀不到影片長度。');
    const duration = Math.min(video.duration, 15);
    const fps = duration <= 6 ? 12 : duration <= 10 ? 10 : 8;
    const frameCount = Math.max(2, Math.ceil(duration * fps));
    const layout = calculateLayout(video.videoWidth, video.videoHeight, contentScale);
    const encoder = createGifEncoder();
    const canvas = createTransparentCanvas(layout.canvasWidth, layout.canvasHeight);
    const ctx = canvas.getContext('2d', { alpha: true, willReadFrequently: true });

    for (let index = 0; index < frameCount; index += 1) {
      const time = Math.min(index / fps, Math.max(0, duration - 0.001));
      await seekVideo(video, time);
      drawTransparentFrame(ctx, video, layout);
      writeGifFrame(encoder, ctx, layout.canvasWidth, layout.canvasHeight, Math.round(1000 / fps));
      onProgress(`正在轉換第 ${index + 1}／${frameCount} 格…`);
      if (index % 5 === 0) await yieldToUi();
    }
    return finishGif(encoder);
  } finally {
    video.removeAttribute('src');
    video.load();
    URL.revokeObjectURL(url);
  }
}

async function resizeStaticImageToPng(blob, contentScale) {
  const bitmap = await createImageBitmap(blob);
  const layout = calculateLayout(bitmap.width, bitmap.height, contentScale);
  const canvas = createTransparentCanvas(layout.canvasWidth, layout.canvasHeight);
  const ctx = canvas.getContext('2d', { alpha: true, willReadFrequently: true });
  drawTransparentFrame(ctx, bitmap, layout);
  bitmap.close();
  return new Promise((resolve, reject) => canvas.toBlob((result) => result ? resolve(result) : reject(new Error('圖片輸出失敗。')), 'image/png'));
}

function calculateLayout(sourceWidth, sourceHeight, contentScale) {
  const canvasWidth = Math.max(1, Math.round(sourceWidth * contentScale));
  const canvasHeight = Math.max(1, Math.round(sourceHeight * contentScale));
  return {
    canvasWidth,
    canvasHeight,
    contentWidth: canvasWidth,
    contentHeight: canvasHeight,
    x: 0,
    y: 0
  };
}

function createTransparentCanvas(width, height) {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  return canvas;
}

function createGifEncoder() {
  if (!window.gifenc) throw new Error('GIF 編碼器載入失敗。');
  return window.gifenc.GIFEncoder();
}

function drawTransparentFrame(ctx, source, layout) {
  ctx.save();
  ctx.globalCompositeOperation = 'copy';
  ctx.clearRect(0, 0, layout.canvasWidth, layout.canvasHeight);
  ctx.globalCompositeOperation = 'source-over';
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(source, 0, 0, layout.canvasWidth, layout.canvasHeight);
  ctx.restore();
}

function writeGifFrame(encoder, ctx, width, height, delay) {
  const rgba = ctx.getImageData(0, 0, width, height).data;
  let transparentPixels = 0;
  for (let offset = 3; offset < rgba.length; offset += 4) if (rgba[offset] < 128) transparentPixels += 1;

  const hasTransparency = transparentPixels > 0;
  let palette;
  let index;
  let transparentIndex = 0;
  if (hasTransparency) {
    const opaque = new Uint8Array((width * height - transparentPixels) * 4);
    let target = 0;
    for (let offset = 0; offset < rgba.length; offset += 4) {
      if (rgba[offset + 3] < 128) continue;
      opaque[target++] = rgba[offset];
      opaque[target++] = rgba[offset + 1];
      opaque[target++] = rgba[offset + 2];
      opaque[target++] = 255;
    }
    const opaquePalette = opaque.length ? window.gifenc.quantize(opaque, 255, { format: 'rgb565' }) : [[0, 0, 0]];
    const opaqueIndex = window.gifenc.applyPalette(rgba, opaquePalette, 'rgb565');
    // GIF 邏輯畫布的背景色固定讀取色盤第 0 號。將透明白色固定在 0，
    // LINE 即使忽略透明索引也只會顯示白底；實體白色則使用偏移後的獨立索引，不會被挖空。
    palette = [[255, 255, 255], ...opaquePalette];
    transparentIndex = 0;
    index = new Uint8Array(width * height);
    for (let pixel = 0, offset = 3; offset < rgba.length; pixel += 1, offset += 4) {
      index[pixel] = rgba[offset] < 128 ? transparentIndex : opaqueIndex[pixel] + 1;
    }
  } else {
    palette = window.gifenc.quantize(rgba, 256, { format: 'rgb565' });
    index = window.gifenc.applyPalette(rgba, palette, 'rgb565');
  }
  encoder.writeFrame(index, width, height, { palette, delay, repeat: 0, dispose: 2, transparent: hasTransparency, transparentIndex });
}

function finishGif(encoder) {
  encoder.finish();
  return new Blob([encoder.bytes()], { type: 'image/gif' });
}

function normalizeDelay(value) {
  return Math.max(20, Math.min(10_000, Math.round(Number(value) || 100)));
}

function seekVideo(video, time) {
  if (Math.abs(video.currentTime - time) < 0.001 && video.readyState >= 2) return Promise.resolve();
  return new Promise((resolve, reject) => {
    const cleanup = () => { video.removeEventListener('seeked', done); video.removeEventListener('error', fail); };
    const done = () => { cleanup(); resolve(); };
    const fail = () => { cleanup(); reject(new Error('影片影格讀取失敗。')); };
    video.addEventListener('seeked', done, { once: true });
    video.addEventListener('error', fail, { once: true });
    video.currentTime = time;
  });
}

function once(target, eventName) {
  return new Promise((resolve, reject) => {
    const cleanup = () => { target.removeEventListener(eventName, done); target.removeEventListener('error', fail); };
    const done = () => { cleanup(); resolve(); };
    const fail = () => { cleanup(); reject(new Error('媒體載入失敗。')); };
    target.addEventListener(eventName, done, { once: true });
    target.addEventListener('error', fail, { once: true });
  });
}

function yieldToUi() {
  return new Promise((resolve) => setTimeout(resolve, 0));
}
