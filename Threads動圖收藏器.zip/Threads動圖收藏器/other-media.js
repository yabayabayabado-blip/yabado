const grid = document.querySelector('#grid');
const empty = document.querySelector('#empty');
const summary = document.querySelector('#summary');
const statusNode = document.querySelector('#status');
const template = document.querySelector('#cardTemplate');
const selectAllButton = document.querySelector('#selectAllButton');
const clearButton = document.querySelector('#clearButton');
const downloadButton = document.querySelector('#downloadButton');
const openFolderButton = document.querySelector('#openFolderButton');
const previewLevel = document.querySelector('#previewLevel');
const previewLevelLabel = document.querySelector('#previewLevelLabel');
const NATIVE_HOST = 'com.cjcu.threads_line_clipboard';
const selected = new Set();
let items = [];
let page = {};

selectAllButton.addEventListener('click', () => {
  const allSelected = items.length > 0 && selected.size === items.length;
  selected.clear();
  if (!allSelected) items.forEach((_, i) => selected.add(i));
  syncSelection();
});
clearButton.addEventListener('click', () => { selected.clear(); syncSelection(); });
downloadButton.addEventListener('click', downloadSelected);
openFolderButton.addEventListener('click', openOtherMediaFolder);
previewLevel.addEventListener('input', () => { applyPreviewLevel(); savePreviewSetting(); });
initialize();

async function initialize() {
  const stored = await chrome.storage.local.get({ threadsOtherMediaScan: {}, otherMediaPreviewLevel: '5' });
  previewLevel.value = stored.otherMediaPreviewLevel || '5';
  applyPreviewLevel();
  const scan = stored.threadsOtherMediaScan || {};
  items = Array.isArray(scan.items) ? scan.items : [];
  page = scan.page || {};
  render();
  await refineMediaTypes();
}


async function refineMediaTypes() {
  if (!items.length) return;
  showStatus(`正在確認媒體格式 0/${items.length}…`);
  const refined = [];
  for (let index = 0; index < items.length; index += 1) {
    const item = items[index];
    showStatus(`正在確認媒體格式 ${index + 1}/${items.length}…`);
    try {
      const response = await fetch(item.url, { credentials:'include', cache:'no-cache', referrer: page.url || 'https://www.threads.com/' });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const blob = await response.blob();
      const mime = String(blob.type || '').split(';')[0].toLowerCase();
      if (mime === 'image/gif') continue;
      let kind = item.kind;
      if (mime.startsWith('video/')) kind = 'video';
      else if (mime.startsWith('image/')) kind = 'image';
      refined.push({ ...item, kind, detectedMime: mime });
    } catch (_) {
      // 預覽仍可能可用；無法探測 MIME 時保留候選，實際下載時再驗證。
      refined.push(item);
    }
  }
  items = refined;
  selected.clear();
  render();
  showStatus(items.length ? `已確認 ${items.length} 個其他媒體。` : '目前貼文未找到 GIF 以外可下載的媒體。', items.length ? 'success' : '');
}

function applyPreviewLevel() {
  const level = Math.max(1, Math.min(10, Number(previewLevel.value) || 5));
  const sizes = [76, 92, 110, 132, 190, 220, 250, 280, 310, 340];
  const percentages = [20, 25, 30, 35, 50, 60, 70, 80, 90, 100];
  grid.style.setProperty('--card-size', `${sizes[level - 1]}px`);
  grid.classList.toggle('small-cards', level >= 5 && level <= 6);
  grid.classList.toggle('thumbnail-only', level <= 4);
  previewLevelLabel.textContent = `第${level}級（${percentages[level - 1]}%）`;
}

async function savePreviewSetting() {
  await chrome.storage.local.set({ otherMediaPreviewLevel: previewLevel.value });
}

function render() {
  grid.textContent = '';
  empty.hidden = items.length > 0;
  summary.textContent = items.length ? `共找到 ${items.length} 個 GIF 以外的媒體` : '未找到其他媒體';
  items.forEach((item, index) => {
    const node = template.content.firstElementChild.cloneNode(true);
    const input = node.querySelector('.selector');
    input.checked = selected.has(index);
    input.addEventListener('change', () => {
      if (input.checked) selected.add(index); else selected.delete(index);
      syncSelection();
    });
    const preview = node.querySelector('.preview');
    if (item.kind === 'video' || /\.(?:mp4|webm|mov)(?:$|[?#])/i.test(item.url || '')) {
      const video = document.createElement('video');
      video.src = item.url;
      video.controls = true;
      video.muted = true;
      video.playsInline = true;
      preview.append(video);
    } else {
      const img = document.createElement('img');
      img.src = item.url;
      img.alt = 'Threads 媒體預覽';
      preview.append(img);
    }
    const ext = (item.detectedMime ? extensionFromType(item.detectedMime, item.url) : guessExtensionFromUrl(item.url, item.kind)).toUpperCase();
    node.querySelector('.type').textContent = ext;
    node.querySelector('.name').textContent = shortUrlName(item.url);
    grid.append(node);
  });
  syncSelection();
}

function syncSelection() {
  const count = selected.size;
  downloadButton.disabled = count === 0;
  clearButton.disabled = count === 0;
  downloadButton.textContent = `下載已勾選 ${count} 個`;
  selectAllButton.textContent = items.length > 0 && count === items.length ? '取消全選' : '全選';
  [...grid.querySelectorAll('.selector')].forEach((input, index) => { input.checked = selected.has(index); });
}

async function downloadSelected() {
  const indexes = [...selected].sort((a,b) => a-b);
  if (!indexes.length) return;
  setBusy(true);
  let ok = 0;
  let failed = 0;
  for (let pos = 0; pos < indexes.length; pos += 1) {
    const index = indexes[pos];
    showStatus(`正在下載 ${pos + 1}/${indexes.length}…`);
    try {
      const item = items[index];
      const response = await fetch(item.url, { credentials:'include', cache:'no-cache', referrer: page.url || 'https://www.threads.com/' });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const blob = await response.blob();
      if (!blob.size) throw new Error('檔案大小為 0');
      const type = normalizeType(blob.type, item.kind, item.url);
      const ext = extensionFromType(type, item.url);
      if (ext === 'gif' || !['webp','png','jpg','mp4','webm','mov'].includes(ext)) throw new Error('不是支援的其他媒體格式');
      const objectUrl = URL.createObjectURL(blob.type === type ? blob : blob.slice(0, blob.size, type));
      try {
        await chrome.downloads.download({
          url: objectUrl,
          filename: `Threads其他媒體/${buildFilename(pos + 1, ext)}`,
          conflictAction: 'uniquify',
          saveAs: false
        });
      } finally {
        setTimeout(() => URL.revokeObjectURL(objectUrl), 60000);
      }
      ok += 1;
    } catch (_) { failed += 1; }
  }
  showStatus(`完成：下載 ${ok} 個${failed ? `，失敗 ${failed} 個` : ''}。`, failed ? 'error' : 'success');
  setBusy(false);
}

async function openOtherMediaFolder() {
  try {
    const downloads = await chrome.downloads.search({ orderBy:['-startTime'], limit:5000 });
    const marker = '/Threads其他媒體/';
    let folder = '';
    for (const item of downloads) {
      const full = String(item.filename || '');
      const normalized = full.replaceAll('\\','/');
      const at = normalized.toLowerCase().lastIndexOf(marker.toLowerCase());
      if (at >= 0) { folder = full.slice(0, at + marker.length - 1).replaceAll('/','\\'); break; }
    }
    if (folder) {
      const response = await nativeCall({ action:'open_folder', folderPath:folder });
      if (response?.ok) return;
    }
  } catch (_) { }
  chrome.downloads.showDefaultFolder();
}

function setBusy(busy) {
  downloadButton.disabled = busy || selected.size === 0;
  selectAllButton.disabled = busy;
  clearButton.disabled = busy || selected.size === 0;
  openFolderButton.disabled = busy;
}
function showStatus(message, kind='') { statusNode.textContent = message; statusNode.className = `status ${kind}`.trim(); }
function nativeCall(message) { return new Promise((resolve,reject) => chrome.runtime.sendNativeMessage(NATIVE_HOST,message,(response) => { if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message)); else resolve(response || null); })); }
function normalizeType(mime, kind, url) {
  const clean = String(mime || '').split(';')[0].toLowerCase();
  if (/^(image|video)\//.test(clean)) return clean;
  const ext = guessExtensionFromUrl(url, kind);
  const types = { webp:'image/webp', png:'image/png', jpg:'image/jpeg', mp4:'video/mp4', webm:'video/webm', mov:'video/quicktime' };
  return types[ext] || (kind === 'video' ? 'video/mp4' : 'image/jpeg');
}
function extensionFromType(mime, url) {
  const types = { 'image/webp':'webp','image/png':'png','image/jpeg':'jpg','video/mp4':'mp4','video/webm':'webm','video/quicktime':'mov','image/gif':'gif' };
  return types[mime] || guessExtensionFromUrl(url,'image');
}
function guessExtensionFromUrl(url, kind) {
  const match = String(url || '').match(/\.(webp|png|jpe?g|gif|mp4|webm|mov)(?:$|[?#])/i);
  if (match) return match[1].toLowerCase().replace('jpeg','jpg');
  const param = String(url || '').match(/(?:format|fm|ext)=(webp|png|jpe?g|gif|mp4|webm|mov)(?:&|$)/i);
  if (param) return param[1].toLowerCase().replace('jpeg','jpg');
  return kind === 'video' ? 'mp4' : 'jpg';
}
function buildFilename(index, ext) {
  const date = new Date().toISOString().slice(0,10).replaceAll('-','');
  const author = String(page.author || 'threads').replace(/[\\/:*?"<>|\u0000-\u001f]/g,'_').replace(/\s+/g,'_').slice(0,50) || 'threads';
  return `${date}_${author}_${String(index).padStart(2,'0')}.${ext}`;
}
function shortUrlName(url) { try { const u = new URL(url); return (u.pathname.split('/').pop() || u.hostname).slice(0,80); } catch (_) { return String(url || '').slice(0,80); } }
