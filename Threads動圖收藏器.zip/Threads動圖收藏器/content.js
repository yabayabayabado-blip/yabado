chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type !== 'SCAN_THREADS_MEDIA') return;
  try {
    const result = scanThreadsMedia();
    sendResponse({ ok: true, ...result });
  } catch (error) {
    sendResponse({ ok: false, error: error?.message || '掃描失敗' });
  }
});

function scanThreadsMedia() {
  const scope = findPrimaryPostScope();
  const found = new Map();
  let unresolvedVideos = 0;

  scope.querySelectorAll('video').forEach((video) => {
    if (!isGifLikeVideo(video)) return;
    const urls = [video.currentSrc, video.src, ...[...video.querySelectorAll('source')].map((source) => source.src)];
    const httpUrls = urls.filter(isHttpUrl);
    if (httpUrls.length === 0) unresolvedVideos += 1;
    httpUrls.forEach((url) => addCandidate(found, url, 'video', true));
  });

  scope.querySelectorAll('img').forEach((img) => {
    const urls = [img.currentSrc, img.src, ...parseSrcset(img.srcset)];
    urls.filter(isAnimatedImageUrl).forEach((url) => addCandidate(found, url, 'image'));
  });

  scope.querySelectorAll('picture source').forEach((source) => {
    [source.src, ...parseSrcset(source.srcset)]
      .filter(isAnimatedImageUrl)
      .forEach((url) => addCandidate(found, url, 'image'));
  });

  scope.querySelectorAll('[style]').forEach((node) => {
    const style = node.getAttribute('style') || '';
    for (const match of style.matchAll(/url\(["']?([^"')]+)["']?\)/gi)) {
      if (isAnimatedImageUrl(match[1])) addCandidate(found, match[1], 'image');
    }
  });

  // Threads 以影片承載 GIF 時，媒體 URL 有時只出現在已載入的資源清單。
  if (unresolvedVideos > 0) {
    performance.getEntriesByType('resource').forEach((entry) => {
      const url = entry.name || '';
      if (isLikelyMotionResource(url)) {
        const isVideo = /\.(?:mp4|webm|mov)(?:$|[?#])/i.test(url);
        addCandidate(found, url, isVideo ? 'video' : 'image', isVideo);
      }
    });
  }

  const canonical = document.querySelector('link[rel="canonical"]')?.href || location.href;
  const author = extractAuthor();
  return {
    items: [...found.values()],
    page: {
      url: canonical,
      title: document.title.replace(/\s*\|\s*Threads.*$/i, '').trim() || 'Threads 貼文',
      author
    }
  };
}

function findPrimaryPostScope() {
  const articles = [...document.querySelectorAll('main article')];
  if (articles.length) {
    const articleWithMedia = articles.find((article) => article.querySelector('video, img[src*=".gif"], img[src*=".webp"]'));
    return articleWithMedia || articles[0];
  }
  return document.querySelector('main') || document.body;
}

function extractAuthor() {
  const meta = document.querySelector('meta[property="og:title"]')?.content || '';
  const handle = meta.match(/@([\w.]+)/)?.[1];
  if (handle) return `@${handle}`;
  const pathHandle = location.pathname.match(/^\/@([^/]+)/)?.[1];
  return pathHandle ? `@${pathHandle}` : 'threads';
}

function parseSrcset(srcset) {
  if (!srcset) return [];
  return srcset.split(',').map((part) => part.trim().split(/\s+/)[0]).filter(Boolean);
}

function addCandidate(map, rawUrl, kind, motionHint = false) {
  try {
    const url = new URL(rawUrl, location.href).href;
    if (!map.has(url)) map.set(url, { url, kind, motionHint });
  } catch (_) {
    // 忽略無效 URL。
  }
}

function isGifLikeVideo(video) {
  const urls = [video.currentSrc, video.src, ...[...video.querySelectorAll('source')].map((source) => source.src)].filter(Boolean);
  if (urls.some((url) => /(?:gif|giphy)/i.test(url))) return true;

  const aria = [
    video.getAttribute('aria-label'),
    video.getAttribute('title'),
    video.closest('[aria-label]')?.getAttribute('aria-label')
  ].filter(Boolean).join(' ');
  if (/(?:\bgif\b|動圖)/i.test(aria)) return true;

  // Threads 會以無控制列、靜音、自動播放且循環的 video 承載 GIF。
  return Boolean(video.loop && video.autoplay && video.muted && !video.controls);
}

function isHttpUrl(value) {
  return /^https?:\/\//i.test(value || '');
}

function isAnimatedImageUrl(value) {
  if (!isHttpUrl(value)) return false;
  return /\.(?:gif|webp)(?:$|[?#])/i.test(value) || /(?:format|fm|ext)=(?:gif|webp)(?:&|$)/i.test(value);
}

function isLikelyMotionResource(value) {
  if (!isHttpUrl(value)) return false;
  return /\.(?:gif|webp|mp4|webm|mov)(?:$|[?#])/i.test(value) && /(?:threads|fbcdn|cdninstagram|giphy)/i.test(value);
}
