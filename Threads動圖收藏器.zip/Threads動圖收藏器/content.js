chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!['SCAN_THREADS_MEDIA', 'SCAN_THREADS_OTHER_MEDIA', 'SCAN_THREADS_ALL_MEDIA'].includes(message?.type)) return;
  try {
    const all = scanThreadsAllMedia();
    if (message.type === 'SCAN_THREADS_MEDIA') {
      sendResponse({ ok: true, items: all.items.filter(isMotionCandidate), page: all.page });
    } else if (message.type === 'SCAN_THREADS_OTHER_MEDIA') {
      sendResponse({ ok: true, items: all.items.filter((item) => !isObviousGif(item.url)), page: all.page });
    } else {
      sendResponse({ ok: true, ...all });
    }
  } catch (error) {
    sendResponse({ ok: false, error: error?.message || '掃描失敗' });
  }
});

function scanThreadsAllMedia() {
  const scope = findPrimaryPostScope();
  const found = new Map();

  scope.querySelectorAll('video').forEach((video) => {
    [video.currentSrc, video.src, ...[...video.querySelectorAll('source')].flatMap((source) => [source.src, ...parseSrcset(source.srcset)])]
      .filter(isHttpUrl)
      .forEach((url) => addCandidate(found, url, 'video'));
  });

  scope.querySelectorAll('img').forEach((img) => {
    const rect = img.getBoundingClientRect();
    const width = Number(img.naturalWidth || rect.width || 0);
    const height = Number(img.naturalHeight || rect.height || 0);
    if (width && height && width < 110 && height < 110) return;
    [img.currentSrc, img.src, ...parseSrcset(img.srcset)]
      .filter(isHttpUrl)
      .forEach((url) => addCandidate(found, url, 'image'));
  });

  scope.querySelectorAll('picture source').forEach((source) => {
    [source.src, ...parseSrcset(source.srcset)]
      .filter(isHttpUrl)
      .forEach((url) => addCandidate(found, url, 'image'));
  });

  scope.querySelectorAll('[style]').forEach((node) => {
    const style = node.getAttribute('style') || '';
    for (const match of style.matchAll(/url\(["']?([^"')]+)["']?\)/gi)) {
      if (isHttpUrl(match[1])) addCandidate(found, match[1], 'image');
    }
  });

  // Threads / Meta 有些影片來源只會出現在已載入的 resource 清單中。
  // 這裡只補媒體 CDN 上明顯的影片或動圖資源，避免把頁面 UI 資源全部抓進來。
  performance.getEntriesByType('resource').forEach((entry) => {
    const url = entry.name || '';
    if (!isHttpUrl(url) || !/(?:threads|fbcdn|cdninstagram|giphy)/i.test(url)) return;
    if (isLikelyVideoResource(url)) addCandidate(found, url, 'video');
    else if (isLikelyAnimatedImageResource(url)) addCandidate(found, url, 'image');
  });

  const canonical = document.querySelector('link[rel="canonical"]')?.href || location.href;
  return {
    items: [...found.values()],
    page: {
      url: canonical,
      title: document.title.replace(/\s*\|\s*Threads.*$/i, '').trim() || 'Threads 貼文',
      author: extractAuthor()
    }
  };
}

function findPrimaryPostScope() {
  const articles = [...document.querySelectorAll('main article')];
  if (articles.length) {
    // permalink 頁通常第一個 article 就是主貼文；優先找實際有媒體的 article。
    const articleWithMedia = articles.find((article) => article.querySelector('video, img, picture source'));
    return articleWithMedia || articles[0];
  }
  return document.querySelector('main') || document.body;
}

function extractAuthor() {
  const meta = document.querySelector('meta[property="og:title"]')?.content || '';
  const handle = meta.match(/@([\w.]+)/)?.[1];
  if (handle) return `@${handle}`;
  const pathHandle = location.pathname.match(/^\/@([^/]+)/)?.[1];
  return pathHandle ? `@${pathHandle}` : 'threads';
}

function parseSrcset(srcset) {
  if (!srcset) return [];
  return srcset.split(',').map((part) => part.trim().split(/\s+/)[0]).filter(Boolean);
}

function addCandidate(map, rawUrl, kind) {
  try {
    const url = new URL(rawUrl, location.href).href;
    if (!isHttpUrl(url)) return;
    const key = normalizeMediaKey(url);
    if (!map.has(key)) map.set(key, { url, kind });
  } catch (_) { }
}

function normalizeMediaKey(url) {
  try {
    const parsed = new URL(url);
    // 保留實際資源 query，但移除常見無關 fragment。
    parsed.hash = '';
    return parsed.href;
  } catch (_) {
    return String(url || '');
  }
}

function isHttpUrl(value) {
  return /^https?:\/\//i.test(value || '');
}

function isObviousGif(value) {
  return /\.gif(?:$|[?#])/i.test(value || '') || /(?:format|fm|ext)=gif(?:&|$)/i.test(value || '');
}

function isMotionCandidate(item) {
  const url = item?.url || '';
  if (item?.kind === 'video') return true;
  return isObviousGif(url) || /\.webp(?:$|[?#])/i.test(url) || /(?:format|fm|ext)=(?:gif|webp)(?:&|$)/i.test(url);
}

function isLikelyVideoResource(value) {
  return /\.(?:mp4|webm|mov)(?:$|[?#])/i.test(value || '') || /(?:mime|format|fm|ext)=(?:video%2F)?(?:mp4|webm|mov)(?:&|$)/i.test(value || '');
}

function isLikelyAnimatedImageResource(value) {
  return /\.(?:gif|webp)(?:$|[?#])/i.test(value || '') || /(?:format|fm|ext)=(?:gif|webp)(?:&|$)/i.test(value || '');
}
