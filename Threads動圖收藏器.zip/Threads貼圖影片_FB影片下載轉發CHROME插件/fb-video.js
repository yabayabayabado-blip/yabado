const grid = document.querySelector('#grid');
const empty = document.querySelector('#empty');
const summary = document.querySelector('#summary');
const statusNode = document.querySelector('#status');
const transferProgress = document.querySelector('#transferProgress');
const transferProgressTitle = document.querySelector('#transferProgressTitle');
const transferProgressText = document.querySelector('#transferProgressText');
const transferProgressBar = document.querySelector('#transferProgressBar');
const template = document.querySelector('#cardTemplate');
const selectAllButton = document.querySelector('#selectAllButton');
const clearButton = document.querySelector('#clearButton');
const downloadButton = document.querySelector('#downloadButton');
const lineSendButton = document.querySelector('#lineSendButton');
const lineStopButton = document.querySelector('#lineStopButton');
const lineConnection = document.querySelector('#lineConnection');
const lineCount = document.querySelector('#lineCount');
const lineWindowDialog = document.querySelector('#lineWindowDialog');
const lineWindowSelect = document.querySelector('#lineWindowSelect');
const openFolderButton = document.querySelector('#openFolderButton');
const tempManagerButton = document.querySelector('#tempManagerButton');
const tempManagerDialog = document.querySelector('#tempManagerDialog');
const tempSummary = document.querySelector('#tempSummary');
const tempFileList = document.querySelector('#tempFileList');
const openTempFolderButton = document.querySelector('#openTempFolderButton');
const clearTempButton = document.querySelector('#clearTempButton');
const previewLevel = document.querySelector('#previewLevel');
const previewLevelLabel = document.querySelector('#previewLevelLabel');
const NATIVE_HOST = 'com.cjcu.threads_line_clipboard';
const selected = new Set();
let items = [];
let page = {};
let nativeReady = false;
let ffmpegAvailable = false;
let lineRunning = false;
let stopLineRequested = false;
let activeTransferAbortController = null;
let tempStatus = { count: 0, totalBytes: 0, activeCount: 0, files: [] };

selectAllButton.addEventListener('click', () => {
  if (lineRunning) return;
  const allSelected = items.length > 0 && selected.size === items.length;
  selected.clear();
  if (!allSelected) items.forEach((_, i) => selected.add(i));
  syncSelection();
});
clearButton.addEventListener('click', () => {
  if (lineRunning) return;
  selected.clear();
  syncSelection();
});
downloadButton.addEventListener('click', downloadSelected);
lineSendButton.addEventListener('click', sendSelectedToLine);
lineStopButton.addEventListener('click', () => {
  stopLineRequested = true;
  if (activeTransferAbortController) activeTransferAbortController.abort();
  lineStopButton.disabled = true;
  showStatus('正在停止 LINE 傳送…');
});
openFolderButton.addEventListener('click', openOtherMediaFolder);
tempManagerButton.addEventListener('click', openTempManager);
openTempFolderButton.addEventListener('click', openTempFolder);
clearTempButton.addEventListener('click', clearTempFiles);
previewLevel.addEventListener('input', () => { applyPreviewLevel(); savePreviewSetting(); });
initialize();

async function initialize() {
  const stored = await chrome.storage.local.get({ facebookVideoScan: {}, facebookVideoPreviewLevel: '5' });
  previewLevel.value = stored.facebookVideoPreviewLevel || '5';
  applyPreviewLevel();
  const scan = stored.facebookVideoScan || {};
  items = Array.isArray(scan.items) ? scan.items : [];
  page = scan.page || {};
  render();
  await checkNativeHost();
  if (nativeReady) await refreshTempStatus();
  await refineMediaTypes();
}

async function checkNativeHost() {
  lineConnection.textContent = '正在檢查 Windows 橋接程式…';
  lineConnection.className = '';
  try {
    const response = await nativeCall({ action: 'ping' });
    if (!response?.ok) throw new Error(response?.error || 'native_host_unavailable');
    nativeReady = true;
    ffmpegAvailable = response.ffmpegAvailable === true;
    const windowCount = Number(response.windowCount || 0);
    if (!ffmpegAvailable) {
      lineConnection.textContent = '橋接程式正常，但尚未啟用 Facebook 影音合併元件；請重新執行「安裝LINE自動貼上功能.cmd」。';
      lineConnection.className = 'warning';
    } else {
      lineConnection.textContent = windowCount > 0
        ? `橋接程式正常，已偵測到 ${windowCount} 個 LINE 對話視窗；Facebook 影音合併已啟用。`
        : '橋接程式正常，Facebook 影音合併已啟用；LINE 傳送時會等待對話視窗 5 秒。';
      lineConnection.className = windowCount > 0 ? 'connected' : 'warning';
    }
  } catch (_) {
    nativeReady = false;
    ffmpegAvailable = false;
    lineConnection.textContent = '尚未安裝橋接程式，請執行「安裝LINE自動貼上功能.cmd」。';
    lineConnection.className = 'error';
  }
  syncSelection();
}

async function refineMediaTypes() {
  if (!items.length) return;
  showStatus(`正在辨識 Facebook 影音串流 0/${items.length}…`);
  const refined = [];
  for (let index = 0; index < items.length; index += 1) {
    const raw = items[index];
    const item = { ...raw, url: stripByteRange(raw.fullUrl || raw.url), fullUrl: stripByteRange(raw.fullUrl || raw.url) };
    showStatus(`正在辨識 Facebook 影音串流 ${index + 1}/${items.length}…`);
    try {
      const probe = await probeMedia(item);
      const hasVideo = probe.hasVideo === true;
      const hasAudio = probe.hasAudio === true;
      const mime = probe.mime || item.detectedMime || '';
      const kind = hasVideo ? 'video' : (hasAudio ? 'audio' : (mime.startsWith('audio/') ? 'audio' : (mime.startsWith('video/') ? 'video' : item.kind || 'unknown')));
      if (!hasVideo && !hasAudio && kind === 'unknown') continue;
      refined.push({
        ...item,
        kind,
        detectedMime: mime || (kind === 'audio' ? 'audio/mp4' : 'video/mp4'),
        detectedExt: kind === 'audio' ? audioExtensionFromType(mime, item.url) : extensionFromType(mime || 'video/mp4', item.url),
        sizeBytes: probe.totalBytes || Number(item.sizeBytes || 0),
        hasVideoTrack: hasVideo,
        hasAudioTrack: hasAudio,
        trackKnown: probe.trackKnown,
        completeStream: true
      });
    } catch (_) {
      // Facebook page-native/playable 來源無法探測時仍保留為候選視訊；網路未知片段則略過。
      if (Number(item.priority || 0) >= 100 || item.progressive) {
        refined.push({
          ...item,
          kind: item.kind === 'audio' ? 'audio' : 'video',
          detectedExt: item.kind === 'audio' ? 'm4a' : (guessExtensionFromUrl(item.url, 'video') || 'mp4'),
          sizeBytes: Number(item.sizeBytes || 0),
          completeStream: true,
          trackKnown: false
        });
      }
    }
  }

  const deduped = dedupeFullStreams(refined);
  let videos = deduped.filter((x) => x.kind === 'video' || x.hasVideoTrack === true);
  const audios = deduped.filter((x) => x.kind === 'audio' || (x.hasAudioTrack === true && x.hasVideoTrack !== true));

  const confirmedVideos = videos.filter((x) => x.hasVideoTrack === true);
  if (confirmedVideos.length) videos = confirmedVideos;

  const combined = videos.filter((x) => x.hasVideoTrack === true && x.hasAudioTrack === true);
  if (combined.length) {
    videos = combined;
  } else {
    const meaningful = videos.filter((x) => Number(x.sizeBytes || 0) >= 64 * 1024 || Number(x.priority || 0) >= 100);
    if (meaningful.length) videos = meaningful;
    videos.sort((a, b) => Number(b.priority || 0) - Number(a.priority || 0) || Number(b.sizeBytes || 0) - Number(a.sizeBytes || 0));
    videos = videos.slice(0, 4);

    if (audios.length) {
      const sortedAudios = [...audios]
        .filter((x) => Number(x.sizeBytes || 0) >= 8 * 1024 || x.hasAudioTrack === true)
        .sort((a, b) => Number(b.sizeBytes || 0) - Number(a.sizeBytes || 0) || Number(b.capturedAt || 0) - Number(a.capturedAt || 0));
      videos = videos.map((video) => {
        if (video.hasAudioTrack === true || !sortedAudios.length) return video;
        const audio = chooseBestAudioForVideo(video, sortedAudios);
        return audio ? {
          ...video,
          audioUrl: audio.url,
          audioMime: audio.detectedMime || 'audio/mp4',
          audioExt: audio.detectedExt || 'm4a',
          audioSizeBytes: Number(audio.sizeBytes || 0),
          needsMux: true
        } : video;
      });
    }
  }

  items = sortMediaItems(videos);
  selected.clear();
  render();
  if (!items.length) {
    showStatus('已偵測到 Facebook 分段串流，但目前尚未取得可使用的完整影片。請重新整理 Facebook 頁面並播放影片數秒後再試。', 'error');
  } else if (items.some((x) => x.needsMux && x.audioUrl)) {
    showStatus(`已還原 ${items.length} 個影片；偵測到 Facebook 影音分離串流，下載與 LINE 傳送時會自動合併聲音。`, 'success');
  } else if (items.some((x) => x.hasVideoTrack && !x.hasAudioTrack)) {
    showStatus(`已還原 ${items.length} 個影片，但尚未攔截到對應音訊。請回 Facebook 將影片開啟聲音播放數秒後，再重新開啟本功能。`, 'error');
  } else {
    showStatus(`已還原 ${items.length} 個可直接下載的有聲 Facebook 影片。`, 'success');
  }
}

function chooseBestAudioForVideo(video, audios) {
  const videoTime = Number(video.capturedAt || 0);
  const ranked = [...audios].sort((a, b) => {
    const aDelta = videoTime && a.capturedAt ? Math.abs(Number(a.capturedAt) - videoTime) : Number.MAX_SAFE_INTEGER;
    const bDelta = videoTime && b.capturedAt ? Math.abs(Number(b.capturedAt) - videoTime) : Number.MAX_SAFE_INTEGER;
    if (aDelta !== bDelta) return aDelta - bDelta;
    return Number(b.sizeBytes || 0) - Number(a.sizeBytes || 0);
  });
  const best = ranked[0] || null;
  if (!best) return null;
  if (videoTime && best.capturedAt && Math.abs(Number(best.capturedAt) - videoTime) > 120000) return null;
  return best;
}

function audioExtensionFromType(mime, url) {
  const clean = String(mime || '').split(';')[0].toLowerCase();
  const types = { 'audio/mp4': 'm4a', 'audio/aac': 'aac', 'audio/mpeg': 'mp3', 'audio/ogg': 'opus', 'audio/webm': 'webm' };
  if (types[clean]) return types[clean];
  const match = String(url || '').match(/\.(m4a|aac|mp3|opus|webm|mp4)(?:$|[?#])/i);
  return match ? match[1].toLowerCase() : 'm4a';
}

function stripByteRange(value) {
  try {
    const u = new URL(String(value || ''));
    u.hash = '';
    for (const key of ['bytestart','byteend','start','end']) u.searchParams.delete(key);
    return u.href;
  } catch (_) { return String(value || ''); }
}

function dedupeFullStreams(list) {
  const map = new Map();
  for (const item of list) {
    const key = stripByteRange(item.url);
    const old = map.get(key);
    if (!old || Number(item.priority || 0) > Number(old.priority || 0) || Number(item.sizeBytes || 0) > Number(old.sizeBytes || 0)) map.set(key, item);
  }
  return [...map.values()];
}

async function probeMedia(item) {
  const url = stripByteRange(item.url);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 12000);
  try {
    const response = await fetch(url, {
      credentials: 'include', cache: 'no-cache', referrer: page.url || 'https://www.facebook.com/',
      headers: { Range: 'bytes=0-262143' }, signal: controller.signal
    });
    if (!response.ok && response.status !== 206) throw new Error(`HTTP ${response.status}`);
    const mime = String(response.headers.get('content-type') || '').split(';')[0].toLowerCase();
    const contentRange = String(response.headers.get('content-range') || '');
    const rangeMatch = contentRange.match(/\/(\d+)\s*$/);
    const totalBytes = rangeMatch ? Number(rangeMatch[1]) : Number(response.headers.get('content-length') || 0);
    const head = new Uint8Array(await response.arrayBuffer());
    let tail = new Uint8Array();
    if (totalBytes > 300000) {
      try {
        const tailStart = Math.max(0, totalBytes - 262144);
        const tailResponse = await fetch(url, {
          credentials: 'include', cache: 'no-cache', referrer: page.url || 'https://www.facebook.com/',
          headers: { Range: `bytes=${tailStart}-${totalBytes - 1}` }, signal: controller.signal
        });
        if (tailResponse.ok || tailResponse.status === 206) tail = new Uint8Array(await tailResponse.arrayBuffer());
      } catch (_) { }
    }
    const tracks = inspectMp4Tracks(head, tail);
    return { mime, totalBytes, ...tracks };
  } finally { clearTimeout(timer); }
}

function inspectMp4Tracks(head, tail) {
  const decoder = new TextDecoder('latin1');
  const text = decoder.decode(head) + decoder.decode(tail);
  const hasFtyp = text.includes('ftyp');
  const hasMoov = text.includes('moov') || text.includes('moof');
  const hasVideo = /vide/.test(text) || /avc1|av01|hvc1|hev1|vp09/.test(text);
  const hasAudio = /soun/.test(text) || /mp4a|Opus|opus/.test(text);
  return { hasVideo, hasAudio, trackKnown: hasFtyp || hasMoov || hasVideo || hasAudio };
}

function applyPreviewLevel() {
  const level = Math.max(1, Math.min(10, Number(previewLevel.value) || 5));
  const sizes = [76, 92, 110, 132, 190, 220, 250, 280, 310, 340];
  const percentages = [20, 25, 30, 35, 50, 60, 70, 80, 90, 100];
  grid.style.setProperty('--card-size', `${sizes[level - 1]}px`);
  grid.classList.toggle('small-cards', level >= 5 && level <= 6);
  grid.classList.toggle('thumbnail-only', level <= 4);
  previewLevelLabel.textContent = `第${level}級（${percentages[level - 1]}%）`;
}

async function savePreviewSetting() {
  await chrome.storage.local.set({ facebookVideoPreviewLevel: previewLevel.value });
}

function mediaTypeOrder(ext) {
  const order = { mp4: 1, mov: 2, webm: 3, webp: 4, png: 5, jpg: 6 };
  return order[String(ext || '').toLowerCase()] || 99;
}

function mediaExt(item) {
  return String(item.detectedExt || (item.detectedMime ? extensionFromType(item.detectedMime, item.url) : guessExtensionFromUrl(item.url, item.kind))).toLowerCase();
}

function sortMediaItems(list) {
  return [...list].sort((a, b) => {
    const extA = mediaExt(a);
    const extB = mediaExt(b);
    const typeDiff = mediaTypeOrder(extA) - mediaTypeOrder(extB);
    if (typeDiff) return typeDiff;
    const sizeDiff = Number(b.sizeBytes || 0) - Number(a.sizeBytes || 0);
    if (sizeDiff) return sizeDiff;
    return shortUrlName(a.url).localeCompare(shortUrlName(b.url), 'zh-Hant');
  });
}

function render() {
  grid.textContent = '';
  empty.hidden = items.length > 0;
  const totalBytes = items.reduce((sum, item) => sum + Number(item.sizeBytes || 0), 0);
  summary.textContent = items.length
    ? `共找到 ${items.length} 個 Facebook 完整影片${totalBytes ? `，合計 ${formatBytes(totalBytes)}` : ''}`
    : '未找到Facebook 影片';

  const groups = new Map();
  items.forEach((item, index) => {
    const ext = mediaExt(item);
    if (!groups.has(ext)) groups.set(ext, []);
    groups.get(ext).push({ item, index });
  });

  [...groups.entries()]
    .sort((a, b) => mediaTypeOrder(a[0]) - mediaTypeOrder(b[0]))
    .forEach(([ext, entries]) => {
      const section = document.createElement('section');
      section.className = 'media-group';
      const groupBytes = entries.reduce((sum, entry) => sum + Number(entry.item.sizeBytes || 0), 0);
      const heading = document.createElement('div');
      heading.className = 'media-group-heading';
      const title = document.createElement('h2');
      title.textContent = ext.toUpperCase();
      const info = document.createElement('span');
      info.textContent = `${entries.length} 個${groupBytes ? `・${formatBytes(groupBytes)}` : ''}`;
      heading.append(title, info);
      section.append(heading);

      const groupGrid = document.createElement('div');
      groupGrid.className = 'media-group-grid';
      entries.forEach(({ item, index }) => {
        const node = template.content.firstElementChild.cloneNode(true);
        const input = node.querySelector('.selector');
        input.checked = selected.has(index);
        input.addEventListener('change', () => {
          if (lineRunning) {
            input.checked = selected.has(index);
            return;
          }
          if (input.checked) selected.add(index); else selected.delete(index);
          syncSelection();
        });
        const preview = node.querySelector('.preview');
        if (item.kind === 'video' || /\.(?:mp4|webm|mov)(?:$|[?#])/i.test(item.url || '')) {
          const video = document.createElement('video');
          video.src = item.url;
          video.controls = true;
          video.preload = 'metadata';
          // 預覽由使用者手動按播放，不需強制靜音。
          video.muted = false;
          video.defaultMuted = false;
          video.volume = 1;
          video.playsInline = true;
          preview.append(video);
          if (item.needsMux && item.audioUrl) {
            const audio = document.createElement('audio');
            audio.src = item.audioUrl;
            audio.preload = 'metadata';
            audio.hidden = true;
            preview.append(audio);
            const syncAudio = () => {
              try {
                if (Number.isFinite(video.currentTime) && Math.abs((audio.currentTime || 0) - video.currentTime) > 0.35) audio.currentTime = video.currentTime;
                audio.volume = video.volume;
                audio.muted = video.muted;
                audio.playbackRate = video.playbackRate;
              } catch (_) { }
            };
            video.addEventListener('play', async () => {
              syncAudio();
              try { await audio.play(); } catch (_) { }
            });
            video.addEventListener('pause', () => { try { audio.pause(); } catch (_) { } });
            video.addEventListener('seeking', syncAudio);
            video.addEventListener('ratechange', syncAudio);
            video.addEventListener('volumechange', syncAudio);
            video.addEventListener('ended', () => { try { audio.pause(); audio.currentTime = 0; } catch (_) { } });
          }
        } else {
          const img = document.createElement('img');
          img.src = item.url;
          img.alt = 'Facebook 影片預覽';
          preview.append(img);
        }
        node.querySelector('.type').textContent = item.needsMux && item.audioUrl ? `${ext.toUpperCase()}・影音自動合併` : ext.toUpperCase();
        node.querySelector('.name').textContent = shortUrlName(item.url);
        const sizeNode = node.querySelector('.size');
        if (sizeNode) {
          const videoBytes = Number(item.sizeBytes || 0);
          const audioBytes = Number(item.audioSizeBytes || 0);
          const totalBytes = videoBytes + (item.needsMux ? audioBytes : 0);
          sizeNode.textContent = totalBytes > 0 ? `${formatBytes(totalBytes)}${item.needsMux && audioBytes ? '（含聲音）' : ''}` : '大小未知';
        }
        groupGrid.append(node);
      });
      section.append(groupGrid);
      grid.append(section);
    });
  syncSelection();
}

function syncSelection() {
  const count = selected.size;
  downloadButton.disabled = lineRunning || count === 0;
  clearButton.disabled = lineRunning || count === 0;
  selectAllButton.disabled = lineRunning || items.length === 0;
  openFolderButton.disabled = lineRunning;
  tempManagerButton.disabled = lineRunning || !nativeReady || tempStatus.count === 0;
  previewLevel.disabled = lineRunning;
  downloadButton.textContent = `下載已勾選 ${count} 個`;
  lineSendButton.textContent = lineRunning
    ? 'LINE 傳送中…'
    : count > 0 ? `LINE 自動傳送（${count}）` : 'LINE 自動傳送（請先勾選）';
  lineSendButton.disabled = lineRunning || count === 0 || !nativeReady;
  lineStopButton.disabled = !lineRunning || stopLineRequested;
  lineCount.textContent = `已勾選 ${count} 個`;
  selectAllButton.textContent = items.length > 0 && count === items.length ? '取消全選' : '全選';
  [...grid.querySelectorAll('.selector')].forEach((input, index) => {
    input.checked = selected.has(index);
    input.disabled = lineRunning;
  });
}

async function downloadSelected() {
  const indexes = [...selected].sort((a,b) => a-b);
  if (!indexes.length || lineRunning) return;
  setBusy(true);
  let ok = 0;
  let failed = 0;
  for (let pos = 0; pos < indexes.length; pos += 1) {
    const index = indexes[pos];
    showStatus(`正在下載 ${pos + 1}/${indexes.length}…`);
    try {
      const item = items[index];
      if (item.needsMux && item.audioUrl) {
        if (!nativeReady) throw new Error('native_host_required_for_mux');
        if (!ffmpegAvailable) throw new Error('ffmpeg_missing');
        const muxed = await prepareMuxedTransfer(item, pos + 1, indexes.length);
        const filename = buildFilename(pos + 1, 'mp4');
        const saved = await nativeCall({ action: 'save_temp_file_to_downloads', transferId: muxed.transferId, filename });
        if (!saved?.ok) throw new Error(saved?.error || 'save_muxed_file_failed');
      } else {
        const extHint = mediaExt(item) || 'mp4';
        try {
          const blob = await fetchMediaBlobWithProgress(item, {
            title: `正在下載第 ${pos + 1}/${indexes.length} 個影片`,
            shouldStop: () => false
          });
          if (!blob.size) throw new Error('檔案大小為 0');
          const type = normalizeType(blob.type, item.kind, item.url);
          const ext = extensionFromType(type, item.url);
          if (!['mp4','webm','mov'].includes(ext)) throw new Error('不是支援的 Facebook 影片格式');
          const objectUrl = URL.createObjectURL(blob.type === type ? blob : blob.slice(0, blob.size, type));
          try {
            await chrome.downloads.download({
              url: objectUrl,
              filename: `Facebook影片/${buildFilename(pos + 1, ext)}`,
              conflictAction: 'uniquify',
              saveAs: false
            });
          } finally {
            setTimeout(() => URL.revokeObjectURL(objectUrl), 60000);
          }
        } catch (fetchError) {
          hideTransferProgress();
          showStatus(`一般下載受限制，改用 Chrome 原生下載 ${pos + 1}/${indexes.length}…`);
          await chrome.downloads.download({
            url: item.url,
            filename: `Facebook影片/${buildFilename(pos + 1, ['mp4','webm','mov'].includes(extHint) ? extHint : 'mp4')}`,
            conflictAction: 'uniquify',
            saveAs: false
          });
        }
      }
      ok += 1;
    } catch (error) {
      failed += 1;
      showStatus(`第 ${pos + 1} 個下載失敗：${nativeErrorMessage(error?.message || error)}`, 'error');
    }
  }
  hideTransferProgress();
  showStatus(`完成：下載 ${ok} 個${failed ? `，失敗 ${failed} 個` : ''}${ok && items.some((x) => x.needsMux) ? '；影音分離來源已自動合併聲音' : ''}。`, failed ? 'error' : 'success');
  setBusy(false);
}

async function sendSelectedToLine() {
  const indexes = [...selected].sort((a, b) => a - b);
  if (!indexes.length || lineRunning) return;
  if (!nativeReady) {
    showStatus('LINE 橋接程式尚未就緒，請重新安裝橋接程式後重開 Chrome。', 'error');
    return;
  }

  lineRunning = true;
  stopLineRequested = false;
  syncSelection();
  let completed = 0;

  try {
    const targetWindow = await waitForLineTarget();
    if (!targetWindow) {
      await safelyClearClipboard();
      showStatus(stopLineRequested
        ? '已停止等待 LINE 視窗；剪貼簿已清空。'
        : '5 秒內仍未偵測到可用的 LINE 對話視窗；已清空剪貼簿。', 'error');
      return;
    }

    showStatus(`已選擇 LINE 視窗「${targetWindow.title}」，開始準備媒體…`);

    for (let pos = 0; pos < indexes.length; pos += 1) {
      if (stopLineRequested) break;
      const item = items[indexes[pos]];
      showStatus(`正在準備第 ${pos + 1}/${indexes.length} 個媒體…`);
      let nativeResponse;
      if (item.needsMux && item.audioUrl) {
        if (!ffmpegAvailable) throw new Error('ffmpeg_missing');
        const muxed = await prepareMuxedTransfer(item, pos + 1, indexes.length);
        if (stopLineRequested) {
          try { await nativeCall({ action: 'cancel_temp_transfer', transferId: muxed.transferId }); } catch (_) { }
          break;
        }
        showStatus(`正在透過 LINE 檔案選擇器傳送第 ${pos + 1}/${indexes.length} 個有聲影片…`);
        nativeResponse = await nativeCall({ action: 'send_temp_file', transferId: muxed.transferId, windowId: targetWindow.id });
      } else {
        const blob = await fetchMediaBlobWithProgress(item, {
          title: `正在取得第 ${pos + 1}/${indexes.length} 個媒體`,
          shouldStop: () => stopLineRequested
        });
        if (!blob.size) throw new Error('empty_file');

        const type = normalizeType(blob.type, item.kind, item.url);
        const ext = extensionFromType(type, item.url);
        if (!['mp4','webm','mov'].includes(ext)) throw new Error('unsupported_media_format');
        if (stopLineRequested) break;
        const lineFilename = buildLineFilename(item, pos + 1, ext);
        nativeResponse = await sendBlobToLineInChunks({
          blob: blob.type === type ? blob : blob.slice(0, blob.size, type),
          filename: lineFilename,
          windowId: targetWindow.id,
          position: pos + 1,
          total: indexes.length
        });
      }
      if (!nativeResponse?.ok) throw new Error(nativeResponse?.error || 'line_send_failed');
      if (nativeResponse?.method === 'ctrl_o' && nativeResponse?.uploadConfirmed === false && !nativeResponse?.fallbackWaitUsed) {
        throw new Error('line_upload_not_confirmed');
      }
      if (nativeResponse?.method === 'ctrl_o' && nativeResponse?.fallbackWaitUsed) {
        showStatus(`此電腦無法使用 LINE 上傳完成監看；已延長等待後清除第 ${pos + 1}/${indexes.length} 個影片暫存檔。`);
      }
      completed += 1;
      if (pos < indexes.length - 1 && !stopLineRequested) {
        showStatus(`已確認送出 ${completed} 個，正在準備下一個…`);
      }
    }

    await safelyClearClipboard();
    if (stopLineRequested) {
      showStatus(`已停止，共送出 ${completed}/${indexes.length} 個；剪貼簿已清空。`);
    } else {
      selected.clear();
      syncSelection();
      showStatus(`完成：${completed} 個媒體已依序送出，系統剪貼簿已清空。`, 'success');
    }
  } catch (error) {
    await safelyClearClipboard();
    showStatus(`LINE 自動傳送中止：${nativeErrorMessage(error.message)}`, 'error');
  } finally {
    activeTransferAbortController = null;
    hideTransferProgress();
    lineRunning = false;
    stopLineRequested = false;
    syncSelection();
    await checkNativeHost();
    if (nativeReady) await refreshTempStatus();
  }
}


async function uploadBlobToTemp(blob, filename, prefix = 'facebook') {
  const transferId = `${prefix}_${Date.now()}_${Math.random().toString(16).slice(2)}`;
  const chunkSize = 1024 * 1024;
  let begun = false;
  try {
    const begin = await nativeCall({ action: 'begin_temp_transfer', transferId, filename, expectedBytes: blob.size });
    if (!begin?.ok) throw new Error(begin?.error || 'temp_transfer_failed');
    begun = true;
    for (let offset = 0; offset < blob.size; offset += chunkSize) {
      if (stopLineRequested) throw new Error('transfer_stopped');
      const chunk = blob.slice(offset, Math.min(offset + chunkSize, blob.size));
      const response = await nativeCall({ action: 'append_temp_chunk', transferId, base64: await blobToBase64(chunk) });
      if (!response?.ok) throw new Error(response?.error || 'temp_transfer_failed');
    }
    return transferId;
  } catch (error) {
    if (begun) {
      try { await nativeCall({ action: 'cancel_temp_transfer', transferId }); } catch (_) { }
    }
    throw error;
  }
}

async function prepareMuxedTransfer(item, position, total) {
  showStatus(`正在取得第 ${position}/${total} 個影片影像軌…`);
  const videoBlob = await fetchMediaBlobWithProgress(item, {
    title: `正在取得第 ${position}/${total} 個影片影像軌`,
    shouldStop: () => stopLineRequested
  });
  if (!videoBlob.size) throw new Error('empty_file');

  showStatus(`正在取得第 ${position}/${total} 個影片聲音軌…`);
  const audioItem = { ...item, url: item.audioUrl, kind: 'audio' };
  const audioBlob = await fetchMediaBlobWithProgress(audioItem, {
    title: `正在取得第 ${position}/${total} 個影片聲音軌`,
    shouldStop: () => stopLineRequested
  });
  if (!audioBlob.size) throw new Error('audio_track_empty');

  let videoTransferId = '';
  let audioTransferId = '';
  try {
    showStatus(`正在暫存第 ${position}/${total} 個影片的影像與聲音…`);
    videoTransferId = await uploadBlobToTemp(videoBlob, `video_${position}.mp4`, 'fbvideo');
    const audioExt = item.audioExt || audioExtensionFromType(audioBlob.type || item.audioMime, item.audioUrl);
    audioTransferId = await uploadBlobToTemp(audioBlob, `audio_${position}.${audioExt}`, 'fbaudio');
    const outputTransferId = `fbmux_${Date.now()}_${Math.random().toString(16).slice(2)}`;
    showStatus(`正在合併第 ${position}/${total} 個影片的聲音…`);
    const muxed = await nativeCall({
      action: 'mux_temp_files',
      videoTransferId,
      audioTransferId,
      outputTransferId,
      outputFilename: `facebook_${position}.mp4`
    });
    videoTransferId = '';
    audioTransferId = '';
    if (!muxed?.ok) throw new Error(muxed?.error || 'ffmpeg_mux_failed');
    return muxed;
  } catch (error) {
    if (videoTransferId) try { await nativeCall({ action: 'cancel_temp_transfer', transferId: videoTransferId }); } catch (_) { }
    if (audioTransferId) try { await nativeCall({ action: 'cancel_temp_transfer', transferId: audioTransferId }); } catch (_) { }
    throw error;
  }
}


async function sendBlobToLineInChunks({ blob, filename, windowId, position, total }) {
  const transferId = `facebook_${Date.now()}_${Math.random().toString(16).slice(2)}`;
  const chunkSize = 1024 * 1024;
  let transferred = 0;
  let begun = false;
  try {
    const begin = await nativeCall({
      action: 'begin_temp_transfer',
      transferId,
      filename,
      expectedBytes: blob.size
    });
    if (!begin?.ok) throw new Error(begin?.error || 'temp_transfer_failed');
    begun = true;

    for (let offset = 0; offset < blob.size; offset += chunkSize) {
      if (stopLineRequested) throw new Error('transfer_stopped');
      const chunk = blob.slice(offset, Math.min(offset + chunkSize, blob.size));
      const response = await nativeCall({
        action: 'append_temp_chunk',
        transferId,
        base64: await blobToBase64(chunk)
      });
      if (!response?.ok) throw new Error(response?.error || 'temp_transfer_failed');
      transferred += chunk.size;
      showTransferProgress(
        `正在準備第 ${position}/${total} 個媒體傳送到 LINE`,
        transferred,
        blob.size
      );
    }

    if (stopLineRequested) throw new Error('transfer_stopped');
    const isVideo = /\.(mp4|mov|webm)$/i.test(filename);
    showStatus(isVideo
      ? `正在透過 LINE 檔案選擇器傳送第 ${position}/${total} 個影片…`
      : `正在傳送第 ${position}/${total} 個媒體到 LINE…`);
    const sent = await nativeCall({
      action: 'send_temp_file',
      transferId,
      windowId
    });
    begun = false;
    return sent;
  } catch (error) {
    if (begun) {
      try { await nativeCall({ action: 'cancel_temp_transfer', transferId }); } catch (_) { }
    }
    throw error;
  }
}

async function waitForLineTarget() {
  let windows = await listLineWindows();
  if (!windows.length) {
    lineConnection.textContent = '尚未偵測到 LINE 對話視窗；請在 5 秒內開啟聊天室…';
    lineConnection.className = 'warning';
    showStatus('沒有偵測到已開啟的 LINE 對話視窗，正在待命 5 秒；請立即開啟要傳送的聊天室。');
    const deadline = Date.now() + 5000;
    while (Date.now() < deadline && !stopLineRequested) {
      const remaining = Math.max(1, Math.ceil((deadline - Date.now()) / 1000));
      lineConnection.textContent = `請開啟 LINE 對話視窗；剩餘 ${remaining} 秒…`;
      await wait(500);
      windows = await listLineWindows();
      if (windows.length) break;
    }
  }
  if (!windows.length || stopLineRequested) return null;
  if (windows.length === 1) return windows[0];
  const selectedWindow = await chooseLineWindow(windows);
  if (!selectedWindow) throw new Error('line_window_selection_cancelled');
  return selectedWindow;
}

async function listLineWindows() {
  const response = await nativeCall({ action: 'list_line_windows' });
  if (!response?.ok) throw new Error(response?.error || 'line_not_running');
  return Array.isArray(response.windows)
    ? response.windows.filter((entry) => String(entry.title || '').trim().toLowerCase() !== 'line')
    : [];
}

function chooseLineWindow(windows) {
  lineWindowSelect.replaceChildren();
  windows.forEach((entry, index) => {
    const option = document.createElement('option');
    option.value = entry.id;
    option.textContent = `${index + 1}. ${entry.title || 'LINE 對話視窗'}`;
    lineWindowSelect.append(option);
  });
  lineWindowDialog.showModal();
  return new Promise((resolve) => {
    lineWindowDialog.addEventListener('close', () => {
      if (lineWindowDialog.returnValue !== 'confirm') {
        resolve(null);
        return;
      }
      resolve(windows.find((entry) => entry.id === lineWindowSelect.value) || null);
    }, { once: true });
  });
}

async function safelyClearClipboard() {
  try { await nativeCall({ action: 'clear_clipboard' }); } catch (_) { }
}

function wait(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

async function fetchMedia(item, signal = undefined) {
  const response = await fetch(item.url, {
    credentials: 'include',
    cache: 'no-cache',
    referrer: page.url || 'https://www.facebook.com/',
    signal
  });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return response;
}

async function fetchMediaBlobWithProgress(item, options = {}) {
  const controller = new AbortController();
  activeTransferAbortController = controller;
  try {
    const response = await fetchMedia(item, controller.signal);
    const total = Number(response.headers.get('content-length') || 0);
    const mime = String(response.headers.get('content-type') || '').split(';')[0].toLowerCase();
    if (!response.body || typeof response.body.getReader !== 'function') {
      showTransferProgress(options.title || '正在取得媒體', 0, total);
      const blob = await response.blob();
      showTransferProgress(options.title || '正在取得媒體', blob.size, total || blob.size);
      return mime && blob.type !== mime ? blob.slice(0, blob.size, mime) : blob;
    }

    const reader = response.body.getReader();
    const chunks = [];
    let loaded = 0;
    showTransferProgress(options.title || '正在取得媒體', loaded, total);
    while (true) {
      if (options.shouldStop?.()) {
        try { await reader.cancel(); } catch (_) { }
        throw new Error('transfer_stopped');
      }
      const { done, value } = await reader.read();
      if (done) break;
      if (value) {
        chunks.push(value);
        loaded += value.byteLength;
        showTransferProgress(options.title || '正在取得媒體', loaded, total);
      }
    }
    showTransferProgress(options.title || '正在取得媒體', loaded, total || loaded);
    return new Blob(chunks, { type: mime || '' });
  } catch (error) {
    if (error?.name === 'AbortError') throw new Error('transfer_stopped');
    throw error;
  } finally {
    if (activeTransferAbortController === controller) activeTransferAbortController = null;
  }
}

function showTransferProgress(title, loaded, total = 0) {
  transferProgress.hidden = false;
  transferProgressTitle.textContent = title;
  const safeLoaded = Math.max(0, Number(loaded) || 0);
  const safeTotal = Math.max(0, Number(total) || 0);
  if (safeTotal > 0) {
    const percent = Math.max(0, Math.min(100, Math.round((safeLoaded / safeTotal) * 100)));
    transferProgressBar.value = percent;
    transferProgressText.textContent = `${percent}%（${formatBytes(safeLoaded)} / ${formatBytes(safeTotal)}）`;
  } else {
    transferProgressBar.removeAttribute('value');
    transferProgressText.textContent = `已接收 ${formatBytes(safeLoaded)}`;
  }
}

function hideTransferProgress() {
  transferProgress.hidden = true;
  transferProgressBar.removeAttribute('value');
  transferProgressTitle.textContent = '';
  transferProgressText.textContent = '';
}

function formatBytes(bytes) {
  const value = Math.max(0, Number(bytes) || 0);
  if (value < 1024) return `${value} B`;
  if (value < 1024 * 1024) return `${(value / 1024).toFixed(1)} KB`;
  return `${(value / (1024 * 1024)).toFixed(value >= 10 * 1024 * 1024 ? 1 : 2)} MB`;
}

async function openOtherMediaFolder() {
  try {
    const downloads = await chrome.downloads.search({ orderBy:['-startTime'], limit:5000 });
    const marker = '/Facebook影片/';
    let folder = '';
    for (const item of downloads) {
      const full = String(item.filename || '');
      const normalized = full.replaceAll('\\','/');
      const at = normalized.toLowerCase().lastIndexOf(marker.toLowerCase());
      if (at >= 0) { folder = full.slice(0, at + marker.length - 1).replaceAll('/','\\'); break; }
    }
    if (folder) {
      const response = await nativeCall({ action:'open_folder', folderPath:folder });
      if (response?.ok) return;
    }
  } catch (_) { }
  chrome.downloads.showDefaultFolder();
}

async function refreshTempStatus() {
  if (!nativeReady) {
    tempStatus = { count: 0, totalBytes: 0, activeCount: 0, files: [] };
    renderTempStatus();
    syncSelection();
    return;
  }
  try {
    const response = await nativeCall({ action: 'temp_status' });
    if (!response?.ok) throw new Error(response?.error || 'temp_status_failed');
    tempStatus = {
      count: Number(response.count || 0),
      totalBytes: Number(response.totalBytes || 0),
      activeCount: Number(response.activeCount || 0),
      files: Array.isArray(response.files) ? response.files : []
    };
  } catch (_) {
    tempStatus = { count: 0, totalBytes: 0, activeCount: 0, files: [] };
  }
  renderTempStatus();
  syncSelection();
}

function renderTempStatus() {
  const count = tempStatus.count || 0;
  const activeCount = tempStatus.activeCount || 0;
  tempManagerButton.textContent = count > 0 ? `暫存檔案（${count}，${formatBytes(tempStatus.totalBytes)}）` : '暫存檔案';
  tempManagerButton.disabled = lineRunning || !nativeReady || count === 0;
  tempSummary.textContent = count > 0
    ? `共 ${count} 個，合計 ${formatBytes(tempStatus.totalBytes)}${activeCount ? `；${activeCount} 個正在使用中` : ''}`
    : '暫存目錄目前是空的。';
  tempFileList.textContent = '';
  if (!count) {
    const emptyNode = document.createElement('div');
    emptyNode.className = 'temp-empty';
    emptyNode.textContent = '沒有暫存檔案';
    tempFileList.append(emptyNode);
  } else {
    for (const file of tempStatus.files) {
      const row = document.createElement('div');
      row.className = 'temp-file-row';
      const name = document.createElement('div');
      name.className = 'temp-file-name';
      name.textContent = file.filename || '未命名檔案';
      name.title = file.path || file.filename || '';
      const size = document.createElement('div');
      size.className = 'temp-file-size';
      size.textContent = formatBytes(Number(file.bytes || 0));
      const state = document.createElement('div');
      state.className = `temp-file-state${file.active ? ' active' : ''}`;
      state.textContent = file.active ? '使用中' : '可清理';
      row.append(name, size, state);
      tempFileList.append(row);
    }
  }
  openTempFolderButton.disabled = count === 0;
  clearTempButton.disabled = count === 0 || activeCount > 0 || lineRunning;
  clearTempButton.textContent = activeCount > 0 ? '有檔案使用中，無法清空' : '清空暫存檔';
}

async function openTempManager() {
  await refreshTempStatus();
  if (!tempStatus.count) return;
  tempManagerDialog.showModal();
}

async function openTempFolder() {
  if (!tempStatus.count || !nativeReady) return;
  try {
    const response = await nativeCall({ action: 'open_temp_folder' });
    if (!response?.ok) throw new Error(response?.error || 'open_temp_folder_failed');
  } catch (error) {
    showStatus(`無法開啟暫存目錄：${nativeErrorMessage(error.message)}`, 'error');
  }
}

async function clearTempFiles() {
  if (!tempStatus.count || tempStatus.activeCount > 0 || lineRunning || !nativeReady) return;
  clearTempButton.disabled = true;
  clearTempButton.textContent = '正在清空…';
  try {
    const response = await nativeCall({ action: 'clear_temp_files' });
    if (!response?.ok) throw new Error(response?.error || 'temp_clear_failed');
    showStatus(`已清空 ${Number(response.deleted || 0)} 個暫存檔。`, 'success');
    await refreshTempStatus();
    if (!tempStatus.count && tempManagerDialog.open) tempManagerDialog.close();
  } catch (error) {
    showStatus(`無法清空暫存檔：${nativeErrorMessage(error.message)}`, 'error');
    await refreshTempStatus();
  }
}

function formatBytes(value) {
  const bytes = Math.max(0, Number(value) || 0);
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(bytes >= 10240 ? 0 : 1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / 1024 / 1024).toFixed(bytes >= 100 * 1024 * 1024 ? 0 : 1)} MB`;
  return `${(bytes / 1024 / 1024 / 1024).toFixed(2)} GB`;
}

function setBusy(busy) {
  downloadButton.disabled = busy || selected.size === 0;
  selectAllButton.disabled = busy;
  clearButton.disabled = busy || selected.size === 0;
  openFolderButton.disabled = busy;
  tempManagerButton.disabled = busy || !nativeReady || tempStatus.count === 0;
  lineSendButton.disabled = busy || selected.size === 0 || !nativeReady;
  previewLevel.disabled = busy;
}

function showStatus(message, kind='') {
  statusNode.textContent = message;
  statusNode.className = `status ${kind}`.trim();
}

function nativeCall(message) {
  return new Promise((resolve,reject) => chrome.runtime.sendNativeMessage(NATIVE_HOST,message,(response) => {
    if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
    else resolve(response || null);
  }));
}

function nativeErrorMessage(value) {
  const message = String(value || '未知錯誤');
  if (/host not found|not registered|Specified native messaging/i.test(message)) {
    return '找不到 Windows 橋接程式，請執行「安裝LINE自動貼上功能.cmd」後重新開啟 Chrome。';
  }
  const messages = {
    line_not_running: '找不到 LINE 電腦版，請先開啟 LINE 並進入正確聊天室。',
    line_focus_failed: '無法切換到 LINE 視窗，請解除最小化並重新執行。',
    line_window_closed: '選取的 LINE 對話視窗已關閉，請重新選取後再傳送。',
    line_window_selection_cancelled: '已取消選擇 LINE 對話視窗。',
    clipboard_busy: '系統剪貼簿正被其他程式占用，請稍後重試。',
    clipboard_clear_failed: '媒體已送出，但系統剪貼簿無法清空，請手動清除。',
    empty_file: '媒體內容為空。',
    unsupported_media_format: '這個媒體格式目前無法傳送到 LINE。',
    transfer_stopped: '已停止傳送。',
    line_file_dialog_not_found: '無法開啟 LINE 的檔案選擇視窗。',
    line_file_path_input_failed: '無法將暫存影片路徑填入 LINE 檔案選擇視窗。',
    line_file_dialog_submit_failed: 'LINE 檔案選擇視窗未完成送出。',
    line_send_failed: 'LINE 傳送失敗。',
    line_upload_not_confirmed: '影片已交給 LINE，但無法確認上傳已完成。為避免過早刪除，暫存影片會保留並由橋接程式後續清理。',
    temp_transfer_failed: '大型媒體暫存傳輸失敗。',
    temp_files_in_use: '目前有暫存檔正在使用中，無法清空。',
    temp_clear_failed: '暫存檔清理失敗，可能有檔案正在被其他程式使用。',
    transfer_too_large: '媒體檔案過大，超過橋接程式的大型檔案安全上限。',
    native_host_required_for_mux: '此 Facebook 影片採影音分離，需要 Windows 橋接程式才能自動合併聲音。請重新執行「安裝LINE自動貼上功能.cmd」。',
    ffmpeg_missing: '尚未安裝 FFmpeg，無法將 Facebook 的影像軌與聲音軌合併。請重新執行「安裝LINE自動貼上功能.cmd」，新版會自動安裝所需元件。',
    ffmpeg_mux_failed: 'Facebook 影音合併失敗，請重新播放影片數秒後再擷取一次。',
    audio_track_empty: '已偵測到聲音軌，但取得的音訊內容為空。請回 Facebook 開啟聲音播放數秒後再試。',
    save_muxed_file_failed: '有聲影片已合併，但儲存到下載資料夾失敗。'
  };
  return messages[message] || message;
}

function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(',')[1] || '');
    reader.onerror = () => reject(reader.error || new Error('讀取媒體失敗。'));
    reader.readAsDataURL(blob);
  });
}

function buildLineFilename(item, index, ext) {
  const raw = shortUrlName(item.url).replace(/\.[^.]+$/, '') || `facebook_video_${index}`;
  const base = raw.replace(/[\\/:*?"<>|\u0000-\u001f]+/g, '_').replace(/\s+/g, '_').slice(0, 80) || `facebook_video_${index}`;
  return `${base}.${ext}`;
}

function normalizeType(mime, kind, url) {
  const clean = String(mime || '').split(';')[0].toLowerCase();
  if (/^(image|video)\//.test(clean)) return clean;
  const ext = guessExtensionFromUrl(url, kind);
  const types = { webp:'image/webp', png:'image/png', jpg:'image/jpeg', mp4:'video/mp4', webm:'video/webm', mov:'video/quicktime' };
  return types[ext] || (kind === 'video' ? 'video/mp4' : 'image/jpeg');
}

function extensionFromType(mime, url) {
  const types = { 'image/webp':'webp','image/png':'png','image/jpeg':'jpg','video/mp4':'mp4','video/webm':'webm','video/quicktime':'mov','image/gif':'gif' };
  return types[mime] || guessExtensionFromUrl(url,'image');
}

function guessExtensionFromUrl(url, kind) {
  const match = String(url || '').match(/\.(webp|png|jpe?g|gif|mp4|webm|mov)(?:$|[?#])/i);
  if (match) return match[1].toLowerCase().replace('jpeg','jpg');
  const param = String(url || '').match(/(?:format|fm|ext)=(webp|png|jpe?g|gif|mp4|webm|mov)(?:&|$)/i);
  if (param) return param[1].toLowerCase().replace('jpeg','jpg');
  return kind === 'video' ? 'mp4' : 'jpg';
}

function buildFilename(index, ext) {
  const date = new Date().toISOString().slice(0,10).replaceAll('-','');
  const author = String(page.author || 'facebook').replace(/[\\/:*?"<>|\u0000-\u001f]/g,'_').replace(/\s+/g,'_').slice(0,50) || 'facebook';
  return `${date}_${author}_${String(index).padStart(2,'0')}.${ext}`;
}

function shortUrlName(url) {
  try {
    const u = new URL(url);
    return (u.pathname.split('/').pop() || u.hostname).slice(0,80);
  } catch (_) {
    return String(url || '').slice(0,80);
  }
}
