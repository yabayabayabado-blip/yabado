chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type !== 'SCAN_FACEBOOK_VIDEOS') return;
  try {
    sendResponse({ ok: true, ...scanFacebookVideos() });
  } catch (error) {
    sendResponse({ ok: false, error: error?.message || 'Facebook 影片掃描失敗' });
  }
});

function scanFacebookVideos() {
  const found = new Map();
  const scope = findBestScope();

  const add = (rawUrl, source = 'dom', priority = 10) => {
    if (!rawUrl || /^blob:/i.test(rawUrl)) return;
    try {
      const parsedUrl = new URL(decodeFacebookEscapedUrl(rawUrl), location.href).href;
      if (!/^https?:\/\//i.test(parsedUrl)) return;
      if (!isLikelyFacebookVideoUrl(parsedUrl)) return;
      const fullUrl = stripFacebookByteRange(parsedUrl);
      const key = normalizeVideoKey(fullUrl);
      const existing = found.get(key);
      if (!existing || priority > Number(existing.priority || 0)) {
        found.set(key, {
          url: fullUrl,
          originalUrl: parsedUrl,
          kind: 'video',
          source,
          priority,
          progressive: /page-(?:native|playable)|meta|video-(?:currentSrc|src)/.test(source)
        });
      }
    } catch (_) { }
  };

  scope.querySelectorAll('video').forEach((video) => {
    add(video.currentSrc, 'video-currentSrc', 90);
    add(video.src, 'video-src', 85);
    video.querySelectorAll('source').forEach((source) => {
      add(source.src, 'source-src', 85);
      for (const candidate of parseSrcset(source.srcset)) add(candidate, 'source-srcset', 80);
    });
    for (const attr of ['data-src', 'data-video-url', 'data-href']) add(video.getAttribute(attr), 'video-data', 75);
  });

  document.querySelectorAll('meta[property="og:video"], meta[property="og:video:url"], meta[property="og:video:secure_url"], meta[name="twitter:player:stream"]').forEach((meta) => add(meta.content, 'meta', 95));

  // Facebook 會把可直接播放/下載的 progressive URL 放在 hydration JSON 裡。
  // 不只掃 script.textContent，也掃目前 DOM HTML，因為新版 Facebook 會把資料動態塞入頁面。
  const chunks = [...document.scripts].map((script) => script.textContent || '');
  try { chunks.push(document.documentElement.innerHTML || ''); } catch (_) { }
  const sourceText = chunks.join('\n');
  extractNamedFacebookVideoUrls(sourceText).forEach(({ url, field }) => {
    const priority = /browser_native_hd_url/i.test(field) ? 130
      : /playable_url_quality_hd/i.test(field) ? 125
      : /browser_native_sd_url/i.test(field) ? 120
      : 115;
    add(url, /browser_native/i.test(field) ? 'page-native' : 'page-playable', priority);
  });

  // blob: 播放時，實際 CDN 位址通常仍會出現在 performance resource。
  performance.getEntriesByType('resource').forEach((entry) => add(entry.name, 'resource', 30));

  const canonical = document.querySelector('link[rel="canonical"]')?.href || location.href;
  const title = document.querySelector('meta[property="og:title"]')?.content || document.title || 'Facebook 影片';
  return {
    items: [...found.values()],
    page: {
      url: canonical,
      title: title.replace(/\s*\|\s*Facebook.*$/i, '').trim() || 'Facebook 影片',
      author: extractAuthor()
    }
  };
}

function extractNamedFacebookVideoUrls(text) {
  const results = [];
  const fields = ['browser_native_hd_url', 'browser_native_sd_url', 'playable_url_quality_hd', 'playable_url'];
  for (const field of fields) {
    const re = new RegExp(`${field}[^:]{0,80}:\\s*(?:\\\\?\")([^\"<]{20,})`, 'gi');
    for (const match of String(text || '').matchAll(re)) {
      let candidate = match[1];
      candidate = candidate.split(/(?:\\?\"|&quot;|<)/)[0];
      candidate = decodeFacebookEscapedUrl(candidate);
      if (/^https?:\/\//i.test(candidate)) results.push({ field, url: candidate });
    }
  }
  // 再補抓 HTML entity / escaped key 的常見格式。
  const broad = /(?:browser_native_(?:hd|sd)_url|playable_url(?:_quality_hd)?)[^h]{0,160}(https?:\\?\/\\?\/[^\"'<\\s]{20,})/gi;
  for (const match of String(text || '').matchAll(broad)) {
    const url = decodeFacebookEscapedUrl(match[1]);
    if (/^https?:\/\//i.test(url)) results.push({ field: match[0].split(/[^a-z_]/i)[0] || 'playable_url', url });
  }
  return results;
}

function findBestScope() {
  const videos = [...document.querySelectorAll('video')].filter((video) => {
    const r = video.getBoundingClientRect();
    return r.width >= 160 && r.height >= 90 && r.bottom > 0 && r.right > 0 && r.top < innerHeight && r.left < innerWidth;
  });
  if (videos.length) {
    const video = videos.sort((a, b) => visibleArea(b) - visibleArea(a))[0];
    return video.closest('[role="article"], article, [data-pagelet*="FeedUnit"]') || video.parentElement || document;
  }
  return document.querySelector('[role="main"]') || document.querySelector('main') || document;
}

function visibleArea(node) {
  const r = node.getBoundingClientRect();
  const w = Math.max(0, Math.min(r.right, innerWidth) - Math.max(r.left, 0));
  const h = Math.max(0, Math.min(r.bottom, innerHeight) - Math.max(r.top, 0));
  return w * h;
}

function parseSrcset(srcset) {
  if (!srcset) return [];
  return String(srcset).split(',').map((part) => part.trim().split(/\s+/)[0]).filter(Boolean);
}

function isLikelyFacebookVideoUrl(value) {
  const raw = String(value || '');
  if (!/^https?:\/\//i.test(raw)) return false;
  try {
    const u = new URL(raw);
    const host = u.hostname.toLowerCase();
    if (!(host === 'fbcdn.net' || host.endsWith('.fbcdn.net') || host === 'cdninstagram.com' || host.endsWith('.cdninstagram.com'))) return false;
    if (/\.(?:jpg|jpeg|png|gif|webp|avif)(?:$|[?#])/i.test(u.href)) return false;
    return /(?:\.mp4(?:$|[?#])|mime_type=video|mime=video|video%2F|\/video\/|\/v\/t\d+|\/o1\/v\/|bytestart=|byteend=)/i.test(u.href);
  } catch (_) { return false; }
}

function decodeFacebookEscapedUrl(value) {
  let out = String(value || '');
  for (let i = 0; i < 3; i += 1) {
    out = out
      .replace(/&amp;/gi, '&')
      .replace(/\\u0025/gi, '%')
      .replace(/\\u0026/gi, '&')
      .replace(/\\u003d/gi, '=')
      .replace(/\\u002f/gi, '/')
      .replace(/\\u003a/gi, ':')
      .replace(/\\\//g, '/')
      .replace(/\\x26/gi, '&');
  }
  return out;
}

function stripFacebookByteRange(value) {
  try {
    const u = new URL(value);
    u.searchParams.delete('bytestart');
    u.searchParams.delete('byteend');
    u.searchParams.delete('start');
    u.searchParams.delete('end');
    return u.href;
  } catch (_) { return String(value || ''); }
}

function normalizeVideoKey(value) {
  try {
    const u = new URL(stripFacebookByteRange(value));
    u.hash = '';
    return u.href;
  } catch (_) { return String(value || ''); }
}

function extractAuthor() {
  const og = document.querySelector('meta[property="og:title"]')?.content || '';
  if (og) return og.split('|')[0].trim().slice(0, 60) || 'facebook';
  return 'facebook';
}
