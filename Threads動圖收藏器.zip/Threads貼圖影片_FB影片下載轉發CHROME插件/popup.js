const captureButton = document.querySelector('#captureButton');
const saveButton = document.querySelector('#saveButton');
const libraryButton = document.querySelector('#libraryButton');
const otherMediaButton = document.querySelector('#otherMediaButton');
const facebookVideoButton = document.querySelector('#facebookVideoButton');
const threadsStatusNode = document.querySelector('#threadsStatus');
const facebookStatusNode = document.querySelector('#facebookStatus');
const countBadge = document.querySelector('#countBadge');

refreshCount();
captureButton.addEventListener('click', () => capture(true));
saveButton.addEventListener('click', () => capture(false));
libraryButton.addEventListener('click', () => chrome.runtime.sendMessage({ type: 'OPEN_LIBRARY' }));
otherMediaButton.addEventListener('click', openOtherMedia);
facebookVideoButton.addEventListener('click', openFacebookVideo);

async function capture(shouldDownload) {
  setBusy(true);
  showThreadsStatus('正在辨識貼文中的動圖…');
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id || !/^https:\/\/(?:[^/]+\.)?threads\.com\//i.test(tab.url || '')) {
      throw new Error('目前頁面不是 Threads，請先開啟要擷取的貼文。');
    }

    const scan = await chrome.tabs.sendMessage(tab.id, { type: 'SCAN_THREADS_MEDIA' });
    if (!scan?.ok) throw new Error(scan?.error || '無法讀取此貼文。');
    if (!scan.items?.length) {
      throw new Error('目前貼文未找到動圖。請先播放動圖或滑過貼文內容，再按一次。');
    }

    showThreadsStatus(`找到 ${scan.items.length} 個動圖來源，正在保存…`);
    const stored = await chrome.runtime.sendMessage({
      type: 'STORE_MEDIA_BATCH',
      items: scan.items,
      page: scan.page
    });
    if (!stored?.ok && !stored?.saved?.length) throw new Error(stored?.error || '保存失敗。');

    const savedEntries = stored.saved || [];
    const newIds = [...new Set(savedEntries.filter((entry) => !entry.existing).map((entry) => entry.id))];
    const downloadedCount = shouldDownload && newIds.length ? await downloadIds(newIds) : 0;
    if (downloadedCount > 0) {
      try { await chrome.runtime.sendMessage({ type: 'REFRESH_FOLDER_INDEX_SIGNATURE' }); } catch (_) { }
    }

    const newCount = newIds.length;
    const skippedCount = stored.skipped || 0;
    const failedText = stored.failed?.length ? `，另有 ${stored.failed.length} 個來源無法取得` : '';
    showThreadsStatus(
      shouldDownload
        ? `完成：下載 ${downloadedCount} 個 GIF，新增收藏 ${newCount} 個，略過重複 ${skippedCount} 個${failedText}。`
        : `完成：新增收藏 ${newCount} 個，略過重複 ${skippedCount} 個${failedText}。`,
      'success'
    );
    await refreshCount();
  } catch (error) {
    const message = error?.message?.includes('Receiving end does not exist')
      ? '擴充功能剛安裝或更新，請重新整理 Threads 頁面後再試。'
      : error?.message || '執行失敗。';
    showThreadsStatus(message, 'error');
  } finally {
    setBusy(false);
  }
}

async function downloadIds(ids) {
  let downloaded = 0;
  for (const id of ids) {
    const item = await getMedia(id);
    if (!item?.blob) continue;
    const isGif = item.mime === 'image/gif' || String(item.extension || '').toLowerCase() === 'gif';
    if (!isGif) continue;

    const objectUrl = URL.createObjectURL(item.blob);
    try {
      const downloadId = await chrome.downloads.download({
        url: objectUrl,
        filename: `Threads動圖/${item.filename.replace(/\.[^.]+$/, '.gif')}`,
        conflictAction: 'uniquify',
        saveAs: false
      });
      downloaded += 1;
      const localPath = await waitForDownloadPath(downloadId);
      if (localPath) {
        item.localFilePath = localPath;
        item.recoveredFromDownload = true;
        await putMedia(item);
      }
    } finally {
      setTimeout(() => URL.revokeObjectURL(objectUrl), 60_000);
    }
  }
  return downloaded;
}

async function waitForDownloadPath(downloadId) {
  for (let attempt = 0; attempt < 20; attempt += 1) {
    const items = await chrome.downloads.search({ id: downloadId });
    const path = String(items?.[0]?.filename || '');
    if (path) return path;
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  return '';
}

async function refreshCount() {
  try {
    // popup.html 已載入 idb.js；直接讀同一個 IndexedDB，避免 service worker 尚未啟動時先顯示 0。
    const items = await getAllMedia();
    countBadge.textContent = String(items.length);
    return;
  } catch (_) { }

  try {
    const response = await chrome.runtime.sendMessage({ type: 'GET_LIBRARY_COUNT' });
    countBadge.textContent = response?.ok ? String(response.count) : '—';
  } catch (_) {
    countBadge.textContent = '—';
  }
}

function setBusy(isBusy) {
  captureButton.disabled = isBusy;
  saveButton.disabled = isBusy;
  otherMediaButton.disabled = isBusy;
  facebookVideoButton.disabled = isBusy;
}

async function openOtherMedia() {
  setBusy(true);
  showThreadsStatus('正在掃描貼文中的其他媒體…');
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id || !/^https:\/\/(?:[^/]+\.)?threads\.com\//i.test(tab.url || '')) {
      throw new Error('目前頁面不是 Threads，請先開啟要擷取的貼文。');
    }
    let scan = await chrome.tabs.sendMessage(tab.id, { type: 'SCAN_THREADS_ALL_MEDIA' });
    // 相容更新前已開啟的 Threads 分頁；若舊 content script 不認識新指令，改用舊掃描指令。
    if (!scan?.ok) scan = await chrome.tabs.sendMessage(tab.id, { type: 'SCAN_THREADS_OTHER_MEDIA' });
    if (!scan?.ok) throw new Error(scan?.error || '無法讀取此貼文。');
    const candidates = Array.isArray(scan.items) ? scan.items.filter((item) => !/\.gif(?:$|[?#])/i.test(item?.url || '') && !/(?:format|fm|ext)=gif(?:&|$)/i.test(item?.url || '')) : [];
    if (!candidates.length) throw new Error('目前貼文未找到 GIF 以外可下載的媒體。');
    await chrome.storage.local.set({ threadsOtherMediaScan: { items: candidates, page: scan.page, scannedAt: Date.now() } });
    await chrome.tabs.create({ url: chrome.runtime.getURL('other-media.html') });
    showThreadsStatus(`找到 ${candidates.length} 個其他媒體。`, 'success');
  } catch (error) {
    const message = error?.message?.includes('Receiving end does not exist')
      ? '擴充功能剛安裝或更新，請重新整理 Threads 頁面後再試。'
      : error?.message || '執行失敗。';
    showThreadsStatus(message, 'error');
  } finally {
    setBusy(false);
  }
}

function showThreadsStatus(message, kind = '') {
  threadsStatusNode.textContent = message;
  threadsStatusNode.className = `status section-note ${kind}`.trim();
}

function showFacebookStatus(message, kind = '') {
  facebookStatusNode.textContent = message;
  facebookStatusNode.className = `status section-note facebook-note ${kind}`.trim();
}


async function openFacebookVideo() {
  setBusy(true);
  showFacebookStatus('正在分析 Facebook 完整影片來源…');
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id || !/^https:\/\/(?:[^/]+\.)?(?:facebook\.com|fb\.watch)\//i.test(tab.url || '')) {
      throw new Error('目前頁面不是 Facebook，請先開啟含有影片的 Facebook 頁面。');
    }
    let scan = null;
    try {
      scan = await chrome.tabs.sendMessage(tab.id, { type: 'SCAN_FACEBOOK_VIDEOS' });
    } catch (_) {
      scan = { ok: false, items: [], page: { url: tab.url, title: 'Facebook 影片', author: 'facebook' } };
    }
    const network = await chrome.runtime.sendMessage({ type: 'GET_FACEBOOK_VIDEO_REQUESTS', tabId: tab.id }).catch(() => ({ ok: false, items: [] }));
    const merged = [
      ...(Array.isArray(scan?.items) ? scan.items : []),
      ...(Array.isArray(network?.items) ? network.items.map((item) => ({ ...item, priority: Number(item.priority || 20) })) : [])
    ].filter((item) => item?.url && ['video','audio','unknown'].includes(item.kind || 'unknown'));

    const byFullUrl = new Map();
    for (const item of merged) {
      try {
        const originalUrl = new URL(item.url);
        const fullUrl = new URL(originalUrl.href);
        fullUrl.hash = '';
        fullUrl.searchParams.delete('bytestart');
        fullUrl.searchParams.delete('byteend');
        fullUrl.searchParams.delete('start');
        fullUrl.searchParams.delete('end');
        const key = fullUrl.href;
        const next = {
          ...item,
          originalUrl: item.originalUrl || originalUrl.href,
          url: key,
          fullUrl: key,
          priority: Number(item.priority || (String(item.source || '').startsWith('page-') ? 100 : 20))
        };
        const old = byFullUrl.get(key);
        if (!old || next.priority > Number(old.priority || 0) || Number(next.sizeBytes || 0) > Number(old.sizeBytes || 0)) {
          byFullUrl.set(key, next);
        }
      } catch (_) { }
    }

    const candidates = [...byFullUrl.values()];
    if (!candidates.length) {
      throw new Error('目前尚未偵測到 Facebook 影片資料。請讓影片實際開始播放後再按一次。');
    }
    const pageInfo = scan?.page || { url: tab.url, title: tab.title || 'Facebook 影片', author: 'facebook' };
    await chrome.storage.local.set({ facebookVideoScan: { items: candidates, page: pageInfo, scannedAt: Date.now(), version: '2.7.8' } });
    await chrome.tabs.create({ url: chrome.runtime.getURL('fb-video.html') });
    showFacebookStatus(`已取得 ${candidates.length} 個候選串流，正在辨識完整影片。`, 'success');
  } catch (error) {
    const message = error?.message?.includes('Receiving end does not exist')
      ? '擴充功能剛安裝或更新，請重新整理 Facebook 頁面後再試。'
      : error?.message || '執行失敗。';
    showFacebookStatus(message, 'error');
  } finally {
    setBusy(false);
  }
}
