﻿$ErrorActionPreference = "Stop"
$hostName = "com.cjcu.threads_line_clipboard"
$registryPath = "HKCU:\Software\Google\Chrome\NativeMessagingHosts\$hostName"
$installDirectory = Join-Path $env:LOCALAPPDATA "ThreadsMotionClipboardHost"

# Unregister first to prevent Chrome from starting a new host while removing files.
if (Test-Path $registryPath) {
    Remove-Item $registryPath -Recurse -Force -ErrorAction SilentlyContinue
}

for ($attempt = 1; $attempt -le 10; $attempt++) {
    Get-Process -Name "threads-line-host" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
    Start-Sleep -Milliseconds 250
    if (-not (Get-Process -Name "threads-line-host" -ErrorAction SilentlyContinue)) { break }
}

if (Test-Path $installDirectory) {
    for ($attempt = 1; $attempt -le 12; $attempt++) {
        try {
            Remove-Item $installDirectory -Recurse -Force -ErrorAction Stop
            break
        }
        catch {
            Get-Process -Name "threads-line-host" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
            Start-Sleep -Milliseconds 300
            if ($attempt -eq 12) { throw }
        }
    }
}
Write-Host "LINE auto-paste bridge removed." -ForegroundColor Green
