﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using System.Reflection;
using Microsoft.Win32;

internal static class ThreadsLineHost
{
    private const int MaxMessageBytes = 64 * 1024 * 1024;
    private const int MaxFileBytes = 45 * 1024 * 1024;
    private const long MaxTransferBytes = 1024L * 1024L * 1024L;
    private static readonly JavaScriptSerializer Json = new JavaScriptSerializer { MaxJsonLength = MaxMessageBytes };
    private delegate bool EnumWindowsCallback(IntPtr hWnd, IntPtr lParam);
    private delegate bool EnumChildWindowsCallback(IntPtr hWnd, IntPtr lParam);

    private sealed class LineWindowInfo
    {
        public string id { get; set; }
        public string title { get; set; }
    }

    [DllImport("user32.dll")]
    private static extern bool EnumWindows(EnumWindowsCallback callback, IntPtr lParam);

    [DllImport("user32.dll")]
    private static extern bool EnumChildWindows(IntPtr hWndParent, EnumChildWindowsCallback callback, IntPtr lParam);

    [DllImport("user32.dll")]
    private static extern bool IsWindow(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern bool IsWindowVisible(IntPtr hWnd);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int GetWindowTextLength(IntPtr hWnd);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int maxCount);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int GetClassName(IntPtr hWnd, StringBuilder className, int maxCount);

    [DllImport("user32.dll")]
    private static extern bool IsWindowEnabled(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern bool GetWindowRect(IntPtr hWnd, out RECT rect);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern IntPtr SendMessage(IntPtr hWnd, uint msg, IntPtr wParam, string lParam);

    [StructLayout(LayoutKind.Sequential)]
    private struct RECT
    {
        public int Left;
        public int Top;
        public int Right;
        public int Bottom;
    }

    private const uint WM_SETTEXT = 0x000C;

    [DllImport("user32.dll")]
    private static extern bool SetForegroundWindow(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);

    [DllImport("user32.dll")]
    private static extern IntPtr GetForegroundWindow();

    [DllImport("user32.dll", EntryPoint = "GetWindowThreadProcessId")]
    private static extern uint GetWindowThreadIdForFocus(IntPtr hWnd, IntPtr processId);

    [DllImport("user32.dll", EntryPoint = "GetWindowThreadProcessId")]
    private static extern uint GetWindowThreadIdAndProcess(IntPtr hWnd, out uint processId);

    [DllImport("kernel32.dll")]
    private static extern uint GetCurrentThreadId();

    [DllImport("user32.dll")]
    private static extern bool AttachThreadInput(uint idAttach, uint idAttachTo, bool attach);

    [DllImport("user32.dll")]
    private static extern bool BringWindowToTop(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern IntPtr SetFocus(IntPtr hWnd);

    [STAThread]
    private static void Main()
    {
        try
        {
            Dictionary<string, object> request = ReadMessage();
            string action = GetString(request, "action");
            if (action == "ping")
            {
                List<LineWindowInfo> windows = GetLineWindows();
                string ffmpeg = ResolveFfmpegPath();
                WriteMessage(new { ok = true, version = "2.7.8", lineRunning = windows.Count > 0, windowCount = windows.Count, ffmpegAvailable = !string.IsNullOrWhiteSpace(ffmpeg) });
                return;
            }
            if (action == "list_line_windows") { ListLineWindows(); return; }
            if (action == "copy_file") { CopyFile(request); return; }
            if (action == "open_folder") { OpenFolder(request); return; }
            if (action == "read_file") { ReadFile(request); return; }
            if (action == "list_folder") { ListFolder(request); return; }
            if (action == "delete_file") { DeleteFile(request); return; }
            if (action == "paste_file") { PasteFile(request); return; }
            if (action == "paste_and_send_file") { PasteAndSendFile(request); return; }
            if (action == "begin_temp_transfer") { BeginTempTransfer(request); return; }
            if (action == "append_temp_chunk") { AppendTempChunk(request); return; }
            if (action == "mux_temp_files") { MuxTempFiles(request); return; }
            if (action == "save_temp_file_to_downloads") { SaveTempFileToDownloads(request); return; }
            if (action == "send_temp_file") { SendTempFile(request); return; }
            if (action == "cancel_temp_transfer") { CancelTempTransfer(request); return; }
            if (action == "temp_status") { TempStatus(); return; }
            if (action == "open_temp_folder") { OpenTempFolder(); return; }
            if (action == "clear_temp_files") { ClearTempFiles(); return; }
            if (action == "send_enter_and_clear") { SendEnterAndClear(request); return; }
            if (action == "clear_clipboard") { ClearClipboard(); WriteMessage(new { ok = true, cleared = true }); return; }
            throw new InvalidOperationException("unsupported_action");
        }
        catch (Exception error)
        {
            WriteMessage(new { ok = false, error = error.Message });
        }
    }

    private static void ReadFile(Dictionary<string, object> request)
    {
        string filePath = GetString(request, "filePath");
        if (string.IsNullOrWhiteSpace(filePath)) throw new InvalidOperationException("file_path_missing");
        filePath = Path.GetFullPath(filePath);
        string normalized = filePath.Replace('/', '\\');
        string marker = "\\Threads動圖\\";
        if (normalized.IndexOf(marker, StringComparison.OrdinalIgnoreCase) < 0)
            throw new InvalidOperationException("file_path_not_allowed");
        if (!File.Exists(filePath)) throw new InvalidOperationException("file_not_found");
        FileInfo info = new FileInfo(filePath);
        if (info.Length <= 0) throw new InvalidOperationException("empty_file");
        if (info.Length > MaxFileBytes) throw new InvalidOperationException("file_too_large");
        byte[] bytes = File.ReadAllBytes(filePath);
        WriteMessage(new { ok = true, base64 = Convert.ToBase64String(bytes), bytes = bytes.Length, filename = Path.GetFileName(filePath) });
    }


    private static void ListFolder(Dictionary<string, object> request)
    {
        string folderPath = GetString(request, "folderPath");
        if (string.IsNullOrWhiteSpace(folderPath)) throw new InvalidOperationException("folder_path_missing");
        folderPath = Path.GetFullPath(folderPath);
        string folderName = Path.GetFileName(folderPath.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar));
        if (!string.Equals(folderName, "Threads動圖", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("folder_path_not_allowed");
        if (!Directory.Exists(folderPath)) throw new InvalidOperationException("folder_not_found");

        string[] allowed = { ".gif", ".png", ".webp", ".jpg", ".jpeg", ".mp4", ".webm", ".mov", ".m4a", ".aac", ".mp3", ".opus" };
        var files = Directory.EnumerateFiles(folderPath, "*", SearchOption.TopDirectoryOnly)
            .Where(path => allowed.Contains(Path.GetExtension(path).ToLowerInvariant()))
            .Select(path => new FileInfo(path))
            .Where(info => info.Exists && info.Length > 0 && info.Length <= MaxFileBytes)
            .OrderBy(info => info.Name, StringComparer.OrdinalIgnoreCase)
            .Select(info => new {
                path = info.FullName,
                filename = info.Name,
                bytes = info.Length,
                modifiedAt = info.LastWriteTimeUtc.ToString("o")
            })
            .ToArray();

        WriteMessage(new { ok = true, folderPath = folderPath, files = files });
    }

    private static void DeleteFile(Dictionary<string, object> request)
    {
        string filePath = GetString(request, "filePath");
        if (string.IsNullOrWhiteSpace(filePath)) throw new InvalidOperationException("file_path_missing");
        filePath = Path.GetFullPath(filePath);
        string parent = Path.GetDirectoryName(filePath) ?? "";
        string folderName = Path.GetFileName(parent.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar));
        if (!string.Equals(folderName, "Threads動圖", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("file_path_not_allowed");
        if (!File.Exists(filePath))
        {
            WriteMessage(new { ok = true, deleted = false, missing = true, filePath = filePath });
            return;
        }
        File.Delete(filePath);
        WriteMessage(new { ok = true, deleted = true, filePath = filePath });
    }

    private static void OpenFolder(Dictionary<string, object> request)
    {
        string folderPath = GetString(request, "folderPath");
        if (string.IsNullOrWhiteSpace(folderPath)) throw new InvalidOperationException("folder_path_missing");
        folderPath = Path.GetFullPath(folderPath);
        if (!Directory.Exists(folderPath)) throw new InvalidOperationException("folder_not_found");
        Process.Start(new ProcessStartInfo
        {
            FileName = "explorer.exe",
            Arguments = "\"" + folderPath + "\"",
            UseShellExecute = true
        });
        WriteMessage(new { ok = true, opened = true, folderPath = folderPath });
    }

    private static void PasteFile(Dictionary<string, object> request)
    {
        IntPtr lineWindow = ResolveLineWindow(request);
        string filePath = SaveTemporaryFile(request);
        SetClipboardFile(filePath);
        if (!FocusLineWindow(lineWindow)) throw new InvalidOperationException("line_focus_failed");
        Thread.Sleep(180);
        SendKeys.SendWait("^v");
        Thread.Sleep(320);
        if (GetBoolean(request, "confirmImageMode"))
        {
            // LINE 第一次貼上會詢問要貼「圖片」或「文字」，預設焦點為圖片。
            SendKeys.SendWait("{ENTER}");
            Thread.Sleep(320);
        }
        WriteMessage(new { ok = true, pasted = true, bytes = new FileInfo(filePath).Length });
    }

    private static void PasteAndSendFile(Dictionary<string, object> request)
    {
        IntPtr lineWindow = ResolveLineWindow(request);
        string filePath = SaveTemporaryFile(request);
        SetClipboardFile(filePath);
        if (!FocusLineWindow(lineWindow)) throw new InvalidOperationException("line_focus_failed");

        // 每一張都完整走完 LINE 的貼圖流程：貼上 -> Enter 選擇「圖片」 -> Enter 送出。
        Thread.Sleep(220);
        SendKeys.SendWait("^v");
        Thread.Sleep(420);
        SendKeys.SendWait("{ENTER}");
        Thread.Sleep(520);
        SendKeys.SendWait("{ENTER}");
        Thread.Sleep(700);

        WriteMessage(new { ok = true, pasted = true, sent = true, bytes = new FileInfo(filePath).Length });
    }

    private static void CopyFile(Dictionary<string, object> request)
    {
        string filePath = SaveTemporaryFile(request);
        SetClipboardFile(filePath);
        WriteMessage(new { ok = true, copied = true, bytes = new FileInfo(filePath).Length });
    }

    private static void SendEnterAndClear(Dictionary<string, object> request)
    {
        IntPtr lineWindow = ResolveLineWindow(request);
        if (!FocusLineWindow(lineWindow)) throw new InvalidOperationException("line_focus_failed");
        Thread.Sleep(180);
        SendKeys.SendWait("{ENTER}");
        Thread.Sleep(260);
        ClearClipboard();
        WriteMessage(new { ok = true, sent = true, cleared = true });
    }

    private static string GetTempDirectory()
    {
        string tempDirectory = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "ThreadsMotionClipboardHost",
            "Temp"
        );
        Directory.CreateDirectory(tempDirectory);
        CleanOldFiles(tempDirectory);
        return tempDirectory;
    }

    private static string SanitizeTransferId(string value)
    {
        string raw = value ?? string.Empty;
        string clean = new string(raw.Where(c => char.IsLetterOrDigit(c) || c == '_' || c == '-').ToArray());
        if (clean.Length < 8 || clean.Length > 120) throw new InvalidOperationException("invalid_transfer_id");
        return clean;
    }

    private static string GetTransferPath(string transferId)
    {
        string id = SanitizeTransferId(transferId);
        string directory = GetTempDirectory();
        string[] files = Directory.GetFiles(directory, id + ".*")
            .Where(path => !string.Equals(Path.GetExtension(path), ".active", StringComparison.OrdinalIgnoreCase))
            .ToArray();
        if (files.Length == 0) throw new InvalidOperationException("transfer_not_found");
        return files[0];
    }

    private static void BeginTempTransfer(Dictionary<string, object> request)
    {
        string transferId = SanitizeTransferId(GetString(request, "transferId"));
        string requestedName = Path.GetFileName(GetString(request, "filename"));
        string extension = Path.GetExtension(requestedName).ToLowerInvariant();
        string[] allowed = { ".gif", ".png", ".webp", ".jpg", ".jpeg", ".mp4", ".webm", ".mov", ".m4a", ".aac", ".mp3", ".opus" };
        if (!allowed.Contains(extension)) throw new InvalidOperationException("unsupported_media_format");
        long expectedBytes = 0;
        object rawExpected;
        if (request.TryGetValue("expectedBytes", out rawExpected) && rawExpected != null)
            long.TryParse(Convert.ToString(rawExpected), out expectedBytes);
        if (expectedBytes <= 0) throw new InvalidOperationException("empty_file");
        if (expectedBytes > MaxTransferBytes) throw new InvalidOperationException("transfer_too_large");

        string directory = GetTempDirectory();
        foreach (string old in Directory.GetFiles(directory, transferId + ".*"))
        {
            try { File.Delete(old); } catch { }
        }
        string filePath = Path.Combine(directory, transferId + extension);
        using (FileStream stream = new FileStream(filePath, FileMode.CreateNew, FileAccess.Write, FileShare.Read)) { }
        File.WriteAllText(Path.Combine(directory, transferId + ".active"), DateTime.UtcNow.ToString("o"), Encoding.UTF8);
        WriteMessage(new { ok = true, transferId = transferId, expectedBytes = expectedBytes });
    }

    private static void AppendTempChunk(Dictionary<string, object> request)
    {
        string transferId = SanitizeTransferId(GetString(request, "transferId"));
        string filePath = GetTransferPath(transferId);
        string base64 = GetString(request, "base64");
        byte[] bytes = Convert.FromBase64String(base64);
        if (bytes.Length == 0) throw new InvalidOperationException("empty_chunk");
        FileInfo before = new FileInfo(filePath);
        if (before.Length + bytes.LongLength > MaxTransferBytes) throw new InvalidOperationException("transfer_too_large");
        using (FileStream stream = new FileStream(filePath, FileMode.Append, FileAccess.Write, FileShare.Read))
        {
            stream.Write(bytes, 0, bytes.Length);
        }
        WriteMessage(new { ok = true, bytes = new FileInfo(filePath).Length });
    }


    private static string ResolveFfmpegPath()
    {
        try
        {
            string env = Environment.GetEnvironmentVariable("FFMPEG_EXE") ?? string.Empty;
            if (!string.IsNullOrWhiteSpace(env) && File.Exists(env)) return env;
        }
        catch { }

        try
        {
            Process process = Process.Start(new ProcessStartInfo {
                FileName = "where.exe", Arguments = "ffmpeg.exe", UseShellExecute = false,
                RedirectStandardOutput = true, RedirectStandardError = true, CreateNoWindow = true
            });
            if (process != null)
            {
                string output = process.StandardOutput.ReadToEnd();
                process.WaitForExit(3000);
                string first = output.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries).FirstOrDefault();
                if (!string.IsNullOrWhiteSpace(first) && File.Exists(first.Trim())) return first.Trim();
            }
        }
        catch { }

        string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        string programFiles = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
        string[] directCandidates = {
            Path.Combine(local, "Microsoft", "WinGet", "Links", "ffmpeg.exe"),
            Path.Combine(programFiles, "ffmpeg", "bin", "ffmpeg.exe"),
            Path.Combine(programFiles, "FFmpeg", "bin", "ffmpeg.exe")
        };
        foreach (string candidate in directCandidates)
            if (!string.IsNullOrWhiteSpace(candidate) && File.Exists(candidate)) return candidate;

        try
        {
            string packages = Path.Combine(local, "Microsoft", "WinGet", "Packages");
            if (Directory.Exists(packages))
            {
                string found = Directory.EnumerateFiles(packages, "ffmpeg.exe", SearchOption.AllDirectories).FirstOrDefault();
                if (!string.IsNullOrWhiteSpace(found)) return found;
            }
        }
        catch { }
        return string.Empty;
    }

    private static string QuoteArg(string value)
    {
        return "\"" + (value ?? string.Empty).Replace("\"", "\\\"") + "\"";
    }

    private static bool RunFfmpegMux(string ffmpeg, string videoPath, string audioPath, string outputPath, bool transcodeAudio, out string errorText)
    {
        string audioArgs = transcodeAudio ? "-c:a aac -b:a 160k" : "-c:a copy";
        string args = "-hide_banner -loglevel error -y -i " + QuoteArg(videoPath) + " -i " + QuoteArg(audioPath) +
            " -map 0:v:0 -map 1:a:0 -c:v copy " + audioArgs + " -shortest -movflags +faststart " + QuoteArg(outputPath);
        Process process = Process.Start(new ProcessStartInfo {
            FileName = ffmpeg, Arguments = args, UseShellExecute = false,
            RedirectStandardOutput = true, RedirectStandardError = true, CreateNoWindow = true
        });
        if (process == null) { errorText = "ffmpeg_start_failed"; return false; }
        string stderr = process.StandardError.ReadToEnd();
        process.WaitForExit();
        errorText = stderr;
        return process.ExitCode == 0 && File.Exists(outputPath) && new FileInfo(outputPath).Length > 0;
    }

    private static void DeleteTransferAndMarker(string transferId)
    {
        try
        {
            string path = GetTransferPath(transferId);
            if (File.Exists(path)) File.Delete(path);
        }
        catch { }
        try
        {
            string marker = Path.Combine(GetTempDirectory(), SanitizeTransferId(transferId) + ".active");
            if (File.Exists(marker)) File.Delete(marker);
        }
        catch { }
    }

    private static void MuxTempFiles(Dictionary<string, object> request)
    {
        string videoId = SanitizeTransferId(GetString(request, "videoTransferId"));
        string audioId = SanitizeTransferId(GetString(request, "audioTransferId"));
        string outputId = SanitizeTransferId(GetString(request, "outputTransferId"));
        string videoPath = GetTransferPath(videoId);
        string audioPath = GetTransferPath(audioId);
        string ffmpeg = ResolveFfmpegPath();
        if (string.IsNullOrWhiteSpace(ffmpeg)) throw new InvalidOperationException("ffmpeg_missing");

        string directory = GetTempDirectory();
        foreach (string old in Directory.GetFiles(directory, outputId + ".*"))
        {
            try { File.Delete(old); } catch { }
        }
        string outputPath = Path.Combine(directory, outputId + ".mp4");
        string errorText;
        bool ok = RunFfmpegMux(ffmpeg, videoPath, audioPath, outputPath, false, out errorText);
        if (!ok)
        {
            try { if (File.Exists(outputPath)) File.Delete(outputPath); } catch { }
            ok = RunFfmpegMux(ffmpeg, videoPath, audioPath, outputPath, true, out errorText);
        }
        if (!ok) throw new InvalidOperationException("ffmpeg_mux_failed");

        File.WriteAllText(Path.Combine(directory, outputId + ".active"), DateTime.UtcNow.ToString("o"), Encoding.UTF8);
        long bytes = new FileInfo(outputPath).Length;
        DeleteTransferAndMarker(videoId);
        DeleteTransferAndMarker(audioId);
        WriteMessage(new { ok = true, transferId = outputId, bytes = bytes, filename = Path.GetFileName(outputPath) });
    }

    private static string GetDownloadsFolder()
    {
        try
        {
            using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders"))
            {
                object value = key == null ? null : key.GetValue("{374DE290-123F-4565-9164-39C4925E467B}");
                if (value != null)
                {
                    string expanded = Environment.ExpandEnvironmentVariables(Convert.ToString(value));
                    if (!string.IsNullOrWhiteSpace(expanded)) return expanded;
                }
            }
        }
        catch { }
        return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
    }

    private static string UniqueDestination(string folder, string filename)
    {
        string safe = Path.GetFileName(filename);
        if (string.IsNullOrWhiteSpace(safe)) safe = "facebook_video.mp4";
        string path = Path.Combine(folder, safe);
        if (!File.Exists(path)) return path;
        string stem = Path.GetFileNameWithoutExtension(safe);
        string ext = Path.GetExtension(safe);
        for (int i = 1; i < 10000; i++)
        {
            string next = Path.Combine(folder, stem + " (" + i + ")" + ext);
            if (!File.Exists(next)) return next;
        }
        throw new InvalidOperationException("download_filename_conflict");
    }

    private static void SaveTempFileToDownloads(Dictionary<string, object> request)
    {
        string transferId = SanitizeTransferId(GetString(request, "transferId"));
        string source = GetTransferPath(transferId);
        if (!File.Exists(source) || new FileInfo(source).Length <= 0) throw new InvalidOperationException("empty_file");
        string filename = Path.GetFileName(GetString(request, "filename"));
        if (string.IsNullOrWhiteSpace(filename)) filename = "facebook_video.mp4";
        string folder = Path.Combine(GetDownloadsFolder(), "Facebook影片");
        Directory.CreateDirectory(folder);
        string target = UniqueDestination(folder, filename);
        File.Copy(source, target, false);
        File.Delete(source);
        try
        {
            string marker = Path.Combine(GetTempDirectory(), transferId + ".active");
            if (File.Exists(marker)) File.Delete(marker);
        }
        catch { }
        WriteMessage(new { ok = true, saved = true, path = target, bytes = new FileInfo(target).Length });
    }

    private static void SendTempFile(Dictionary<string, object> request)
    {
        string transferId = SanitizeTransferId(GetString(request, "transferId"));
        string filePath = GetTransferPath(transferId);
        if (!File.Exists(filePath) || new FileInfo(filePath).Length <= 0) throw new InvalidOperationException("empty_file");
        IntPtr lineWindow = ResolveLineWindow(request);
        string extension = Path.GetExtension(filePath).ToLowerInvariant();
        string activeMarkerPath = Path.Combine(Path.GetDirectoryName(filePath) ?? GetTempDirectory(), transferId + ".active");
        try
        {
            if (extension == ".mp4" || extension == ".mov" || extension == ".webm")
            {
                bool usedFallbackWait;
                bool uploadConfirmed = SendVideoThroughOpenDialog(lineWindow, filePath, out usedFallbackWait);
                long videoBytes = new FileInfo(filePath).Length;
                if (uploadConfirmed)
                {
                    try { if (File.Exists(filePath)) File.Delete(filePath); } catch { }
                }
                WriteMessage(new {
                    ok = true, pasted = false, sent = true, bytes = videoBytes, method = "ctrl_o",
                    uploadConfirmed = uploadConfirmed && !usedFallbackWait,
                    fallbackWaitUsed = usedFallbackWait,
                    tempDeleted = uploadConfirmed,
                    tempRetained = !uploadConfirmed
                });
                return;
            }

            SetClipboardFile(filePath);
            if (!FocusLineWindow(lineWindow)) throw new InvalidOperationException("line_focus_failed");
            Thread.Sleep(220);
            SendKeys.SendWait("^v");
            Thread.Sleep(420);
            SendKeys.SendWait("{ENTER}");
            Thread.Sleep(520);
            SendKeys.SendWait("{ENTER}");
            Thread.Sleep(1200);
            try { ClearClipboard(); } catch { }
            long bytes = new FileInfo(filePath).Length;
            WriteMessage(new { ok = true, pasted = true, sent = true, bytes = bytes, method = "clipboard" });
        }
        finally
        {
            if (extension != ".mp4" && extension != ".mov" && extension != ".webm")
            {
                try { if (File.Exists(filePath)) File.Delete(filePath); } catch { }
            }
            try { if (File.Exists(activeMarkerPath)) File.Delete(activeMarkerPath); } catch { }
        }
    }

    private static bool SendVideoThroughOpenDialog(IntPtr lineWindow, string filePath, out bool usedFallbackWait)
    {
        usedFallbackWait = false;
        if (!FocusLineWindow(lineWindow)) throw new InvalidOperationException("line_focus_failed");
        Thread.Sleep(220);
        SendKeys.SendWait("^o");

        IntPtr dialog = WaitForLineOpenDialog(lineWindow, 6000);
        if (dialog == IntPtr.Zero) throw new InvalidOperationException("line_file_dialog_not_found");
        if (!SetFilePathInOpenDialog(dialog, filePath)) throw new InvalidOperationException("line_file_path_input_failed");

        SetForegroundWindow(dialog);
        Thread.Sleep(180);
        SendKeys.SendWait("{ENTER}");

        DateTime closeDeadline = DateTime.UtcNow.AddSeconds(8);
        while (DateTime.UtcNow < closeDeadline && IsWindow(dialog))
            Thread.Sleep(120);
        if (IsWindow(dialog)) throw new InvalidOperationException("line_file_dialog_submit_failed");

        WaitForLineToTakeFile(filePath);
        return WaitForLineUploadCompletion(lineWindow, filePath, out usedFallbackWait);
    }

    private static bool WaitForLineUploadCompletion(IntPtr lineWindow, string filePath, out bool usedFallbackWait)
    {
        usedFallbackWait = false;
        int baseline = CountProgressBarsOptional(lineWindow);
        if (baseline < 0)
        {
            usedFallbackWait = true;
            FallbackWaitBeforeTempDelete(lineWindow, filePath);
            return true;
        }

        DateTime appearDeadline = DateTime.UtcNow.AddSeconds(15);
        bool sawProgress = false;

        while (DateTime.UtcNow < appearDeadline)
        {
            if (!IsWindow(lineWindow)) throw new InvalidOperationException("line_window_closed");
            int current = CountProgressBarsOptional(lineWindow);
            if (current < 0)
            {
                usedFallbackWait = true;
                FallbackWaitBeforeTempDelete(lineWindow, filePath);
                return true;
            }
            if (current > baseline)
            {
                sawProgress = true;
                break;
            }
            Thread.Sleep(250);
        }

        if (!sawProgress) return false;

        long bytes = 0;
        try { bytes = new FileInfo(filePath).Length; } catch { }
        int maxWaitSeconds = (int)Math.Min(1800L, Math.Max(60L, 60L + (bytes / (5L * 1024L * 1024L)) * 6L));
        DateTime finishDeadline = DateTime.UtcNow.AddSeconds(maxWaitSeconds);
        DateTime clearSince = DateTime.MinValue;

        while (DateTime.UtcNow < finishDeadline)
        {
            if (!IsWindow(lineWindow)) throw new InvalidOperationException("line_window_closed");
            int current = CountProgressBarsOptional(lineWindow);
            if (current < 0)
            {
                usedFallbackWait = true;
                FallbackWaitBeforeTempDelete(lineWindow, filePath);
                return true;
            }
            if (current <= baseline)
            {
                if (clearSince == DateTime.MinValue) clearSince = DateTime.UtcNow;
                if ((DateTime.UtcNow - clearSince).TotalSeconds >= 2.0) return true;
            }
            else
            {
                clearSince = DateTime.MinValue;
            }
            Thread.Sleep(300);
        }

        return false;
    }

    // Returns -1 when Windows UI Automation is unavailable. This lets the bridge
    // fall back to a conservative timed cleanup instead of failing installation.
    private static int CountProgressBarsOptional(IntPtr lineWindow)
    {
        try
        {
            Assembly client = TryLoadUiAutomationAssembly("UIAutomationClient.dll", "UIAutomationClient");
            Assembly typesAssembly = TryLoadUiAutomationAssembly("UIAutomationTypes.dll", "UIAutomationTypes");
            if (client == null || typesAssembly == null) return -1;

            Type automationElementType = client.GetType("System.Windows.Automation.AutomationElement", false)
                ?? typesAssembly.GetType("System.Windows.Automation.AutomationElement", false);
            Type treeScopeType = typesAssembly.GetType("System.Windows.Automation.TreeScope", false)
                ?? client.GetType("System.Windows.Automation.TreeScope", false);
            Type propertyConditionType = client.GetType("System.Windows.Automation.PropertyCondition", false)
                ?? typesAssembly.GetType("System.Windows.Automation.PropertyCondition", false);
            Type controlTypeType = typesAssembly.GetType("System.Windows.Automation.ControlType", false)
                ?? client.GetType("System.Windows.Automation.ControlType", false);
            if (automationElementType == null || treeScopeType == null || propertyConditionType == null || controlTypeType == null)
                return -1;

            MethodInfo fromHandle = automationElementType.GetMethod("FromHandle", BindingFlags.Public | BindingFlags.Static, null, new[] { typeof(IntPtr) }, null);
            if (fromHandle == null) return -1;
            object root = fromHandle.Invoke(null, new object[] { lineWindow });
            if (root == null) return 0;

            object controlTypeProperty = GetStaticMemberValue(automationElementType, "ControlTypeProperty");
            object progressBar = GetStaticMemberValue(controlTypeType, "ProgressBar");
            if (controlTypeProperty == null || progressBar == null) return -1;
            object condition = Activator.CreateInstance(propertyConditionType, new object[] { controlTypeProperty, progressBar });
            object descendants = Enum.Parse(treeScopeType, "Descendants");

            MethodInfo findAll = automationElementType.GetMethods(BindingFlags.Public | BindingFlags.Instance)
                .FirstOrDefault(method => method.Name == "FindAll" && method.GetParameters().Length == 2);
            if (findAll == null) return -1;
            object bars = findAll.Invoke(root, new object[] { descendants, condition });
            if (bars == null) return 0;
            PropertyInfo countInfo = bars.GetType().GetProperty("Count", BindingFlags.Public | BindingFlags.Instance);
            if (countInfo == null) return -1;
            return Convert.ToInt32(countInfo.GetValue(bars, null));
        }
        catch
        {
            return -1;
        }
    }

    private static object GetStaticMemberValue(Type type, string memberName)
    {
        try
        {
            PropertyInfo property = type.GetProperty(memberName, BindingFlags.Public | BindingFlags.Static);
            if (property != null) return property.GetValue(null, null);
            FieldInfo field = type.GetField(memberName, BindingFlags.Public | BindingFlags.Static);
            if (field != null) return field.GetValue(null);
        }
        catch { }
        return null;
    }

    private static Assembly TryLoadUiAutomationAssembly(string fileName, string shortName)
    {
        try
        {
            foreach (Assembly loaded in AppDomain.CurrentDomain.GetAssemblies())
            {
                try
                {
                    if (string.Equals(loaded.GetName().Name, shortName, StringComparison.OrdinalIgnoreCase)) return loaded;
                }
                catch { }
            }

            string windir = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
            string runtime = RuntimeEnvironment.GetRuntimeDirectory();
            string[] candidates = {
                Path.Combine(runtime ?? string.Empty, "WPF", fileName),
                Path.Combine(windir, "Microsoft.NET", "Framework64", "v4.0.30319", "WPF", fileName),
                Path.Combine(windir, "Microsoft.NET", "Framework", "v4.0.30319", "WPF", fileName)
            };
            foreach (string candidate in candidates)
            {
                if (!string.IsNullOrWhiteSpace(candidate) && File.Exists(candidate))
                    return Assembly.LoadFrom(candidate);
            }

            try { return Assembly.Load(shortName); } catch { return null; }
        }
        catch { return null; }
    }

    private static void FallbackWaitBeforeTempDelete(IntPtr lineWindow, string filePath)
    {
        long bytes = 0;
        try { bytes = new FileInfo(filePath).Length; } catch { }

        // Fallback for PCs without UI Automation: give LINE extra time to read/upload
        // the selected video before removing the temporary source file.
        double sizeMb = bytes / (1024.0 * 1024.0);
        int waitSeconds = (int)Math.Ceiling(18.0 + sizeMb * 0.45);
        waitSeconds = Math.Max(20, Math.Min(180, waitSeconds));
        DateTime deadline = DateTime.UtcNow.AddSeconds(waitSeconds);
        while (DateTime.UtcNow < deadline)
        {
            if (!IsWindow(lineWindow)) throw new InvalidOperationException("line_window_closed");
            Thread.Sleep(500);
        }
    }

    private static IntPtr WaitForLineOpenDialog(IntPtr lineWindow, int timeoutMs)
    {
        uint lineProcessId;
        GetWindowThreadIdAndProcess(lineWindow, out lineProcessId);
        DateTime deadline = DateTime.UtcNow.AddMilliseconds(timeoutMs);
        while (DateTime.UtcNow < deadline)
        {
            IntPtr found = IntPtr.Zero;
            EnumWindows(delegate (IntPtr hWnd, IntPtr lParam)
            {
                if (!IsWindowVisible(hWnd) || hWnd == lineWindow) return true;
                uint processId;
                GetWindowThreadIdAndProcess(hWnd, out processId);
                if (processId != lineProcessId) return true;
                StringBuilder className = new StringBuilder(128);
                GetClassName(hWnd, className, className.Capacity);
                if (string.Equals(className.ToString(), "#32770", StringComparison.OrdinalIgnoreCase))
                {
                    found = hWnd;
                    return false;
                }
                return true;
            }, IntPtr.Zero);
            if (found != IntPtr.Zero) return found;
            Thread.Sleep(100);
        }
        return IntPtr.Zero;
    }

    private static bool SetFilePathInOpenDialog(IntPtr dialog, string filePath)
    {
        List<Tuple<IntPtr, int>> edits = new List<Tuple<IntPtr, int>>();
        EnumChildWindows(dialog, delegate (IntPtr child, IntPtr lParam)
        {
            if (!IsWindowVisible(child) || !IsWindowEnabled(child)) return true;
            StringBuilder className = new StringBuilder(128);
            GetClassName(child, className, className.Capacity);
            if (string.Equals(className.ToString(), "Edit", StringComparison.OrdinalIgnoreCase))
            {
                RECT rect;
                if (GetWindowRect(child, out rect)) edits.Add(Tuple.Create(child, rect.Top));
            }
            return true;
        }, IntPtr.Zero);

        IntPtr edit = edits.OrderByDescending(item => item.Item2).Select(item => item.Item1).FirstOrDefault();
        if (edit == IntPtr.Zero) return false;
        SendMessage(edit, WM_SETTEXT, IntPtr.Zero, filePath);
        return true;
    }

    private static void WaitForLineToTakeFile(string filePath)
    {
        long bytes = new FileInfo(filePath).Length;
        int maxWaitMs = (int)Math.Min(60000L, Math.Max(6000L, (bytes / (4L * 1024L * 1024L)) * 1000L));
        DateTime deadline = DateTime.UtcNow.AddMilliseconds(maxWaitMs);
        DateTime minimum = DateTime.UtcNow.AddMilliseconds(2500);
        bool sawLocked = false;

        while (DateTime.UtcNow < deadline)
        {
            bool locked = false;
            try
            {
                using (FileStream probe = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.None)) { }
            }
            catch (IOException) { locked = true; }
            catch (UnauthorizedAccessException) { locked = true; }

            if (locked) sawLocked = true;
            else if ((sawLocked && DateTime.UtcNow >= minimum) || (!sawLocked && DateTime.UtcNow >= minimum)) return;
            Thread.Sleep(150);
        }
    }

    private static string GetActiveMarkerPath(string transferId)
    {
        return Path.Combine(GetTempDirectory(), SanitizeTransferId(transferId) + ".active");
    }

    private static bool IsTempFileActive(string filePath)
    {
        string directory = Path.GetDirectoryName(filePath) ?? string.Empty;
        string transferId = Path.GetFileNameWithoutExtension(filePath);
        string marker = Path.Combine(directory, transferId + ".active");
        if (File.Exists(marker)) return true;
        try
        {
            using (FileStream stream = new FileStream(filePath, FileMode.Open, FileAccess.ReadWrite, FileShare.None)) { }
            return false;
        }
        catch
        {
            return true;
        }
    }

    private static void TempStatus()
    {
        string directory = GetTempDirectory();
        var files = Directory.EnumerateFiles(directory, "*", SearchOption.TopDirectoryOnly)
            .Where(path => !string.Equals(Path.GetExtension(path), ".active", StringComparison.OrdinalIgnoreCase))
            .Select(path => new FileInfo(path))
            .Where(info => info.Exists)
            .OrderByDescending(info => info.LastWriteTimeUtc)
            .Select(info => new {
                path = info.FullName,
                filename = info.Name,
                bytes = info.Length,
                modifiedAt = info.LastWriteTimeUtc.ToString("o"),
                active = IsTempFileActive(info.FullName)
            })
            .ToArray();
        long totalBytes = files.Sum(item => item.bytes);
        int activeCount = files.Count(item => item.active);
        WriteMessage(new { ok = true, folderPath = directory, files = files, count = files.Length, totalBytes = totalBytes, activeCount = activeCount, canClear = files.Length > 0 && activeCount == 0 });
    }

    private static void OpenTempFolder()
    {
        string directory = GetTempDirectory();
        Process.Start(new ProcessStartInfo
        {
            FileName = "explorer.exe",
            Arguments = "\"" + directory + "\"",
            UseShellExecute = true
        });
        WriteMessage(new { ok = true, opened = true, folderPath = directory });
    }

    private static void ClearTempFiles()
    {
        string directory = GetTempDirectory();
        string[] files = Directory.EnumerateFiles(directory, "*", SearchOption.TopDirectoryOnly)
            .Where(path => !string.Equals(Path.GetExtension(path), ".active", StringComparison.OrdinalIgnoreCase))
            .ToArray();
        if (files.Length == 0)
        {
            WriteMessage(new { ok = true, cleared = true, deleted = 0, empty = true });
            return;
        }
        if (files.Any(IsTempFileActive)) throw new InvalidOperationException("temp_files_in_use");
        int deleted = 0;
        foreach (string file in files)
        {
            try { File.Delete(file); deleted++; } catch { throw new InvalidOperationException("temp_clear_failed"); }
        }
        foreach (string markerFile in Directory.GetFiles(directory, "*.active"))
        {
            try { File.Delete(markerFile); } catch { }
        }
        WriteMessage(new { ok = true, cleared = true, deleted = deleted, empty = true });
    }

    private static void CancelTempTransfer(Dictionary<string, object> request)
    {
        string transferId = SanitizeTransferId(GetString(request, "transferId"));
        string directory = GetTempDirectory();
        bool deleted = false;
        foreach (string path in Directory.GetFiles(directory, transferId + ".*"))
        {
            try { File.Delete(path); deleted = true; } catch { }
        }
        try { string markerFile = Path.Combine(directory, transferId + ".active"); if (File.Exists(markerFile)) File.Delete(markerFile); } catch { }
        WriteMessage(new { ok = true, deleted = deleted });
    }

    private static string SaveTemporaryFile(Dictionary<string, object> request)
    {
        string base64 = GetString(request, "base64");
        byte[] bytes = Convert.FromBase64String(base64);
        if (bytes.Length == 0) throw new InvalidOperationException("empty_file");
        if (bytes.Length > MaxFileBytes) throw new InvalidOperationException("file_too_large");

        string requestedName = Path.GetFileName(GetString(request, "filename"));
        string extension = Path.GetExtension(requestedName).ToLowerInvariant();
        string[] allowed = { ".gif", ".png", ".webp", ".jpg", ".jpeg", ".mp4", ".webm", ".mov", ".m4a", ".aac", ".mp3", ".opus" };
        if (!allowed.Contains(extension)) extension = ".gif";
        string tempDirectory = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "ThreadsMotionClipboardHost",
            "Temp"
        );
        Directory.CreateDirectory(tempDirectory);
        CleanOldFiles(tempDirectory);
        string filePath = Path.Combine(tempDirectory, "threads_" + DateTime.Now.ToString("yyyyMMdd_HHmmss_fff") + extension);
        File.WriteAllBytes(filePath, bytes);
        return filePath;
    }

    private static bool FocusLineWindow(IntPtr lineWindow)
    {
        ShowWindowAsync(lineWindow, 9);
        IntPtr foreground = GetForegroundWindow();
        uint foregroundThread = GetWindowThreadIdForFocus(foreground, IntPtr.Zero);
        uint currentThread = GetCurrentThreadId();
        bool attached = false;
        try
        {
            if (foregroundThread != 0 && foregroundThread != currentThread)
                attached = AttachThreadInput(currentThread, foregroundThread, true);
            BringWindowToTop(lineWindow);
            SetForegroundWindow(lineWindow);
            SetFocus(lineWindow);
        }
        finally
        {
            if (attached) AttachThreadInput(currentThread, foregroundThread, false);
        }
        Thread.Sleep(120);
        return GetForegroundWindow() == lineWindow;
    }

    private static void ListLineWindows()
    {
        List<LineWindowInfo> windows = GetLineWindows();
        WriteMessage(new { ok = true, windows = windows.ToArray(), windowCount = windows.Count });
    }

    private static List<LineWindowInfo> GetLineWindows()
    {
        HashSet<int> processIds = new HashSet<int>(Process.GetProcessesByName("LINE").Select(item => item.Id));
        List<LineWindowInfo> windows = new List<LineWindowInfo>();
        if (processIds.Count == 0) return windows;

        EnumWindows(delegate (IntPtr hWnd, IntPtr lParam)
        {
            if (!IsWindowVisible(hWnd)) return true;
            uint processId;
            GetWindowThreadIdAndProcess(hWnd, out processId);
            if (!processIds.Contains((int)processId)) return true;
            int length = GetWindowTextLength(hWnd);
            if (length <= 0) return true;
            StringBuilder title = new StringBuilder(length + 1);
            GetWindowText(hWnd, title, title.Capacity);
            string value = title.ToString().Trim();
            if (value.Length == 0) return true;
            // LINE 主視窗標題只有 "LINE"，不是實際聊天室，不列入送圖選單。
            if (string.Equals(value, "LINE", StringComparison.OrdinalIgnoreCase)) return true;
            windows.Add(new LineWindowInfo { id = hWnd.ToInt64().ToString(), title = value });
            return true;
        }, IntPtr.Zero);

        return windows.OrderBy(item => item.title, StringComparer.CurrentCultureIgnoreCase).ToList();
    }

    private static IntPtr ResolveLineWindow(Dictionary<string, object> request)
    {
        long rawHandle;
        if (!long.TryParse(GetString(request, "windowId"), out rawHandle)) throw new InvalidOperationException("line_window_closed");
        IntPtr hWnd = new IntPtr(rawHandle);
        if (!IsWindow(hWnd) || !IsWindowVisible(hWnd)) throw new InvalidOperationException("line_window_closed");
        uint processId;
        GetWindowThreadIdAndProcess(hWnd, out processId);
        try
        {
            Process process = Process.GetProcessById((int)processId);
            if (!string.Equals(process.ProcessName, "LINE", StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("line_window_closed");
        }
        catch (ArgumentException)
        {
            throw new InvalidOperationException("line_window_closed");
        }
        return hWnd;
    }

    private static void SetClipboardFile(string filePath)
    {
        Exception lastError = null;
        for (int attempt = 0; attempt < 8; attempt++)
        {
            try
            {
                StringCollection files = new StringCollection();
                files.Add(filePath);
                Clipboard.SetFileDropList(files);
                return;
            }
            catch (Exception error)
            {
                lastError = error;
                Thread.Sleep(120);
            }
        }
        throw new InvalidOperationException("clipboard_busy", lastError);
    }

    private static void ClearClipboard()
    {
        Exception lastError = null;
        for (int attempt = 0; attempt < 8; attempt++)
        {
            try
            {
                Clipboard.Clear();
                return;
            }
            catch (Exception error)
            {
                lastError = error;
                Thread.Sleep(120);
            }
        }
        throw new InvalidOperationException("clipboard_clear_failed", lastError);
    }

    private static void CleanOldFiles(string directory)
    {
        DateTime limit = DateTime.Now.AddDays(-1);
        foreach (string file in Directory.GetFiles(directory, "threads_*"))
        {
            try { if (File.GetLastWriteTime(file) < limit) File.Delete(file); }
            catch { }
        }
    }

    private static Dictionary<string, object> ReadMessage()
    {
        Stream input = Console.OpenStandardInput();
        byte[] lengthBytes = ReadExactly(input, 4);
        int length = BitConverter.ToInt32(lengthBytes, 0);
        if (length <= 0 || length > MaxMessageBytes) throw new InvalidOperationException("invalid_message_size");
        byte[] payload = ReadExactly(input, length);
        return Json.Deserialize<Dictionary<string, object>>(Encoding.UTF8.GetString(payload));
    }

    private static byte[] ReadExactly(Stream stream, int length)
    {
        byte[] buffer = new byte[length];
        int offset = 0;
        while (offset < length)
        {
            int read = stream.Read(buffer, offset, length - offset);
            if (read <= 0) throw new EndOfStreamException("message_incomplete");
            offset += read;
        }
        return buffer;
    }

    private static void WriteMessage(object value)
    {
        byte[] payload = Encoding.UTF8.GetBytes(Json.Serialize(value));
        Stream output = Console.OpenStandardOutput();
        byte[] length = BitConverter.GetBytes(payload.Length);
        output.Write(length, 0, length.Length);
        output.Write(payload, 0, payload.Length);
        output.Flush();
    }

    private static string GetString(Dictionary<string, object> values, string key)
    {
        object value;
        if (!values.TryGetValue(key, out value) || value == null) return string.Empty;
        return Convert.ToString(value);
    }

    private static bool GetBoolean(Dictionary<string, object> values, string key)
    {
        object value;
        if (!values.TryGetValue(key, out value) || value == null) return false;
        return Convert.ToBoolean(value);
    }
}
