﻿$ErrorActionPreference = "Stop"

$hostName = "com.cjcu.threads_line_clipboard"
$extensionId = "ggkdbfgodkiebjfoofbdhebgaikjalkl"
$installDirectory = Join-Path $env:LOCALAPPDATA "ThreadsMotionClipboardHost"
$sourceFile = Join-Path $PSScriptRoot "native-host.cs"
$executableFile = Join-Path $installDirectory "threads-line-host.exe"
$manifestFile = Join-Path $installDirectory "$hostName.json"
$registryPath = "HKCU:\Software\Google\Chrome\NativeMessagingHosts\$hostName"

function Stop-ThreadsNativeHost {
    # Temporarily unregister first so Chrome cannot immediately start another host while updating.
    if (Test-Path $registryPath) {
        Remove-Item $registryPath -Recurse -Force -ErrorAction SilentlyContinue
    }

    for ($attempt = 1; $attempt -le 10; $attempt++) {
        Get-Process -Name "threads-line-host" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
        Start-Sleep -Milliseconds 250
        $running = Get-Process -Name "threads-line-host" -ErrorAction SilentlyContinue
        if (-not $running) { return }
    }

    throw "Unable to stop threads-line-host.exe. Please close Chrome and run the installer again."
}

function Remove-OldExecutable {
    if (-not (Test-Path $executableFile)) { return }

    for ($attempt = 1; $attempt -le 12; $attempt++) {
        try {
            Remove-Item $executableFile -Force -ErrorAction Stop
            return
        }
        catch {
            Get-Process -Name "threads-line-host" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
            Start-Sleep -Milliseconds 300
        }
    }

    throw "Unable to replace threads-line-host.exe because the file is still in use. Please close Chrome and run the installer again."
}


function Ensure-Ffmpeg {
    $ffmpeg = Get-Command ffmpeg.exe -ErrorAction SilentlyContinue
    if ($ffmpeg) {
        Write-Host "已偵測到 FFmpeg：Facebook 影音分離合併功能已啟用。" -ForegroundColor Green
        return $true
    }

    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
    if (-not $winget) {
        Write-Host "尚未安裝 FFmpeg，且目前找不到 winget。" -ForegroundColor Yellow
        Write-Host "未安裝 FFmpeg 前，Facebook 影音分離影片無法合併聲音。" -ForegroundColor Yellow
        return $false
    }

    Write-Host "Facebook 影音分離影片需要 FFmpeg 才能合併聲音。" -ForegroundColor Yellow
    Write-Host "正在使用 Windows Package Manager 自動安裝 FFmpeg..." -ForegroundColor Yellow
    try {
        & winget.exe install --id Gyan.FFmpeg --exact --source winget --accept-source-agreements --accept-package-agreements --silent
    }
    catch { }

    $ffmpeg = Get-Command ffmpeg.exe -ErrorAction SilentlyContinue
    if ($ffmpeg) {
        Write-Host "FFmpeg 安裝完成。" -ForegroundColor Green
        return $true
    }

    $packages = Join-Path $env:LOCALAPPDATA "Microsoft\WinGet\Packages"
    if (Test-Path $packages) {
        $found = Get-ChildItem -Path $packages -Filter ffmpeg.exe -Recurse -File -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($found) {
            Write-Host "FFmpeg 安裝完成。" -ForegroundColor Green
            return $true
        }
    }

    Write-Host "FFmpeg 自動安裝未成功完成。" -ForegroundColor Red
    Write-Host "LINE 橋接程式仍會安裝，但在 FFmpeg 可用前，Facebook DASH 影片無法合併聲音。" -ForegroundColor Yellow
    return $false
}

Write-Host "正在更新 Threads／Facebook LINE 橋接程式..."
Stop-ThreadsNativeHost
New-Item -ItemType Directory -Path $installDirectory -Force | Out-Null
Remove-OldExecutable

function Try-ResolveUiAutomationAssembly([string]$assemblyName) {
    $runtimeDirectory = [System.Runtime.InteropServices.RuntimeEnvironment]::GetRuntimeDirectory()
    $candidates = @(
        (Join-Path $runtimeDirectory ("WPF\" + $assemblyName)),
        (Join-Path $env:WINDIR ("Microsoft.NET\Framework64\v4.0.30319\WPF\" + $assemblyName)),
        (Join-Path $env:WINDIR ("Microsoft.NET\Framework\v4.0.30319\WPF\" + $assemblyName))
    )

    foreach ($candidate in $candidates) {
        if ($candidate -and (Test-Path $candidate)) {
            return (Resolve-Path $candidate).Path
        }
    }

    try {
        $assembly = [System.Reflection.Assembly]::LoadWithPartialName([System.IO.Path]::GetFileNameWithoutExtension($assemblyName))
        if ($assembly -and $assembly.Location -and (Test-Path $assembly.Location)) {
            return $assembly.Location
        }
    }
    catch { }

    return $null
}

$uiAutomationClient = Try-ResolveUiAutomationAssembly "UIAutomationClient.dll"
$uiAutomationTypes = Try-ResolveUiAutomationAssembly "UIAutomationTypes.dll"
$uiAutomationAvailable = ($null -ne $uiAutomationClient -and $null -ne $uiAutomationTypes)

# UI Automation is optional. The host loads it dynamically when available.
# If unavailable, video sending still works and uses a conservative timed cleanup.
Add-Type `
    -Path $sourceFile `
    -OutputAssembly $executableFile `
    -OutputType ConsoleApplication `
    -ReferencedAssemblies @("System.dll", "System.Core.dll", "System.Windows.Forms.dll", "System.Web.Extensions.dll")

if ($uiAutomationAvailable) {
    Write-Host "UI Automation detected: upload completion monitoring enabled." -ForegroundColor Green
}
else {
    Write-Host "UI Automation not found: video sending will use timed temporary-file cleanup." -ForegroundColor Yellow
}

$ffmpegReady = Ensure-Ffmpeg

$manifest = [ordered]@{
    name = $hostName
    description = "Threads Motion Clipboard bridge for LINE Desktop"
    path = $executableFile
    type = "stdio"
    allowed_origins = @("chrome-extension://$extensionId/")
} | ConvertTo-Json -Depth 4

[System.IO.File]::WriteAllText($manifestFile, $manifest, (New-Object System.Text.UTF8Encoding($false)))
New-Item -Path $registryPath -Force | Out-Null
Set-Item -Path $registryPath -Value $manifestFile

Write-Host ""
Write-Host "安裝完成。" -ForegroundColor Green
Write-Host "舊版橋接程式已在更新前自動停止。"
Write-Host "請關閉並重新開啟 Chrome 一次。"
Write-Host "Extension ID: $extensionId"
if ($ffmpegReady) { Write-Host "Facebook 影音合併：已啟用" -ForegroundColor Green }
else { Write-Host "Facebook 影音合併：FFmpeg 尚未可用" -ForegroundColor Yellow }
