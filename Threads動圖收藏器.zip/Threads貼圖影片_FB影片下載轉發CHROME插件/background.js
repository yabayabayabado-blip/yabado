importScripts('idb.js');

const NATIVE_HOST = 'com.cjcu.threads_line_clipboard';
let recoveryPromise = null;

const FOLDER_INDEX_SIGNATURE_KEY = 'threadsGifFolderIndexSignatureV2';

// Facebook 新版播放器常以 MSE / fetch 載入影片，DOM 可能只看得到 blob:。
// v2.7.4：在請求發生時就記錄 FB CDN 媒體請求，並同步保存到 chrome.storage.session，
// 避免 Manifest V3 Service Worker 休眠後遺失已攔截的串流。
const facebookVideoRequestsByTab = new Map();
const FACEBOOK_CAPTURE_MAX = 80;
const FACEBOOK_CAPTURE_TTL = 30 * 60 * 1000;
const FACEBOOK_SESSION_PREFIX = 'facebookVideoCaptureTab:';

function isFacebookVideoCdnUrl(value) {
  try {
    const u = new URL(String(value || ''));
    const host = u.hostname.toLowerCase();
    return host === 'fbcdn.net' || host.endsWith('.fbcdn.net') ||
      host === 'cdninstagram.com' || host.endsWith('.cdninstagram.com');
  } catch (_) {
    return false;
  }
}

function isFacebookPageOrigin(value) {
  try {
    const host = new URL(String(value || '')).hostname.toLowerCase();
    return host === 'facebook.com' || host.endsWith('.facebook.com') ||
      host === 'fb.watch' || host.endsWith('.fb.watch');
  } catch (_) {
    return false;
  }
}

function isObviousImageUrl(value) {
  try {
    const u = new URL(String(value || ''));
    const p = u.pathname.toLowerCase();
    if (/\.(?:jpg|jpeg|png|gif|webp|avif|svg)(?:$|[?#])/i.test(u.href)) return true;
    const type = String(u.searchParams.get('type') || '').toLowerCase();
    if (type.startsWith('image')) return true;
    return /\/s\d+x\d+\//i.test(p) && !/\.(?:mp4|m4v|mov|webm)(?:$|[?#])/i.test(u.href);
  } catch (_) {
    return false;
  }
}

function classifyFacebookMediaRequest(details, detectedMime = '') {
  if (!details || details.tabId < 0 || !isFacebookVideoCdnUrl(details.url)) return '';
  if (isObviousImageUrl(details.url)) return '';
  const origin = details.initiator || details.documentUrl || '';
  if (origin && !isFacebookPageOrigin(origin)) return '';
  const raw = String(details.url || '');
  const mime = String(detectedMime || '').toLowerCase();
  if (mime.startsWith('video/')) return 'video';
  if (mime.startsWith('audio/')) return 'audio';
  if (/mime(?:_type)?=audio|audio%2[fF]|\baudio_id=|\/audio\//i.test(raw)) return 'audio';
  if (/mime(?:_type)?=video|video%2[fF]|\bvideo_id=|\/video\//i.test(raw)) return 'video';
  if (/\.(?:m4a|aac|mp3|opus)(?:$|[?#])/i.test(raw)) return 'audio';
  if (/\.(?:mp4|m4v|mov|webm)(?:$|[?#])/i.test(raw)) return 'video';
  // Facebook DASH 的音訊／視訊分段常沒有明確副檔名；media 請求先保留，稍後用 MP4 track 判斷。
  if (details.type === 'media') return 'unknown';
  if (/bytestart=|byteend=|\/o1\/v\//i.test(raw)) return 'unknown';
  return '';
}

function facebookVideoUrlKey(value) {
  try {
    const u = new URL(String(value || ''));
    u.hash = '';
    // range 只用於判斷同一來源，實際下載仍保留原始 URL，避免把可用網址改壞。
    u.searchParams.delete('bytestart');
    u.searchParams.delete('byteend');
    return u.href;
  } catch (_) {
    return String(value || '');
  }
}

function pruneFacebookItems(items) {
  const now = Date.now();
  const map = new Map();
  for (const item of Array.isArray(items) ? items : []) {
    if (!item?.url || now - Number(item.capturedAt || 0) > FACEBOOK_CAPTURE_TTL) continue;
    const key = facebookVideoUrlKey(item.url);
    const old = map.get(key);
    if (!old || Number(item.capturedAt || 0) >= Number(old.capturedAt || 0)) map.set(key, item);
  }
  const out = [...map.values()].sort((a, b) => Number(b.capturedAt || 0) - Number(a.capturedAt || 0));
  return out.slice(0, FACEBOOK_CAPTURE_MAX);
}

async function persistFacebookCapture(tabId) {
  if (!chrome.storage?.session || tabId < 0) return;
  const map = facebookVideoRequestsByTab.get(tabId);
  const items = pruneFacebookItems(map ? [...map.values()] : []);
  try {
    await chrome.storage.session.set({ [`${FACEBOOK_SESSION_PREFIX}${tabId}`]: items });
  } catch (_) { }
}

async function loadFacebookCapture(tabId) {
  if (tabId < 0) return [];
  let items = [];
  if (chrome.storage?.session) {
    try {
      const key = `${FACEBOOK_SESSION_PREFIX}${tabId}`;
      const stored = await chrome.storage.session.get({ [key]: [] });
      items = Array.isArray(stored[key]) ? stored[key] : [];
    } catch (_) { }
  }
  const mem = facebookVideoRequestsByTab.get(tabId);
  if (mem) items.push(...mem.values());
  return pruneFacebookItems(items);
}

function rememberFacebookVideoRequest(details, extra = {}) {
  const kind = extra.kind || classifyFacebookMediaRequest(details, extra.detectedMime || '');
  if (!kind) return;
  const url = String(details.url || '');
  const key = facebookVideoUrlKey(url);
  const now = Date.now();
  let map = facebookVideoRequestsByTab.get(details.tabId);
  if (!map) {
    map = new Map();
    facebookVideoRequestsByTab.set(details.tabId, map);
  }
  const previous = map.get(key);
  const nextKind = kind !== 'unknown' ? kind : (previous?.kind || 'unknown');
  map.set(key, {
    ...(previous || {}),
    url,
    kind: nextKind,
    source: extra.source || previous?.source || 'network-request',
    requestType: details.type || previous?.requestType || '',
    detectedMime: extra.detectedMime || previous?.detectedMime || '',
    sizeBytes: Math.max(Number(previous?.sizeBytes || 0), Number(extra.sizeBytes || 0)),
    capturedAt: now
  });
  while (map.size > FACEBOOK_CAPTURE_MAX) map.delete(map.keys().next().value);
  persistFacebookCapture(details.tabId).catch(() => {});
}

try {
  chrome.webRequest.onBeforeRequest.addListener(
    (details) => rememberFacebookVideoRequest(details, { source: 'network-request' }),
    { urls: ['https://*.fbcdn.net/*', 'https://*.cdninstagram.com/*'] }
  );

  chrome.webRequest.onHeadersReceived.addListener(
    (details) => {
      if (details.tabId < 0 || !isFacebookVideoCdnUrl(details.url) || isObviousImageUrl(details.url)) return;
      const headers = Array.isArray(details.responseHeaders) ? details.responseHeaders : [];
      const header = (name) => headers.find((h) => String(h?.name || '').toLowerCase() === name)?.value || '';
      const mime = String(header('content-type')).split(';')[0].trim().toLowerCase();
      const contentRange = String(header('content-range'));
      const rangeMatch = contentRange.match(/\/(\d+)\s*$/);
      const sizeBytes = rangeMatch ? Number(rangeMatch[1]) : Number(header('content-length') || 0);
      // DASH 可能是 video/*、audio/* 或 application/octet-stream；都先保留，稍後再讀 MP4 track 判斷。
      const synthetic = { ...details, initiator: details.initiator || '', documentUrl: details.documentUrl || '' };
      const kind = classifyFacebookMediaRequest(synthetic, mime);
      if (kind) {
        rememberFacebookVideoRequest(synthetic, { source: 'network-response', detectedMime: mime, sizeBytes, kind });
      }
    },
    { urls: ['https://*.fbcdn.net/*', 'https://*.cdninstagram.com/*'] },
    ['responseHeaders']
  );
} catch (_) { }

chrome.tabs?.onRemoved?.addListener((tabId) => {
  facebookVideoRequestsByTab.delete(tabId);
  if (chrome.storage?.session) chrome.storage.session.remove(`${FACEBOOK_SESSION_PREFIX}${tabId}`).catch(() => {});
});

function buildFolderIndexSignature(files) {
  return [...files]
    .filter((file) => /\.gif$/i.test(String(file.filename || file.path || '')))
    .map((file) => ({
      filename: String(file.filename || file.path || '').replaceAll('\\', '/').split('/').pop().toLowerCase(),
      bytes: Number(file.bytes || 0)
    }))
    .sort((a, b) => a.filename.localeCompare(b.filename));
}

function sameFolderIndexSignature(a, b) {
  if (!Array.isArray(a) || !Array.isArray(b) || a.length !== b.length) return false;
  for (let i = 0; i < a.length; i += 1) {
    if (a[i].filename !== b[i].filename || a[i].bytes !== b[i].bytes) return false;
  }
  return true;
}

function basenameKey(value) {
  return String(value || '').replaceAll('\\', '/').split('/').pop().toLowerCase();
}

function signatureToMap(signature) {
  const map = new Map();
  for (const entry of Array.isArray(signature) ? signature : []) {
    if (!entry?.filename) continue;
    map.set(String(entry.filename).toLowerCase(), Number(entry.bytes || 0));
  }
  return map;
}

async function saveFolderIndexSignature(files) {
  await chrome.storage.local.set({ [FOLDER_INDEX_SIGNATURE_KEY]: buildFolderIndexSignature(files) });
}


chrome.runtime.onInstalled.addListener(() => {
  chrome.action.setBadgeBackgroundColor({ color: '#0a7a5a' });
  refreshBadgeFromDb().catch(() => {});
});

chrome.runtime.onStartup.addListener(() => {
  refreshBadgeFromDb().catch(() => {});
});

async function refreshBadgeFromDb() {
  const items = await getAllMedia();
  chrome.action.setBadgeText({ text: items.length ? String(Math.min(items.length, 999)) : '' });
  return items.length;
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'GET_FACEBOOK_VIDEO_REQUESTS') {
    const tabId = Number(message.tabId);
    loadFacebookCapture(tabId)
      .then((items) => sendResponse({ ok: true, items }))
      .catch((error) => sendResponse({ ok: false, items: [], error: friendlyError(error) }));
    return true;
  }

  if (message?.type === 'STORE_MEDIA_BATCH') {
    (async () => {
      await ensureRecoveredLibrary();
      return storeMediaBatch(message.items || [], message.page || {});
    })()
      .then(sendResponse)
      .catch((error) => sendResponse({ ok: false, error: friendlyError(error) }));
    return true;
  }

  if (message?.type === 'GET_LIBRARY_COUNT') {
    (async () => {
      const count = await refreshBadgeFromDb();
      return { ok: true, count };
    })()
      .then(sendResponse)
      .catch((error) => sendResponse({ ok: false, error: friendlyError(error) }));
    return true;
  }

  if (message?.type === 'REFRESH_FOLDER_INDEX_SIGNATURE') {
    refreshFolderIndexSignature()
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: friendlyError(error) }));
    return true;
  }

  if (message?.type === 'OPEN_LIBRARY') {
    chrome.tabs.create({ url: chrome.runtime.getURL('library.html') });
    sendResponse({ ok: true });
  }
});

async function ensureRecoveredLibrary() {
  if (recoveryPromise) return recoveryPromise;
  recoveryPromise = recoverLibraryFromExistingDownloads().finally(() => {
    recoveryPromise = null;
  });
  return recoveryPromise;
}


function hasChromeDuplicateSuffix(filename) {
  return / \(\d+\)(?=\.[^.]+$)/i.test(String(filename || ''));
}

function chooseDuplicateKeeper(files) {
  return [...files].sort((a, b) => {
    const aDup = hasChromeDuplicateSuffix(a.filename) ? 1 : 0;
    const bDup = hasChromeDuplicateSuffix(b.filename) ? 1 : 0;
    if (aDup !== bDup) return aDup - bDup;
    const aTime = Date.parse(a.modifiedAt || '') || 0;
    const bTime = Date.parse(b.modifiedAt || '') || 0;
    if (aTime !== bTime) return aTime - bTime;
    const aName = String(a.filename || '');
    const bName = String(b.filename || '');
    if (aName.length !== bName.length) return aName.length - bName.length;
    return aName.localeCompare(bName, 'zh-Hant');
  })[0];
}

async function dedupeFolderFiles(files) {
  const groups = new Map();
  for (let index = 0; index < files.length; index += 1) {
    const file = files[index];
    const fullPath = String(file.path || '');
    if (!fullPath) continue;
    try {
      const response = await nativeCall({ action: 'read_file', filePath: fullPath });
      if (!response?.ok || !response.base64) continue;
      const bytes = base64ToUint8Array(response.base64);
      if (!bytes.byteLength) continue;
      const contentHash = await sha256Bytes(bytes);
      const enriched = { ...file, contentHash, bytesData: bytes };
      if (!groups.has(contentHash)) groups.set(contentHash, []);
      groups.get(contentHash).push(enriched);
    } catch (_) { }
  }

  const kept = [];
  let deletedDuplicates = 0;
  for (const group of groups.values()) {
    const keeper = chooseDuplicateKeeper(group);
    if (!keeper) continue;
    kept.push(keeper);
    for (const file of group) {
      if (file.path === keeper.path) continue;
      try {
        const deleted = await nativeCall({ action: 'delete_file', filePath: file.path });
        if (deleted?.ok && (deleted.deleted || deleted.missing)) deletedDuplicates += 1;
        else kept.push(file);
      } catch (_) {
        kept.push(file);
      }
    }
  }
  return { files: kept, deletedDuplicates };
}

async function refreshFolderIndexSignature() {
  const folderPath = await locateThreadsFolderFromDownloads();
  if (!folderPath) return false;
  const listing = await nativeCall({ action: 'list_folder', folderPath });
  if (!listing?.ok || !Array.isArray(listing.files)) return false;
  await saveFolderIndexSignature(listing.files);
  return true;
}

async function recoverLibraryFromExistingDownloads() {
  const folderPath = await locateThreadsFolderFromDownloads();
  if (!folderPath) return 0;

  let ping;
  try {
    ping = await nativeCall({ action: 'ping' });
  } catch (_) {
    throw new Error('已找到 Threads動圖 資料夾，但目前無法讀取實際檔案。請重新執行「安裝LINE自動貼上功能.cmd」並重開 Chrome，避免重複下載。');
  }
  if (!ping?.ok || compareVersions(String(ping.version || '0'), '2.6.1') < 0) {
    throw new Error('已找到 Threads動圖 資料夾，但 Windows 橋接程式版本過舊。請重新執行「安裝LINE自動貼上功能.cmd」並重開 Chrome，避免重複下載。');
  }

  const listing = await nativeCall({ action: 'list_folder', folderPath });
  if (!listing?.ok || !Array.isArray(listing.files)) return 0;

  const gifFiles = listing.files.filter((file) => /\.gif$/i.test(String(file.filename || file.path || '')));
  const current = await getAllMedia();
  const stored = await chrome.storage.local.get({ [FOLDER_INDEX_SIGNATURE_KEY]: null });
  const previousSignature = stored[FOLDER_INDEX_SIGNATURE_KEY];
  const currentSignature = buildFolderIndexSignature(gifFiles);

  if (sameFolderIndexSignature(previousSignature, currentSignature)) return 0;

  // 有既有 DB 但沒有快速索引時，只建立基準，不再整批重掃。
  if ((!Array.isArray(previousSignature) || previousSignature.length === 0) && current.length > 0) {
    await saveFolderIndexSignature(gifFiles);
    return 0;
  }

  const previousMap = signatureToMap(previousSignature);
  const currentMap = signatureToMap(currentSignature);
  const changedNames = currentSignature
    .filter((entry) => previousMap.get(entry.filename) !== entry.bytes)
    .map((entry) => entry.filename);
  const removedNames = [...previousMap.keys()].filter((name) => !currentMap.has(name));
  const removedSet = new Set(removedNames);
  const changedSet = new Set(changedNames);

  for (const item of current) {
    if (!item?.localFilePath || !removedSet.has(basenameKey(item.localFilePath))) continue;
    await deleteMedia(item.id);
  }

  let restored = 0;
  for (const file of gifFiles.filter((entry) => changedSet.has(basenameKey(entry.filename || entry.path)))) {
    const fullPath = String(file.path || '');
    if (!fullPath) continue;
    try {
      const response = await nativeCall({ action: 'read_file', filePath: fullPath });
      if (!response?.ok || !response.base64) continue;
      const bytes = base64ToUint8Array(response.base64);
      if (!bytes.byteLength) continue;
      const contentHash = await sha256Bytes(bytes);

      let existingItems = await getAllMedia();
      const samePath = existingItems.find((item) => basenameKey(item.localFilePath) === basenameKey(fullPath));
      if (samePath && samePath.contentHash !== contentHash) {
        await deleteMedia(samePath.id);
        existingItems = existingItems.filter((item) => item.id !== samePath.id);
      }

      const sameContent = existingItems.find((item) => item.contentHash && item.contentHash === contentHash);
      if (sameContent) {
        try { await nativeCall({ action: 'delete_file', filePath: fullPath }); } catch (_) { }
        continue;
      }

      const filename = String(file.filename || basenameKey(fullPath) || 'threads.gif');
      await putMedia({
        id: `restored_${contentHash}`,
        blob: new Blob([bytes], { type: 'image/gif' }),
        mime: 'image/gif',
        extension: 'gif',
        bytes: bytes.byteLength,
        kind: 'image',
        sourceUrl: '',
        sourcePage: '',
        pageTitle: filename,
        author: '',
        capturedAt: file.modifiedAt || new Date().toISOString(),
        filename,
        contentHash,
        recoveredFromDownload: true,
        localFilePath: fullPath
      });
      restored += 1;
    } catch (_) { }
  }

  try {
    const finalListing = await nativeCall({ action: 'list_folder', folderPath });
    if (finalListing?.ok && Array.isArray(finalListing.files)) await saveFolderIndexSignature(finalListing.files);
    else await saveFolderIndexSignature(gifFiles);
  } catch (_) {
    await saveFolderIndexSignature(gifFiles);
  }

  await refreshBadgeFromDb();
  return restored;
}

async function locateThreadsFolderFromDownloads() {
  let downloads = [];
  try {
    downloads = await chrome.downloads.search({ orderBy: ['-startTime'], limit: 5000 });
  } catch (_) {
    return '';
  }
  const marker = '/Threads動圖/';
  for (const item of downloads) {
    const fullPath = String(item?.filename || '');
    const normalized = fullPath.replaceAll('\\', '/');
    const at = normalized.toLowerCase().lastIndexOf(marker.toLowerCase());
    if (at < 0) continue;
    return fullPath.slice(0, at + marker.length - 1).replaceAll('/', '\\');
  }
  return '';
}

function compareVersions(a, b) {
  const aa = String(a).split('.').map((part) => Number(part) || 0);
  const bb = String(b).split('.').map((part) => Number(part) || 0);
  const length = Math.max(aa.length, bb.length);
  for (let i = 0; i < length; i += 1) {
    if ((aa[i] || 0) > (bb[i] || 0)) return 1;
    if ((aa[i] || 0) < (bb[i] || 0)) return -1;
  }
  return 0;
}

function nativeCall(message) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendNativeMessage(NATIVE_HOST, message, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message || 'native_host_unavailable'));
        return;
      }
      resolve(response || null);
    });
  });
}

function base64ToUint8Array(base64) {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
  return bytes;
}

async function sha256Bytes(bytes) {
  const view = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  const digest = await crypto.subtle.digest('SHA-256', view);
  return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, '0')).join('');
}

function normalizeRecoveredMime(mime, extension) {
  const clean = String(mime || '').split(';')[0].toLowerCase();
  if (/^(image|video)\//.test(clean)) return clean;
  const types = {
    gif: 'image/gif', webp: 'image/webp', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg',
    mp4: 'video/mp4', webm: 'video/webm', mov: 'video/quicktime'
  };
  return types[String(extension || '').toLowerCase()] || 'image/gif';
}

async function storeMediaBatch(items, page) {
  if (!Array.isArray(items) || items.length === 0) {
    return { ok: true, saved: [], skipped: 0, nonGif: 0, failed: [] };
  }

  const unique = [...new Map(items.map((item) => [item.url, item])).values()];
  const saved = [];
  const failed = [];
  let skipped = 0;
  let nonGif = 0;

  for (let index = 0; index < unique.length; index += 1) {
    const candidate = unique[index];
    try {
      const id = await sha256(candidate.url);
      const existing = await getMedia(id);
      if (existing) {
        if (!(await isActualGifBlob(existing.blob))) {
          nonGif += 1;
          continue;
        }
        skipped += 1;
        saved.push({ id, existing: true });
        continue;
      }

      const response = await fetch(candidate.url, {
        credentials: 'include',
        cache: 'no-cache',
        referrer: page.url || 'https://www.threads.com/'
      });
      if (!response.ok) throw new Error(`下載來源回應 ${response.status}`);

      const blob = await response.blob();
      if (!blob.size) throw new Error('來源檔案大小為 0');
      if (!(await isActualGifBlob(blob))) {
        nonGif += 1;
        continue;
      }

      const contentHash = await sha256Blob(blob);
      const existingItems = await getAllMedia();
      const sameContent = existingItems.find((item) => item.contentHash && item.contentHash === contentHash);
      if (sameContent) {
        if (!(await isActualGifBlob(sameContent.blob))) {
          nonGif += 1;
          continue;
        }
        skipped += 1;
        saved.push({ id: sameContent.id, existing: true });
        continue;
      }

      const mime = 'image/gif';
      const extension = 'gif';
      const capturedAt = new Date().toISOString();
      const item = {
        id,
        blob: blob.type === mime ? blob : blob.slice(0, blob.size, mime),
        mime,
        extension,
        bytes: blob.size,
        kind: 'image',
        sourceUrl: candidate.url,
        sourcePage: page.url || '',
        pageTitle: page.title || 'Threads 貼文',
        author: page.author || '',
        capturedAt,
        filename: buildFilename(page, index + 1, extension),
        contentHash
      };
      await putMedia(item);
      saved.push({ id, existing: false });
    } catch (error) {
      failed.push({ url: candidate.url, error: friendlyError(error) });
    }
  }

  const all = await getAllMedia();
  chrome.action.setBadgeText({ text: all.length ? String(Math.min(all.length, 999)) : '' });
  return { ok: saved.length > 0 || failed.length < unique.length, saved, skipped, nonGif, failed };
}

async function isActualGifBlob(blob) {
  if (!(blob instanceof Blob) || blob.size < 6) return false;
  const bytes = new Uint8Array(await blob.slice(0, 6).arrayBuffer());
  return bytes[0] === 0x47 && bytes[1] === 0x49 && bytes[2] === 0x46 &&
    bytes[3] === 0x38 && (bytes[4] === 0x37 || bytes[4] === 0x39) && bytes[5] === 0x61;
}


async function sha256Blob(blob) {
  const buffer = await blob.arrayBuffer();
  const digest = await crypto.subtle.digest('SHA-256', buffer);
  return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, '0')).join('');
}

async function sha256(value) {
  const data = new TextEncoder().encode(value);
  const digest = await crypto.subtle.digest('SHA-256', data);
  return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, '0')).join('');
}

function normalizeMime(mime, kind, url) {
  const clean = (mime || '').split(';')[0].toLowerCase();
  if (/^(image|video)\//.test(clean)) return clean;
  const lower = url.toLowerCase();
  if (/\.gif(?:$|[?#])/.test(lower)) return 'image/gif';
  if (/\.webp(?:$|[?#])/.test(lower)) return 'image/webp';
  if (/\.webm(?:$|[?#])/.test(lower)) return 'video/webm';
  if (/\.mov(?:$|[?#])/.test(lower)) return 'video/quicktime';
  return kind === 'video' ? 'video/mp4' : 'image/gif';
}

function extensionFromMime(mime, url) {
  const types = {
    'image/gif': 'gif',
    'image/webp': 'webp',
    'image/png': 'png',
    'image/jpeg': 'jpg',
    'video/mp4': 'mp4',
    'video/webm': 'webm',
    'video/quicktime': 'mov'
  };
  if (types[mime]) return types[mime];
  const match = url.match(/\.([a-z0-9]{2,5})(?:$|[?#])/i);
  return match ? match[1].toLowerCase() : 'bin';
}

function buildFilename(page, index, extension) {
  const date = new Date().toISOString().slice(0, 10).replaceAll('-', '');
  const author = sanitizeFilename(page.author || 'threads');
  return `${date}_${author}_${String(index).padStart(2, '0')}.${extension}`;
}

function sanitizeFilename(value) {
  return String(value).replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').replace(/\s+/g, '_').slice(0, 60) || 'threads';
}

function friendlyError(error) {
  if (error?.name === 'QuotaExceededError') return '本機收藏空間不足，請先刪除部分舊收藏。';
  return error?.message || String(error || '未知錯誤');
}
